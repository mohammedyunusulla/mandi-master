import 'package:data_table_2/data_table_2.dart';
import 'package:flutter/material.dart';
import 'package:mandi_admin_panel/common/widgets/loaders/animation_loader.dart';
import 'package:mandi_admin_panel/utils/constants/image_strings.dart';

import '../../../utils/constants/colors.dart';
import '../../../utils/constants/sizes.dart';

// Custom PaginatedDataTable widget with additional features
class TPaginatedDataTable extends StatelessWidget {
  const TPaginatedDataTable({
    Key? key,
    required this.columns,
    required this.source,
    this.rowsPerPage = 10,
    required this.onPageChanged,
    this.sortColumnIndex,
  }) : super(key: key);

  /// Number of rows to display per page
  final int? sortColumnIndex;

  /// Number of rows to display per page
  final int rowsPerPage;

  /// Data source for the DataTable
  final DataTableSource source;

  /// List of columns for the DataTable
  final List<DataColumn> columns;

  /// Callback function to handle page changes
  final Function(int)? onPageChanged;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: MediaQuery.of(context).size.height * 0.8, // Set the height of the PaginatedDataTable
      child: Theme(
        data: Theme.of(context).copyWith(cardTheme: const CardTheme(color: Colors.white)), // Set the card color theme
        child: PaginatedDataTable2(
          empty: TAnimationLoaderWidget(animation: TImages.pencilAnimation, text: 'Nothing Found'),
          autoRowsToHeight: true,
          showCheckboxColumn: false,
          sortColumnIndex: sortColumnIndex,
          rowsPerPage: rowsPerPage,
          // Set the number of rows per page
          columns: columns,
          // Set the columns for the DataTable
          source: source,
          // Set the data source for the DataTable
          onPageChanged: onPageChanged,
          // Set the callback for page changes
          minWidth: 1100,
          // Set the minimum width of the DataTable
          columnSpacing: 12,
          // Set the spacing between columns
          horizontalMargin: 12,
          // Set the horizontal margin
          headingTextStyle: Theme.of(context).textTheme.titleMedium!.apply(color: Colors.white),
          // Set the heading text style
          headingRowColor: MaterialStateProperty.resolveWith((states) => TColors.primary),
          // Set the heading row color
          headingRowDecoration: const BoxDecoration(
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(TSizes.borderRadiusMd),
              topRight: Radius.circular(TSizes.borderRadiusMd),
            ),
          ), // Set the heading row decoration
        ),
      ),
    );
  }
}
