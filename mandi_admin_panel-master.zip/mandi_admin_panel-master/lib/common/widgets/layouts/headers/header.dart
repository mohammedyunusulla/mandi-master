import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:iconsax/iconsax.dart';
import 'package:mandi_admin_panel/common/widgets/images/t_rounded_image.dart';
import 'package:mandi_admin_panel/common/widgets/shimmers/shimmer.dart';

import '../../../../src/controllers/users/admin_controller.dart';
import '../../../../utils/constants/colors.dart';
import '../../../../utils/constants/image_strings.dart';
import '../../../../utils/constants/sizes.dart';
import '../../../../utils/constants/text_strings.dart';
import '../../../../utils/device/device_utility.dart';
import '../../appbar/appbar.dart';

class THeader extends StatelessWidget implements PreferredSizeWidget {
  const THeader({
    super.key,
    required this.scaffoldKey,
  });

  final GlobalKey<ScaffoldState> scaffoldKey;

  @override
  Widget build(BuildContext context) {
    final controller = AdminController.instance;
    return Container(
      decoration: const BoxDecoration(color: TColors.white, border: Border(bottom: BorderSide(color: TColors.grey, width: 1))),
      padding: const EdgeInsets.symmetric(horizontal: TSizes.md, vertical: TSizes.sm),
      child: TAppBar(
        leadingIcon: !TDeviceUtils.isDesktopScreen(context) ? Iconsax.menu : null,
        leadingOnPressed: !TDeviceUtils.isDesktopScreen(context) ? () => scaffoldKey.currentState?.openDrawer() : null,
        title: Text(TTexts.appName.toUpperCase()),
        actions: [
          // Search Icon on Mobile
          // if (!TDeviceUtils.isDesktopScreen(context)) IconButton(icon: const Icon(Iconsax.search_normal), onPressed: () {}),

          // Notification Icon
          // IconButton(icon: const Icon(Iconsax.notification), onPressed: () {}),
          // const SizedBox(width: TSizes.spaceBtwItems / 2),

          /// User Data
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // User Profile Image
              Obx(
                () => TRoundedImage(
                  width: 50,
                  height: 50,
                  isNetworkImage: controller.user.value.profilePicture.isNotEmpty ? true : false,
                  imageUrl: controller.user.value.profilePicture.isNotEmpty ? controller.user.value.profilePicture : TImages.user,
                  padding: const EdgeInsets.all(2),
                ),
              ),

              const SizedBox(width: TSizes.sm),

              // User Profile Data [Hide on Mobile]
              if (!TDeviceUtils.isMobileScreen(context))
                Obx(
                  () => Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      controller.loading.value
                          ? const TShimmerEffect(width: 50, height: 13)
                          : Text(controller.user.value.name, style: Theme.of(context).textTheme.bodyLarge),
                      controller.loading.value
                          ? const TShimmerEffect(width: 70, height: 13)
                          : Text(controller.user.value.email, style: Theme.of(context).textTheme.labelMedium),
                    ],
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  Size get preferredSize => Size.fromHeight(TDeviceUtils.getAppBarHeight() + 15);
}
