import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../utils/constants/colors.dart';
import '../../../../../utils/constants/sizes.dart';
import '../sidebar_controller.dart';

class TMenuItem extends StatelessWidget {
  const TMenuItem({super.key, required this.itemName});

  final String itemName;

  @override
  Widget build(BuildContext context) {
    final menuController = Get.put(SidebarController());
    return InkWell(
      onTap: () => menuController.menuOnTap(itemName),
      onHover: (value) => value ? menuController.changeHoverItem(itemName) : menuController.changeHoverItem(''),
      child: Obx(() {
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: TSizes.xs),
          child: Container(
            color: menuController.isHovering(itemName) || menuController.isActive(itemName)
                ? TColors.dark.withOpacity(0.2)
                : Colors.transparent,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // Icon
                Padding(padding: const EdgeInsets.only(left: TSizes.lg, top: TSizes.md, bottom: TSizes.md, right: TSizes.md, ), child: menuController.returnIcon(itemName)),

                // Text
                if (menuController.isHovering(itemName) || menuController.isActive(itemName))
                  Flexible(
                    child: Text(
                      '${menuController.returnItemName(itemName)}'.toUpperCase(),
                      style: Theme.of(context).textTheme.bodyMedium!.apply(color: TColors.white),
                    ),
                  )
                else
                  Flexible(
                    child: Text(
                      '${menuController.returnItemName(itemName)}'.toUpperCase(),
                      style: Theme.of(context).textTheme.bodyMedium!.apply(color: TColors.grey),
                    ),
                  )
              ],
            ),
          ),
        );
      }),
    );
  }
}
