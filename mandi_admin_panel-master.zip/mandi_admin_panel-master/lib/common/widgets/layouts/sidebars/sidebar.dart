import 'package:flutter/material.dart';
import 'package:mandi_admin_panel/routes/routes.dart';
import '../../../../utils/constants/colors.dart';
import '../../../../utils/constants/image_strings.dart';
import '../../../../utils/constants/sizes.dart';
import '../../images/t_circular_image.dart';
import 'menu/menu_item.dart';

class TSidebar extends StatelessWidget {
  const TSidebar({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      shape: const BeveledRectangleBorder(),
      child: Container(
        color: TColors.primary,
        child: SingleChildScrollView(
          child: Column(
            children: [
              const SizedBox(height: TSizes.spaceBtwSections),
              const TCircularImage(width: 100, height: 100, image: TImages.appLogo, padding: 0, backgroundColor: Colors.transparent),
              const SizedBox(height: TSizes.spaceBtwSections),
              Column(
                mainAxisSize: MainAxisSize.min,
                children: TRoutes.sideMenuItems.map((itemName) => TMenuItem(itemName: itemName)).toList(),
              )
            ],
          ),
        ),
      ),
    );
  }
}
