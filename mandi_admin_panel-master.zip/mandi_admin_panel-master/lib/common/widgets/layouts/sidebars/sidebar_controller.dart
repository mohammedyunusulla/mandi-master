import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:iconsax/iconsax.dart';
import '../../../../data/repositories/authentication/authentication_repository.dart';
import '../../../../routes/routes.dart';
import '../../../../utils/constants/colors.dart';
import '../../../../utils/device/device_utility.dart';
import '../../../../utils/popups/loaders.dart';

class SidebarController extends GetxController {
  static SidebarController instance = Get.find();

  final activeItem = TRoutes.users.obs;
  final hoverItem = ''.obs;

  changeActiveItem(String itemName) => activeItem.value = itemName;

  changeHoverItem(String itemName) {
    if (!isActive(itemName)) hoverItem.value = itemName;
  }

  isActive(String itemName) => activeItem.value == itemName;

  isHovering(String itemName) => hoverItem.value == itemName;

  menuOnTap(itemName) async {
    try {
      if (!isActive(itemName)) {
        // Update Selected Menu Item
        changeActiveItem(itemName);

        // If Menu Drawer opened in Mobile Close it
        if (TDeviceUtils.isMobileScreen(Get.context!)) Get.back();

        // Navigate to other screen OR Logout
        if (itemName == 'logout') {
          await AuthenticationRepository.instance.logout();
        } else {
          Get.toNamed(itemName);
        }
      }
    } catch (e) {
      TLoaders.errorSnackBar(title: 'Error', message: e.toString());
    }
  }

  returnItemName(String itemName) {
    switch (itemName) {
      // case TRoutes.dashboard:
      //   return 'Dashboard';
      case TRoutes.users:
        return 'Users';
      case TRoutes.profile:
        return 'Profile';
      default:
        return 'Logout';
    }
  }

  returnIcon(String itemName) {
    switch (itemName) {
      // case TRoutes.dashboard:
      //   return _customIcon(Icons.dashboard, itemName);
      case TRoutes.users:
        return _customIcon(Iconsax.user, itemName);
      case TRoutes.profile:
        return _customIcon(Iconsax.subtitle, itemName);
      default:
        return _customIcon(Iconsax.logout, itemName);
    }
  }

  Widget _customIcon(IconData icon, String itemName) {
    if (isActive(itemName)) return Icon(icon, size: 22, color: TColors.white);
    return Icon(icon, size: 22, color: isHovering(itemName) ? TColors.white : TColors.lightGrey);
  }
}

