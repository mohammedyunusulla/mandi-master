import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mandi_admin_panel/common/widgets/texts/page_heading.dart';
import 'package:mandi_admin_panel/utils/constants/colors.dart';

class TBreadcrumbsWithHeading extends StatelessWidget {
  const TBreadcrumbsWithHeading({super.key, required this.breadcrumbItems, required this.heading});

  final String heading;
  final List<String> breadcrumbItems;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Row(
          children: [
            TPageHeading(heading: heading),
            const SizedBox(width: 20, child: Divider(thickness: 20, color: TColors.black, indent: 11, endIndent: 8)),
            // InkWell(
            //   onTap: () => Get.offAllNamed(TRoutes.dashboard),
            //   child: Padding(
            //     padding: const EdgeInsets.symmetric(horizontal: 4.0),
            //     child: Icon(Iconsax.home, color: TColors.black.withOpacity(0.6), size: TSizes.iconSm),
            //   ),
            // ),
          ],
        ),
        for (int i = 0; i < breadcrumbItems.length; i++)
          Row(
            children: [
              // const Text('-'),
              InkWell(
                onTap: () => Get.offNamed(breadcrumbItems[i]),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4.0),
                  child: Text(
                    i == breadcrumbItems.length - 1
                        ? breadcrumbItems[i].capitalize.toString()
                        : capitalize(breadcrumbItems[i].substring(1)),
                    style: const TextStyle(fontWeight: FontWeight.w300),
                  ),
                ),
              ),
            ],
          ),
      ],
    );
  }

  // Function to capitalize the first letter of a string
  String capitalize(String s) {
    return s.isEmpty ? '' : s[0].toUpperCase() + s.substring(1);
  }
}
