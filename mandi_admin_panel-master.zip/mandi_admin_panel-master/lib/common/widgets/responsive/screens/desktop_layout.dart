import 'package:flutter/material.dart';
import '../../layouts/headers/header.dart';
import '../../layouts/sidebars/sidebar.dart';

class DesktopLayout extends StatelessWidget {
  DesktopLayout({super.key, this.body});

  final Widget? body;
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      body: Row(
        children: [
          const Expanded(child: TSidebar()),
          Expanded(
            flex: 5,

            /// Desktop Body
            child: Column(
              children: [
                THeader(scaffoldKey: scaffoldKey),
                Expanded(child: body ?? Container()),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
