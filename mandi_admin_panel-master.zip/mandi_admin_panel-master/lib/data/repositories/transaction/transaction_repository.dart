import 'dart:html' as html;
import 'dart:io';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:image_picker/image_picker.dart';
import '../../../src/models/transactions/transaction_model.dart';
import '../../../utils/exceptions/firebase_auth_exceptions.dart';
import '../../../utils/exceptions/format_exceptions.dart';
import '../../../utils/exceptions/platform_exceptions.dart';

/// Repository class for transaction-related operations.
class TransactionRepository extends GetxController {
  static TransactionRepository get instance => Get.find();

  final _db = FirebaseFirestore.instance;
  final _firebaseStorage = FirebaseStorage.instance;

  /// Function to save transaction data to Firestore.
  Future<void> createTransaction(TransactionModel transaction) async {
    try {
      await _db.collection("Transactions").doc().set(transaction.toJson());
    } on FirebaseAuthException catch (e) {
      throw TFirebaseAuthException(e.code).message;
    } on FormatException catch (_) {
      throw const TFormatException();
    } on PlatformException catch (e) {
      throw TPlatformException(e.code).message;
    } catch (e) {
      throw 'Something went wrong. Please try again';
    }
  }

  /// Function to fetch transaction details based on User ID.
  Future<List<TransactionModel>> fetchAllTransactions(String userId) async {
    try {
      final querySnapshot = await _db.collection("Transactions").where('userId', isEqualTo: userId).orderBy('createdAt', descending: true).get();
      return querySnapshot.docs.map((doc) => TransactionModel.fromSnapshot(doc)).toList();
    } on FirebaseAuthException catch (e) {
      throw TFirebaseAuthException(e.code).message;
    } on FormatException catch (_) {
      throw const TFormatException();
    } on PlatformException catch (e) {
      throw TPlatformException(e.code).message;
    } catch (e) {
      if (kDebugMode) print('Something Went Wrong: $e');
      throw 'Something Went Wrong: $e';
    }
  }

  /// Function to fetch transaction details based on User ID.
  Future<List<TransactionModel>> fetchAllTransactionsOfClient(String clientId) async {
    try {
      final querySnapshot = await _db.collection("Transactions").where('clientId', isEqualTo: clientId).get();
      return querySnapshot.docs.map((doc) => TransactionModel.fromSnapshot(doc)).toList();
    } on FirebaseAuthException catch (e) {
      throw TFirebaseAuthException(e.code).message;
    } on FormatException catch (_) {
      throw const TFormatException();
    } on PlatformException catch (e) {
      throw TPlatformException(e.code).message;
    } catch (e) {
      if (kDebugMode) print('Something Went Wrong: $e');
      throw 'Something Went Wrong: $e';
    }
  }

  /// Function to fetch transaction details based on transaction ID.
  Future<TransactionModel> fetchTransactionDetails() async {
    try {
      final documentSnapshot = await _db.collection("Transactions").doc().get();
      if (documentSnapshot.exists) {
        return TransactionModel.fromSnapshot(documentSnapshot);
      } else {
        return TransactionModel.empty();
      }
    } on FirebaseAuthException catch (e) {
      throw TFirebaseAuthException(e.code).message;
    } on FormatException catch (_) {
      throw const TFormatException();
    } on PlatformException catch (e) {
      throw TPlatformException(e.code).message;
    } catch (e) {
      if (kDebugMode) print('Something Went Wrong: $e');
      throw 'Something Went Wrong: $e';
    }
  }

  /// Function to update transaction data in Firestore.
  Future<void> updateTransaction(TransactionModel updatedTransaction) async {
    try {
      await _db.collection("Transactions").doc(updatedTransaction.id).update(updatedTransaction.toJson());
    } on FirebaseAuthException catch (e) {
      throw TFirebaseAuthException(e.code).message;
    } on FormatException catch (_) {
      throw const TFormatException();
    } on PlatformException catch (e) {
      throw TPlatformException(e.code).message;
    } catch (e) {
      throw 'Something went wrong. Please try again';
    }
  }

  /// Update any field in specific Transactions Collection
  Future<void> updateSingleField(String docId, Map<String, dynamic> json) async {
    try {
      await _db.collection("Transactions").doc(docId).update(json);
    } on FirebaseAuthException catch (e) {
      throw TFirebaseAuthException(e.code).message;
    } on FormatException catch (_) {
      throw const TFormatException();
    } on PlatformException catch (e) {
      throw TPlatformException(e.code).message;
    } catch (e) {
      throw 'Something went wrong. Please try again';
    }
  }

  /// Upload any Image
  Future<String> uploadImage(String path, XFile image) async {
    try {
      final ref = _firebaseStorage.ref(path).child(image.name);
      await ref.putFile(File(image.path));
      final url = await ref.getDownloadURL();
      return url;
    } on FirebaseException catch (e) {
      throw e.message!;
    } on SocketException catch (e) {
      throw e.message;
    } on PlatformException catch (e) {
      throw e.message!;
    } catch (e) {
      throw 'Something went wrong. Please try again';
    }
  }

  /// Upload any Image
  Future<String> uploadImageUInt8List(html.File file, String path, String imageName) async {
    try {
      final ref = _firebaseStorage.ref(path).child(imageName);
      await ref.putBlob(file);

      final String downloadURL = await ref.getDownloadURL();

      // Return the download URL
      return downloadURL;
    } on FirebaseException catch (e) {
      throw e.message!;
    } on SocketException catch (e) {
      throw e.message;
    } on PlatformException catch (e) {
      throw e.message!;
    } catch (e) {
      throw e.toString();
    }
  }

  /// Function to remove transaction data from Firestore.
  Future<void> removeTransactionRecord(String transactionId) async {
    try {
      await _db.collection("Transactions").doc(transactionId).delete();
    } on FirebaseAuthException catch (e) {
      throw TFirebaseAuthException(e.code).message;
    } on FormatException catch (_) {
      throw const TFormatException();
    } on PlatformException catch (e) {
      throw TPlatformException(e.code).message;
    } catch (e) {
      throw 'Something went wrong. Please try again';
    }
  }
}
