import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mandi_admin_panel/data/repositories/transaction/transaction_repository.dart';
import 'package:mandi_admin_panel/src/models/users/user_model.dart';
import '../../../utils/popups/loaders.dart';
import '../../models/transactions/transaction_model.dart';

class TransactionController extends GetxController {
  TransactionController(this.user);
  static TransactionController get instance => Get.find();

  UserModel user;
  int perPage = 10;
  RxBool loading = false.obs;
  RxInt sortColumnIndex = 1.obs;
  RxBool headerCheckbox = false.obs;
  RxList<bool> selectedRows = <bool>[].obs;
  final searchTextController = TextEditingController();
  final transactionRepository = Get.put(TransactionRepository());
  RxList<TransactionModel> transactions = <TransactionModel>[].obs;
  RxList<TransactionModel> filteredTransactions = <TransactionModel>[].obs;

  @override
  void onInit() {
    loadData();
    super.onInit();
  }

  Future<void> loadData() async {
    try {
      loading.value = true;
      final List<TransactionModel> newData = await transactionRepository.fetchAllTransactions(user.id!);
      transactions.assignAll(newData);
      filteredTransactions.assignAll(transactions);
      selectedRows.assignAll(List.generate(transactions.length, (index) => false));

      update();
    } catch (e) {
      TLoaders.errorSnackBar(title: 'Something went wrong.', message: e.toString());
    } finally {
      loading.value = false;
    }
  }

  void handleSearchQueryChange() {
    final query = searchTextController.text.toLowerCase();

    // Update filteredTransactions based on the search query
    filteredTransactions.assignAll(transactions.where((transaction) =>
        transaction.clientName.toLowerCase().contains(query) ||
        transaction.category.toLowerCase().contains(query) ||
        transaction.paymentRemarks.toLowerCase().contains(query)));

    // Notify listeners about the change
    update();
  }

  void toggleSelectAll(bool selectAll) {
    selectedRows.assignAll(List.generate(selectedRows.length, (_) => selectAll));
    headerCheckbox.value = selectAll;
    update();
  }

  void updateHeaderCheckbox() {
    // Check if all row checkboxes are selected, excluding the header checkbox
    bool allSelected = selectedRows.every((value) => value);

    // Update header checkbox accordingly
    headerCheckbox.value = allSelected;
    update();
  }

  void toggleSelectTransaction(int index) {
    selectedRows[index] = !selectedRows[index];
    updateHeaderCheckbox();
    update();
  }

  // Sorting related code
  void sortByQuantity(int sortColumnIndex, bool ascending) {
    // Assuming you have a createdAt field in your TransactionModel
    filteredTransactions.sort((a, b) {
      if (ascending) {
        return a.quantity.compareTo(b.quantity);
      } else {
        return b.quantity.compareTo(a.quantity);
      }
    });
    this.sortColumnIndex.value = sortColumnIndex;

    update();
  }

  // Sorting related code
  void sortByTotalPrice(int sortColumnIndex, bool ascending) {
    // Assuming you have a createdAt field in your TransactionModel
    filteredTransactions.sort((a, b) {
      if (ascending) {
        return a.totalPrice.compareTo(b.totalPrice);
      } else {
        return b.totalPrice.compareTo(a.totalPrice);
      }
    });
    this.sortColumnIndex.value = sortColumnIndex;

    update();
  }

  // Sorting related code
  void sortByDate(int sortColumnIndex, bool ascending) {
    // Assuming you have a createdAt field in your TransactionModel
    filteredTransactions.sort((a, b) {
      if (ascending) {
        return a.createdAt!.compareTo(b.createdAt!);
      } else {
        return b.createdAt!.compareTo(a.createdAt!);
      }
    });
    this.sortColumnIndex.value = sortColumnIndex;

    update();
  }
}
