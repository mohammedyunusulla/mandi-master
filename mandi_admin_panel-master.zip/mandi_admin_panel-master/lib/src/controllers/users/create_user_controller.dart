import 'dart:html' as html;
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mandi_admin_panel/data/repositories/authentication/authentication_repository.dart';

import '../../../../data/repositories/user/user_repository.dart';
import '../../../utils/constants/enums.dart';
import '../../../utils/helpers/network_manager.dart';
import '../../../utils/popups/loaders.dart';
import '../../models/users/user_model.dart';

class CreateUserController extends GetxController {
  static CreateUserController get instance => Get.find();

  RxBool loading = false.obs;

  Rx<AppRole> selectedRole = AppRole.user.obs;
  RxBool active = true.obs;
  final formKey = GlobalKey<FormState>();
  final name = TextEditingController();
  final email = TextEditingController();
  final password = TextEditingController();
  final phoneNumber = TextEditingController();
  final address = TextEditingController();
  Rx<html.File?> selectedImage = Rx<html.File?>(null);
  Rx<Uint8List?> selectedRInt8ListImage = Rx<Uint8List?>(null);


  void changeRole(AppRole newValue) {
    selectedRole.value = newValue;
  }

  Future<void> pickImage() async {
    final imageInput = html.FileUploadInputElement()..accept = 'image/*';
    imageInput.click();

    imageInput.onChange.listen((event) {
      final file = imageInput.files!.first;
      final reader = html.FileReader();
      reader.readAsArrayBuffer(file);

      reader.onLoadEnd.listen((event) {
        selectedImage.value = file;
        selectedRInt8ListImage.value = Uint8List.fromList(reader.result as List<int>);
      });
    });
  }

  Future<void> registerNewUser() async {
    try {
      // Start Loading
      loading.value = true;

      // Check Internet Connectivity
      final isConnected = await NetworkManager.instance.isConnected();
      if (!isConnected) {
        loading.value = false;
        return;
      }

      // Form Validation
      if (!formKey.currentState!.validate()) {
        loading.value = false;
        return;
      }

      // Store User in Authentication
      final user = await AuthenticationRepository.instance.registerUserByAdmin(email.text.trim(), password.text.trim());

      // Save user Image If uploaded
      String imageURL = '';
      if (selectedImage.value != null) {
        imageURL = await UserRepository.instance.uploadImageUInt8List(
          selectedImage.value!,
          'Users/${AuthenticationRepository.instance.authUser!.uid}/images',
          'user-profile-image',
        );
      }

      // Map Data
      final newUser = UserModel(
        id: user.user!.uid,
        name: name.text.trim(),
        email: email.text.trim(),
        phoneNumber: phoneNumber.text.trim(),
        address: address.text.trim(),
        createdAt: DateTime.now(),
        profilePicture: imageURL,
        role: selectedRole.value,
        active: active.value,
      );

      // Call Repository to Create New User
      await UserRepository.instance.createUser(newUser);

      // Remove Loader
      loading.value = false;

      // Success Message & Redirect
      TLoaders.successSnackBar(title: 'Congratulations', message: 'New user has been created!');

      // Redirect
      Get.back();
    } catch (e) {
      loading.value = false;
      TLoaders.errorSnackBar(title: 'Oh Snap', message: e.toString());
    }
  }
}
