import 'dart:html' as html;
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../data/repositories/user/user_repository.dart';
import '../../../data/repositories/authentication/authentication_repository.dart';
import '../../../utils/helpers/network_manager.dart';
import '../../../utils/popups/loaders.dart';
import '../../models/users/user_model.dart';

class AdminController extends GetxController {
  static AdminController get instance => Get.find();

  RxBool loading = false.obs;
  Rx<UserModel> user = UserModel.empty().obs;
  final userRepository = Get.put(UserRepository());

  final formKey = GlobalKey<FormState>();
  final name = TextEditingController();
  final email = TextEditingController();
  final password = TextEditingController();
  final phoneNumber = TextEditingController();
  final address = TextEditingController();
  RxString selectedImage = ''.obs;
  Rx<html.File?> browserImage = Rx<html.File?>(null);
  Rx<Uint8List?> selectedRInt8ListImage = Rx<Uint8List?>(null);


  @override
  void onInit() {
    fetchUserDetails();
    super.onInit();
  }

  Future<UserModel> fetchUserDetails() async {
    try {
      loading.value = true;
      final user = await userRepository.fetchUserDetails();
      this.user.value = user;
      loading.value = false;
      return user;
    } catch (e) {
      loading.value = false;
      TLoaders.errorSnackBar(title: 'Something went wrong.', message: e.toString());
      return UserModel.empty();
    }
  }

  Future<UserModel> getUserDetails() async {
    try {
      final user = await userRepository.fetchUserDetails();
      this.user.value = user;
      return user;
    } catch (e) {
      TLoaders.errorSnackBar(title: 'Something went wrong.', message: e.toString());
      return UserModel.empty();
    }
  }



  void initFields(UserModel userModel) {
    selectedImage.value = userModel.profilePicture;
    name.text = userModel.name;
    email.text = userModel.email;
    phoneNumber.text = userModel.phoneNumber;
    address.text = userModel.address;
  }

  Future<void> pickImage() async {
    final imageInput = html.FileUploadInputElement()..accept = 'image/*';
    imageInput.click();

    imageInput.onChange.listen((event) {
      final file = imageInput.files!.first;
      final reader = html.FileReader();
      reader.readAsArrayBuffer(file);

      reader.onLoadEnd.listen((event) {
        browserImage.value = file;
        selectedRInt8ListImage.value = Uint8List.fromList(reader.result as List<int>);
      });
    });
  }

  Future<void> updateData() async {
    try {
      final user = this.user.value;
      if(user.id!.isEmpty) return;

      // Start Loading
      loading.value = true;

      // Check Internet Connectivity
      final isConnected = await NetworkManager.instance.isConnected();
      if (!isConnected) {
        loading.value = false;
        return;
      }

      // Form Validation
      if (!formKey.currentState!.validate()) {
        loading.value = false;
        return;
      }

      // Save user Image If uploaded
      if (browserImage.value != null) {
        user.profilePicture = await UserRepository.instance.uploadImageUInt8List(
          browserImage.value!,
          'Users/${AuthenticationRepository.instance.authUser!.uid}/images',
          'user-profile-image',
        );
      }

      // Map Data
      user.name = name.text.trim();
      user.email = email.text.trim();
      user.phoneNumber = phoneNumber.text.trim();
      user.address = address.text.trim();
      user.updatedAt = DateTime.now();

      // Call Repository to Create New User
      await UserRepository.instance.updateUserDetails(user);

      // Initialize User
      await fetchUserDetails();

      // Remove Loader
      loading.value = false;

      // Success Message & Redirect
      TLoaders.successSnackBar(title: 'Success', message: 'Your record has been updated');
    } catch (e) {
      loading.value = false;
      TLoaders.errorSnackBar(title: 'Oh Snap', message: e.toString());
    }
  }
}