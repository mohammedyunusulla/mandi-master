import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mandi_admin_panel/data/repositories/client/client_repository.dart';
import 'package:mandi_admin_panel/src/models/users/user_model.dart';
import '../../../utils/popups/loaders.dart';
import '../../models/clients/client_model.dart';

class ClientController extends GetxController {
  ClientController(this.user);
  static ClientController get instance => Get.find();

  UserModel user;
  int perPage = 10;
  RxBool loading = false.obs;
  RxInt sortColumnIndex = 1.obs;
  RxBool headerCheckbox = false.obs;
  RxList<bool> selectedRows = <bool>[].obs;
  final searchTextController = TextEditingController();
  final clientRepository = Get.put(ClientRepository());
  RxList<ClientModel> clients = <ClientModel>[].obs;
  RxList<ClientModel> filteredClients = <ClientModel>[].obs;

  @override
  void onInit() {
    loadData();
    super.onInit();
  }

  Future<void> loadData() async {
    try {
      loading.value = true;
      final List<ClientModel> newData = await clientRepository.fetchAllClients(user.id!);
      clients.assignAll(newData);
      filteredClients.assignAll(clients);
      selectedRows.assignAll(List.generate(clients.length, (index) => false));

      update();
    } catch (e) {
      TLoaders.errorSnackBar(title: 'Something went wrong.', message: e.toString());
    } finally {
      loading.value = false;
    }
  }

  void handleSearchQueryChange() {
    final query = searchTextController.text.toLowerCase();

    // Update filteredClients based on the search query
    filteredClients.assignAll(clients.where((client) =>
        client.name.toLowerCase().contains(query) ||
        client.email.toLowerCase().contains(query)));

    // Notify listeners about the change
    update();
  }

  void toggleSelectAll(bool selectAll) {
    selectedRows.assignAll(List.generate(selectedRows.length, (_) => selectAll));
    headerCheckbox.value = selectAll;
    update();
  }

  void updateHeaderCheckbox() {
    // Check if all row checkboxes are selected, excluding the header checkbox
    bool allSelected = selectedRows.every((value) => value);

    // Update header checkbox accordingly
    headerCheckbox.value = allSelected;
    update();
  }

  void toggleSelectClient(int index) {
    selectedRows[index] = !selectedRows[index];
    updateHeaderCheckbox();
    update();
  }

  // Sorting related code
  void sortByName(int sortColumnIndex, bool ascending) {
    // Assuming you have a createdAt field in your ClientModel
    filteredClients.sort((a, b) {
      if (ascending) {
        return a.name.toLowerCase().compareTo(b.name.toLowerCase());
      } else {
        return b.name.toLowerCase().compareTo(a.name.toLowerCase());
      }
    });
    this.sortColumnIndex.value = sortColumnIndex;

    update();
  }

  // Sorting related code
  void sortByDate(int sortColumnIndex, bool ascending) {
    // Assuming you have a createdAt field in your ClientModel
    filteredClients.sort((a, b) {
      if (ascending) {
        return a.createdAt!.compareTo(b.createdAt!);
      } else {
        return b.createdAt!.compareTo(a.createdAt!);
      }
    });
    this.sortColumnIndex.value = sortColumnIndex;

    update();
  }
}
