import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mandi_admin_panel/utils/constants/image_strings.dart';

import '../../../../data/repositories/user/user_repository.dart';
import '../../../utils/constants/sizes.dart';
import '../../../utils/helpers/cloud_helper_functions.dart';
import '../../../utils/popups/full_screen_loader.dart';
import '../../../utils/popups/loaders.dart';
import '../../models/users/user_model.dart';

class UserController extends GetxController {
  static UserController get instance => Get.find();

  int usersPerPage = 10;
  RxBool loading = false.obs;
  RxBool headerCheckbox = false.obs;
  RxList<bool> selectedRows = <bool>[].obs;
  RxList<UserModel> users = <UserModel>[].obs;
  final userRepository = Get.put(UserRepository());

  final searchTextController = TextEditingController();
  RxList<UserModel> filteredUsers = <UserModel>[].obs;
  RxInt sortColumnIndex = 1.obs;

  @override
  void onInit() {
    loadData();
    super.onInit();
  }

  Future<void> loadData() async {
    try {
      loading.value = true;
      final List<UserModel> newData = await userRepository.fetchAllUsers();
      users.assignAll(newData);
      filteredUsers.assignAll(users);
      selectedRows.assignAll(List.generate(users.length, (index) => false));

      update();
    } catch (e) {
      TLoaders.errorSnackBar(title: 'Something went wrong.', message: e.toString());
    } finally {
      loading.value = false;
    }
  }

  void handleSearchQueryChange() {
    final query = searchTextController.text.toLowerCase();

    // Update filteredUsers based on the search query
    filteredUsers.assignAll(users.where((user) => user.name.toLowerCase().contains(query) || user.email.toLowerCase().contains(query)));

    // Notify listeners about the change
    update();
  }

  void toggleSelectAll(bool selectAll) {
    selectedRows.assignAll(List.generate(selectedRows.length, (_) => selectAll));
    headerCheckbox.value = selectAll;
    update();
  }

  void updateHeaderCheckbox() {
    // Check if all row checkboxes are selected, excluding the header checkbox
    bool allSelected = selectedRows.every((value) => value);

    // Update header checkbox accordingly
    headerCheckbox.value = allSelected;
    update();
  }

  void toggleSelectUser(int index) {
    selectedRows[index] = !selectedRows[index];
    updateHeaderCheckbox();
    update();
  }

  // Sorting related code
  void sortByName(int sortColumnIndex, bool ascending) {
    // Assuming you have a createdAt field in your UserModel
    filteredUsers.sort((a, b) {
      if (ascending) {
        return a.name.toLowerCase().compareTo(b.name.toLowerCase());
      } else {
        return b.name.toLowerCase().compareTo(a.name.toLowerCase());
      }
    });
    this.sortColumnIndex.value = sortColumnIndex;

    update();
  }

  // Sorting related code
  void sortByDate(int sortColumnIndex, bool ascending) {
    // Assuming you have a createdAt field in your UserModel
    filteredUsers.sort((a, b) {
      if (ascending) {
        return a.createdAt!.compareTo(b.createdAt!);
      } else {
        return b.createdAt!.compareTo(a.createdAt!);
      }
    });
    this.sortColumnIndex.value = sortColumnIndex;

    update();
  }

  /// -- Load selected category data
  void confirmOnDelete(UserModel user) async {
    Get.defaultDialog(
      title: 'Delete User',
      content: const Text('Are you sure, you want to delete this User?'),
      onConfirm: () => deleteUser(user),
      confirm: SizedBox(
        width: 60,
        child: ElevatedButton(
          onPressed: () => deleteUser(user),
          style: OutlinedButton.styleFrom(
            padding: const EdgeInsets.symmetric(vertical: TSizes.buttonHeight / 2),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(TSizes.buttonRadius * 5)),
          ),
          child: const Text('Ok'),
        ),
      ),
      cancel: SizedBox(
        width: 80,
        child: OutlinedButton(
          onPressed: () => Get.back(),
          style: OutlinedButton.styleFrom(
            padding: const EdgeInsets.symmetric(vertical: TSizes.buttonHeight / 2),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(TSizes.buttonRadius * 5)),
          ),
          child: const Text('Cancel'),
        ),
      ),
    );
  }

  /// -- Load selected category data
  void deleteUser(UserModel user) async {
    try {
      TFullScreenLoader.stopLoading();


      TFullScreenLoader.openLoadingDialog("Deleting User", TImages.docerAnimation);

      // Delete Firestore Data
      await userRepository.deleteUser(user.id!);

      // Delete Firebase Storage Image when the data deleted
      if (user.profilePicture.isNotEmpty) await TCloudHelperFunctions.deleteFileFromStorage(user.profilePicture);

      // Refresh Data
      await loadData();

      update();
      TFullScreenLoader.stopLoading();
      TLoaders.successSnackBar(title: 'Deleted', message: 'User has been Deleted');
      // }
    } catch (e) {
      TFullScreenLoader.stopLoading();
      TLoaders.errorSnackBar(title: 'Oh Snap!', message: e.toString());
    }
  }
}
