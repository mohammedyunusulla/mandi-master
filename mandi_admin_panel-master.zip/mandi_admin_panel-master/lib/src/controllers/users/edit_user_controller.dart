import 'dart:html' as html;
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../data/repositories/user/user_repository.dart';
import '../../../utils/constants/enums.dart';
import '../../../utils/helpers/network_manager.dart';
import '../../../utils/popups/loaders.dart';
import '../../models/users/user_model.dart';

class EditUserController extends GetxController {
  static EditUserController get instance => Get.find();

  RxBool loading = false.obs;

  Rx<AppRole> selectedRole = AppRole.user.obs;
  RxBool active = true.obs;
  final formKey = GlobalKey<FormState>();
  final name = TextEditingController();
  final email = TextEditingController();
  final password = TextEditingController();
  final phoneNumber = TextEditingController();
  final address = TextEditingController();
  RxString selectedImage = ''.obs;
  Rx<html.File?> browserImage = Rx<html.File?>(null);
  Rx<Uint8List?> selectedRInt8ListImage = Rx<Uint8List?>(null);

  void initFields(UserModel user) {
    selectedImage.value = user.profilePicture;
    active.value = user.active;
    selectedRole.value = user.role;
    name.text = user.name;
    name.text = user.name;
    email.text = user.email;
    phoneNumber.text = user.phoneNumber;
    address.text = user.address;
  }

  void changeRole(AppRole newValue) {
    selectedRole.value = newValue;
  }

  Future<void> pickImage() async {
    final imageInput = html.FileUploadInputElement()..accept = 'image/*';
    imageInput.click();

    imageInput.onChange.listen((event) {
      final file = imageInput.files!.first;
      final reader = html.FileReader();
      reader.readAsArrayBuffer(file);

      reader.onLoadEnd.listen((event) {
        browserImage.value = file;
        selectedRInt8ListImage.value = Uint8List.fromList(reader.result as List<int>);
      });
    });
  }

  Future<void> updateUser(UserModel user) async {
    try {
      // Start Loading
      loading.value = true;

      // Check Internet Connectivity
      final isConnected = await NetworkManager.instance.isConnected();
      if (!isConnected) {
        loading.value = false;
        return;
      }

      // Form Validation
      if (!formKey.currentState!.validate()) {
        loading.value = false;
        return;
      }

      // Save user Image If uploaded
      if (browserImage.value != null) {
        user.profilePicture = await UserRepository.instance.uploadImageUInt8List(
          browserImage.value!,
          'Users/${user.id}/images',
          'user-profile-image',
        );
      }

      // Map Data
      user.name = name.text.trim();
      user.email = email.text.trim();
      user.phoneNumber = phoneNumber.text.trim();
      user.address = address.text.trim();
      user.updatedAt = DateTime.now();
      user.role = selectedRole.value;
      user.active = active.value;

      // Call Repository to Create New User
      await UserRepository.instance.updateUserDetails(user);

      // Remove Loader
      loading.value = false;

      // Success Message & Redirect
      TLoaders.successSnackBar(title: 'Success', message: 'User record has been updated');
    } catch (e) {
      loading.value = false;
      TLoaders.errorSnackBar(title: 'Oh Snap', message: e.toString());
    }
  }
}
