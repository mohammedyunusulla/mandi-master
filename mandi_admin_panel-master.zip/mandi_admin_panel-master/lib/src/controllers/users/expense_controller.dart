import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mandi_admin_panel/data/repositories/expense/expense_repository.dart';
import 'package:mandi_admin_panel/src/models/users/user_model.dart';
import '../../../utils/popups/loaders.dart';
import '../../models/expenses/expense_model.dart';

class ExpenseController extends GetxController {
  ExpenseController(this.user);

  static ExpenseController get instance => Get.find();

  UserModel user;
  int perPage = 10;
  RxBool loading = false.obs;
  RxInt sortColumnIndex = 1.obs;
  RxBool headerCheckbox = false.obs;
  RxList<bool> selectedRows = <bool>[].obs;
  final searchTextController = TextEditingController();
  final expenseRepository = Get.put(ExpenseRepository());
  RxList<ExpenseModel> expenses = <ExpenseModel>[].obs;
  RxList<ExpenseModel> filteredExpenses = <ExpenseModel>[].obs;

  @override
  void onInit() {
    loadData();
    super.onInit();
  }

  Future<void> loadData() async {
    try {
      loading.value = true;
      final List<ExpenseModel> newData = await expenseRepository.fetchAllExpenses(user.id!);
      expenses.assignAll(newData);
      filteredExpenses.assignAll(expenses);
      selectedRows.assignAll(List.generate(expenses.length, (index) => false));

      update();
    } catch (e) {
      TLoaders.errorSnackBar(title: 'Something went wrong.', message: e.toString());
    } finally {
      loading.value = false;
    }
  }

  void handleSearchQueryChange() {
    final query = searchTextController.text.toLowerCase();

    // Update filteredExpenses based on the search query
    filteredExpenses
        .assignAll(expenses.where((expense) => expense.name.toLowerCase().contains(query) || expense.amount.toString().contains(query)));

    // Notify listeners about the change
    update();
  }

  void toggleSelectAll(bool selectAll) {
    selectedRows.assignAll(List.generate(selectedRows.length, (_) => selectAll));
    headerCheckbox.value = selectAll;
    update();
  }

  void updateHeaderCheckbox() {
    // Check if all row checkboxes are selected, excluding the header checkbox
    bool allSelected = selectedRows.every((value) => value);

    // Update header checkbox accordingly
    headerCheckbox.value = allSelected;
    update();
  }

  void toggleSelectExpense(int index) {
    selectedRows[index] = !selectedRows[index];
    updateHeaderCheckbox();
    update();
  }

  // Sorting related code
  void sortByName(int sortColumnIndex, bool ascending) {
    // Assuming you have a createdAt field in your ExpenseModel
    filteredExpenses.sort((a, b) {
      if (ascending) {
        return a.name.toLowerCase().compareTo(b.name.toLowerCase());
      } else {
        return b.name.toLowerCase().compareTo(a.name.toLowerCase());
      }
    });
    this.sortColumnIndex.value = sortColumnIndex;

    update();
  }

  // Sorting related code
  void sortByAmount(int sortColumnIndex, bool ascending) {
    // Assuming you have a createdAt field in your ExpenseModel
    filteredExpenses.sort((a, b) {
      if (ascending) {
        return a.amount.compareTo(b.amount);
      } else {
        return b.amount.compareTo(a.amount);
      }
    });
    this.sortColumnIndex.value = sortColumnIndex;

    update();
  }

  // Sorting related code
  void sortByDate(int sortColumnIndex, bool ascending) {
    // Assuming you have a createdAt field in your ExpenseModel
    filteredExpenses.sort((a, b) {
      if (ascending) {
        return a.createdAt!.compareTo(b.createdAt!);
      } else {
        return b.createdAt!.compareTo(a.createdAt!);
      }
    });
    this.sortColumnIndex.value = sortColumnIndex;

    update();
  }
}
