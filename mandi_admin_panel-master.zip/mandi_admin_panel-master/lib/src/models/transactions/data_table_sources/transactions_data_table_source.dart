import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mandi_admin_panel/common/widgets/custom_shapes/containers/rounded_container.dart';
import 'package:mandi_admin_panel/utils/constants/colors.dart';
import 'package:mandi_admin_panel/utils/constants/enums.dart';
import 'package:mandi_admin_panel/utils/constants/sizes.dart';
import '../../../controllers/users/transaction_controller.dart';

class TransactionsDataTableSource extends DataTableSource {
  final controller = TransactionController.instance;

  @override
  DataRow? getRow(int index) {
    if (index >= controller.filteredTransactions.length) return null;

    final transaction = controller.filteredTransactions[index];
    final isBuy = transaction.transactionType == TransactionType.buy;

    return DataRow(
      onSelectChanged: (value) {},
      cells: [
        DataCell(Text(transaction.formattedCreatedAtDate)),
        DataCell(
          TRoundedContainer(
            padding: const EdgeInsets.symmetric(horizontal: TSizes.md, vertical: TSizes.xs),
            backgroundColor: isBuy ? TColors.error.withOpacity(0.1) : TColors.info.withOpacity(0.1),
            child: Text(
              isBuy ? 'Buy' : 'Sell',
              style: Theme.of(Get.context!).textTheme.labelLarge!.apply(color: isBuy ? TColors.error : TColors.info, fontWeightDelta: 2),
            ),
          ),
        ),
        DataCell(Text(transaction.clientName)),
        DataCell(Text(transaction.category)),
        DataCell(Text(transaction.quantity.toString())),
        DataCell(Text(transaction.rate.toString())),
        DataCell(Text(transaction.totalPrice)),
        DataCell(Text(transaction.labor.toString())),
        DataCell(Text(transaction.soldTax)),
      ],
    );
  }

  @override
  bool get isRowCountApproximate => false;

  @override
  int get rowCount => controller.filteredTransactions.length;

  @override
  int get selectedRowCount => TransactionController.instance.selectedRows.where((selected) => selected).length;
}
