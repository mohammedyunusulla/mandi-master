import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../common/widgets/custom_shapes/containers/circular_container.dart';
import '../../../../common/widgets/images/t_circular_image.dart';
import '../../../../routes/routes.dart';
import '../../../../utils/constants/enums.dart';
import '../../../../utils/constants/image_strings.dart';
import '../../../../utils/constants/sizes.dart';
import '../../../controllers/users/user_controller.dart';

class UsersDataTableSource extends DataTableSource {
  final controller = Get.put(UserController());

  @override
  DataRow? getRow(int index) {
    if (index >= controller.filteredUsers.length) return null;

    final user = controller.filteredUsers[index];

    return DataRow(
      // selected: controller.selectedRows[index],
      // onSelectChanged: (value) => controller.toggleSelectUser(index),
      onSelectChanged: (value){},
      cells: [
        // DataCell(
        //   Obx(
        //     () => Checkbox(
        //       value: controller.selectedRows[index],
        //       onChanged: (value) {
        //         controller.toggleSelectUser(index);
        //       },
        //     ),
        //   ),
        // ),
        DataCell(
          TCircularImage(
            width: 40,
            height: 40,
            padding: 2,
            imageType: user.profilePicture.isNotEmpty ? ImageType.network : ImageType.asset,
            image: user.profilePicture.isNotEmpty ? user.profilePicture : TImages.user,
          ),
        ),
        DataCell(Text(user.name)),
        DataCell(Text(user.email)),
        DataCell(Text(user.role.name.capitalize.toString())),
        DataCell(Text(user.phoneNumber)),
        DataCell(Text(user.address)),
        DataCell(Text(user.formattedDate)),
        DataCell(
          Row(
            children: [
              TCircularContainer(width: 12, height: 12, backgroundColor: user.active ? Colors.green : Colors.red),
              const SizedBox(width: TSizes.sm),
              Text(user.active ? 'Active' : 'In Active'),
            ],
          ),
        ),
        DataCell(PopupMenuButton<String>(
          icon: const Icon(Icons.more_vert),
          onSelected: (value) {
            // Handle menu item selection
            switch (value) {
              case 'edit':
                print('Edit selected');
                break;
              case 'clients':
                print('Clients selected');
                break;
              case 'overheads':
                print('Expenses selected');
                break;
              case 'transactions':
                print('Transactions selected');
                break;
            }
          },
          itemBuilder: (BuildContext context) {
            return [
              PopupMenuItem(
                value: 'edit',
                onTap: () => Get.toNamed(TRoutes.editUser, arguments: [user]),
                child: const ListTile(leading: Icon(Icons.edit), title: Text('Edit')),
              ),
              PopupMenuItem(
                value: 'clients',
                onTap: () => Get.toNamed(TRoutes.clients, arguments: [user]),
                child: const ListTile(leading: Icon(Icons.people), title: Text('Clients')),
              ),
              PopupMenuItem(
                value: 'overheads',
                onTap: () => Get.toNamed(TRoutes.expenses, arguments: [user]),
                child: const ListTile(leading: Icon(Icons.track_changes), title: Text('Expenses')),
              ),
              PopupMenuItem(
                value: 'transactions',
                onTap: () => Get.toNamed(TRoutes.transactions, arguments: [user]),
                child: const ListTile(leading: Icon(Icons.account_balance), title: Text('Transactions')),
              ),
              PopupMenuItem(
                value: 'delete',
                onTap: () => UserController.instance.confirmOnDelete(user),
                child: const ListTile(leading: Icon(Icons.delete), title: Text('Delete')),
              ),
            ];
          },
        )),
      ],
    );
  }

  @override
  bool get isRowCountApproximate => false;

  @override
  int get rowCount => controller.filteredUsers.length;

  @override
  int get selectedRowCount => UserController.instance.selectedRows.where((selected) => selected).length;

}
