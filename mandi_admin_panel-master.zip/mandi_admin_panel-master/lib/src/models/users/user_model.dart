import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:mandi_admin_panel/utils/constants/enums.dart';
import '../../../../utils/formatters/formatter.dart';

/// Model class representing user data.
class UserModel {
  final String? id;
  String name;
  String email;
  String phoneNumber;
  String profilePicture;
  String address;
  AppRole role;
  bool active;
  DateTime? createdAt;
  DateTime? updatedAt;

  /// Constructor for UserModel.
  UserModel({
    this.id,
    required this.email,
    this.name = '',
    this.phoneNumber = '',
    this.profilePicture = '',
    this.role = AppRole.user,
    this.active = true,
    this.createdAt,
    this.updatedAt,
    this.address = '',
  });

  /// Helper function to format phone number.
  String get formattedPhoneNo => TFormatter.formatPhoneNumber(phoneNumber);
  String get formattedDate => TFormatter.formatDate(createdAt);
  String get formattedUpdatedAtDate => TFormatter.formatDate(updatedAt);

  /// Static function to create an empty user model.
  static UserModel empty() => UserModel(email: ''); // Default createdAt to current time

  /// Convert model to JSON structure for storing data in Firebase.
  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'email': email,
      'phoneNumber': phoneNumber,
      'profilePicture': profilePicture,
      'role': role.name.toString(),
      'active': active,
      'createdAt': createdAt,
      'updatedAt': updatedAt,
      'address': address,
    };
  }

  /// Factory method to create a UserModel from a Firebase document snapshot.
  factory UserModel.fromSnapshot(DocumentSnapshot<Map<String, dynamic>> document) {
    if (document.data() != null) {
      final data = document.data()!;
      return UserModel(
        id: document.id,
        name: data['name'] ?? '',
        email: data['email'] ?? '',
        phoneNumber: data['phoneNumber'] ?? '',
        profilePicture: data['profilePicture'] ?? '',
        address: data.containsKey('address') ? data['address'] ?? '' : '',
        active: data['active'] ?? false,
        role: (data['role'] ?? AppRole.user) == AppRole.admin.name.toString() ? AppRole.admin : AppRole.user,
        createdAt: data.containsKey('createdAt') ? data['createdAt']?.toDate() ?? DateTime.now() : DateTime.now(), // Convert to DateTime, default to current time if not available
        updatedAt: data.containsKey('updatedAt') ? data['updatedAt']?.toDate() ?? DateTime.now() : DateTime.now(), // Convert to DateTime, default to current time if not available
      );
    } else {
      return empty();
    }
  }
}

