import 'package:flutter/material.dart';
import 'package:mandi_admin_panel/utils/constants/enums.dart';
import '../../../../common/widgets/images/t_circular_image.dart';
import '../../../../utils/constants/image_strings.dart';
import '../../../controllers/users/client_controller.dart';

class ClientsDataTableSource extends DataTableSource {
  final controller = ClientController.instance;

  @override
  DataRow? getRow(int index) {
    if (index >= controller.filteredClients.length) return null;

    final client = controller.filteredClients[index];

    return DataRow(
      onSelectChanged: (value){},
      cells: [
        DataCell(
          TCircularImage(
            width: 40,
            height: 40,
            padding: 2,
            imageType: client.profilePicture.isNotEmpty ? ImageType.network : ImageType.asset,
            image: client.profilePicture.isNotEmpty ? client.profilePicture : TImages.user,
          ),
        ),
        DataCell(Text(client.formattedDate)),
        DataCell(Text(client.name)),
        DataCell(Text(client.email)),
        DataCell(Text(client.phoneNumber)),
        DataCell(Text(client.address)),
      ],
    );
  }

  @override
  bool get isRowCountApproximate => false;

  @override
  int get rowCount => controller.filteredClients.length;

  @override
  int get selectedRowCount => ClientController.instance.selectedRows.where((selected) => selected).length;
}
