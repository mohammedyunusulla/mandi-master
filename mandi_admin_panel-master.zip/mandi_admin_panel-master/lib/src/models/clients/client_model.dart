import 'package:cloud_firestore/cloud_firestore.dart';
import '../../../utils/formatters/formatter.dart';

class ClientModel {
  final String? id;
  String name;
  String email;
  String phoneNumber;
  String profilePicture;
  String address;
  DateTime? createdAt;
  DateTime? updatedAt;

  /// Constructor for ClientModel
  ClientModel({
    this.id,
    this.email = '',
    required this.name,
    this.phoneNumber = '',
    this.profilePicture = '',
    this.createdAt,
    this.updatedAt,
    this.address = '',
  });

  /// Helper function to format phone number.
  String get formattedPhoneNo => TFormatter.formatPhoneNumber(phoneNumber);
  String get formattedDate => TFormatter.formatDate(createdAt);
  String get formattedUpdatedAtDate => TFormatter.formatDate(updatedAt);

  /// Static function to create an empty user model.
  static ClientModel empty() => ClientModel(name: ''); // Default createdAt to current time

  /// Convert model to JSON structure for storing data in Firebase.
  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'email': email,
      'phoneNumber': phoneNumber,
      'profilePicture': profilePicture,
      'createdAt': createdAt,
      'updatedAt': updatedAt,
      'address': address,
    };
  }

  /// Factory method to create a ClientModel from a Firebase document snapshot.
  factory ClientModel.fromSnapshot(DocumentSnapshot<Map<String, dynamic>> document) {
    if (document.data() != null) {
      final data = document.data()!;
      return ClientModel(
        id: document.id,
        name: data['name'] ?? '',
        email: data['email'] ?? '',
        phoneNumber: data['phoneNumber'] ?? '',
        profilePicture: data['profilePicture'] ?? '',
        address: data.containsKey('address') ? data['address'] ?? '' : '',
        createdAt: data.containsKey('createdAt') ? data['createdAt']?.toDate() ?? DateTime.now() : DateTime.now(), // Convert to DateTime, default to current time if not available
        updatedAt: data.containsKey('updatedAt') ? data['updatedAt']?.toDate() ?? DateTime.now() : DateTime.now(), // Convert to DateTime, default to current time if not available
      );
    } else {
      return empty();
    }
  }
}
