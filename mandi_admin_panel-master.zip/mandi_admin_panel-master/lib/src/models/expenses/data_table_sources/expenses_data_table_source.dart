import 'package:flutter/material.dart';
import '../../../controllers/users/expense_controller.dart';

class ExpensesDataTableSource extends DataTableSource {
  final controller = ExpenseController.instance;

  @override
  DataRow? getRow(int index) {
    if (index >= controller.filteredExpenses.length) return null;

    final expense = controller.filteredExpenses[index];

    return DataRow(
      onSelectChanged: (value){},
      cells: [
        DataCell(Text(expense.formattedCreatedAtDate)),
        DataCell(Text(expense.name)),
        DataCell(Text(expense.amount.toString())),
        DataCell(Text(expense.remarks)),
      ],
    );
  }

  @override
  bool get isRowCountApproximate => false;

  @override
  int get rowCount => controller.filteredExpenses.length;

  @override
  int get selectedRowCount => ExpenseController.instance.selectedRows.where((selected) => selected).length;
}
