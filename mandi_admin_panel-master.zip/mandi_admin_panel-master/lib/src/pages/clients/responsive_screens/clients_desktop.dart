import 'package:flutter/material.dart';
import '../../../../../utils/constants/sizes.dart';
import '../../../../common/widgets/breadcrumbs/breadcrumb_with_heading.dart';
import '../../../../routes/routes.dart';
import '../../../models/users/user_model.dart';
import '../widgets/clients_paginated_table.dart';

class ClientsDesktopScreen extends StatelessWidget {
  const ClientsDesktopScreen({super.key, required this.user});

  final UserModel user;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(TSizes.defaultSpace),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const TBreadcrumbsWithHeading(heading: 'Manage Clients', breadcrumbItems: [TRoutes.users, 'All Clients']),
              const SizedBox(height: TSizes.spaceBtwSections),
              ClientsPaginatedDataTable(user: user),
            ],
          ),
        ),
      ),
    );
  }
}