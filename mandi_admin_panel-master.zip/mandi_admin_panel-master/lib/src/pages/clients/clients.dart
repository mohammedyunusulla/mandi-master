import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../common/widgets/layouts/templates/site_layout.dart';
import 'responsive_screens/clients_desktop.dart';
import 'responsive_screens/clients_mobile.dart';

class ClientsScreen extends StatelessWidget {
  const ClientsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    dynamic userInArgument = Get.arguments[0];
    return TSiteTemplate(desktop: ClientsDesktopScreen(user: userInArgument), mobile: ClientsMobileScreen(user: userInArgument));
  }
}