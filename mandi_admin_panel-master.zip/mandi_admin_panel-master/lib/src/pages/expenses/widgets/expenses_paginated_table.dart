import 'package:data_table_2/data_table_2.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:iconsax/iconsax.dart';
import 'package:mandi_admin_panel/common/widgets/images/t_circular_image.dart';
import 'package:mandi_admin_panel/utils/constants/colors.dart';
import 'package:mandi_admin_panel/utils/constants/sizes.dart';
import 'package:mandi_admin_panel/utils/device/device_utility.dart';

import '../../../../../common/widgets/data_table/paginated_data_table.dart';
import '../../../../utils/constants/enums.dart';
import '../../../../utils/constants/image_strings.dart';
import '../../../controllers/users/expense_controller.dart';
import '../../../models/expenses/data_table_sources/expenses_data_table_source.dart';
import '../../../models/users/user_model.dart';

class ExpensesPaginatedDataTable extends StatelessWidget {
  const ExpensesPaginatedDataTable({super.key, required this.user});

  final UserModel user;

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(ExpenseController(user));

    return Obx(
      () => controller.loading.value
          ? const Center(child: CircularProgressIndicator())
          : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                /// Add, Search Bar and Download Button
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: TSizes.spaceBtwItems, horizontal: TSizes.sm),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      /// Download Button
                      Expanded(
                        flex: !TDeviceUtils.isDesktopScreen(context) ? 1 : 3,
                        child: Row(
                          children: [
                            Row(
                              children: [
                                TCircularImage(
                                  width: 40,
                                  height: 40,
                                  padding: 2,
                                  imageType: user.profilePicture.isNotEmpty ? ImageType.network : ImageType.asset,
                                  image: user.profilePicture.isNotEmpty ? user.profilePicture : TImages.user,
                                ),
                                const SizedBox(width: TSizes.sm),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(user.name, style: Theme.of(context).textTheme.labelMedium),
                                    Text(user.email, style: Theme.of(context).textTheme.bodyMedium),
                                  ],
                                ),
                              ],
                            ),
                            // const SizedBox(width: TSizes.spaceBtwItems),
                            // IconButton(onPressed: () {}, icon: const Icon(Iconsax.document_download)),
                          ],
                        ),
                      ),

                      /// Search
                      Expanded(
                        child: TextFormField(
                          controller: controller.searchTextController,
                          onChanged: (value) => controller.handleSearchQueryChange(),
                          decoration: InputDecoration(
                            hintText: 'Search...',
                            prefixIcon: const Icon(Iconsax.search_normal),
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: TColors.darkerGrey.withOpacity(0.6)),
                              borderRadius: BorderRadius.circular(TSizes.cardRadiusMd),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                /// Hidden filteredExpenses to update the UI
                Visibility(visible: false, child: Text('Total Items: ${controller.filteredExpenses.length}')),

                /// Table
                TPaginatedDataTable(
                  sortColumnIndex: controller.sortColumnIndex.value,
                  rowsPerPage: controller.filteredExpenses.length > 10
                      ? 10
                      : controller.filteredExpenses.isEmpty
                          ? 1
                          : controller.filteredExpenses.length,
                  columns: [
                    DataColumn2(
                      label: const Text('Date'),
                      onSort: (columnIndex, ascending) => controller.sortByDate(columnIndex, ascending),
                    ),
                     DataColumn2(label: const Text('Name'),
                      onSort: (columnIndex, ascending) => controller.sortByName(columnIndex, ascending),),
                    DataColumn2(label: const Text('Amount'),
                      onSort: (columnIndex, ascending) => controller.sortByAmount(columnIndex, ascending),),
                    const DataColumn2(label: Text('Remarks')),
                  ],
                  source: ExpensesDataTableSource(),
                  onPageChanged: (int page) {},
                ),
              ],
            ),
    );
  }
}
