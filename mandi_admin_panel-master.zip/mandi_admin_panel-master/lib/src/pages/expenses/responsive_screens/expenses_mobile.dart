import 'package:flutter/material.dart';
import '../../../../../utils/constants/sizes.dart';
import '../../../../common/widgets/breadcrumbs/breadcrumb_with_heading.dart';
import '../../../../routes/routes.dart';
import '../../../models/users/user_model.dart';
import '../widgets/expenses_paginated_table.dart';

class ExpensesMobileScreen extends StatelessWidget {
  const ExpensesMobileScreen({super.key, required this.user});

  final UserModel user;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(TSizes.defaultSpace),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const TBreadcrumbsWithHeading(heading: 'Manage Expenses', breadcrumbItems: [TRoutes.users, 'All Expenses']),
              const SizedBox(height: TSizes.spaceBtwSections),
              ExpensesPaginatedDataTable(user: user),
            ],
          ),
        ),
      ),
    );
  }
}
