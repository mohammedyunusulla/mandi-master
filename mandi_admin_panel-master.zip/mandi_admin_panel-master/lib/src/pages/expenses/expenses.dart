import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../common/widgets/layouts/templates/site_layout.dart';
import 'responsive_screens/expenses_desktop.dart';
import 'responsive_screens/expenses_mobile.dart';

class ExpensesScreen extends StatelessWidget {
  const ExpensesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    dynamic userInArgument = Get.arguments[0];
    return TSiteTemplate(desktop: ExpensesDesktopScreen(user: userInArgument), mobile: ExpensesMobileScreen(user: userInArgument));
  }
}