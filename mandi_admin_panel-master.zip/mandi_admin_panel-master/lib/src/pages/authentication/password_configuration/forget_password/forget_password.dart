import 'package:flutter/material.dart';
import 'package:mandi_admin_panel/src/pages/authentication/password_configuration/forget_password/forget_password_desktop.dart';

import '../../../../../common/widgets/layouts/templates/site_layout.dart';


class ForgetPasswordScreen extends StatelessWidget {
  const ForgetPasswordScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const TSiteTemplate(useLayout: false, desktop: ForgetPasswordDesktopScreen());
  }
}
