import 'package:flutter/material.dart';
import '../../../../common/widgets/layouts/templates/site_layout.dart';
import 'responsive_screens/create_user_desktop.dart';
import 'responsive_screens/create_user_mobile.dart';

class CreateUserScreen extends StatelessWidget {
  const CreateUserScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const TSiteTemplate(desktop: CreateUserDesktopScreen(), mobile: CreateUserMobileScreen());
  }
}