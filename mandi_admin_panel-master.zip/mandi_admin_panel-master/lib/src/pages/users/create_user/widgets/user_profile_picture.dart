import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:iconsax/iconsax.dart';

import '../../../../../common/widgets/icons/t_circular_icon.dart';
import '../../../../../common/widgets/images/t_circular_image.dart';
import '../../../../../utils/constants/colors.dart';
import '../../../../../utils/constants/enums.dart';
import '../../../../../utils/constants/image_strings.dart';
import '../../../../../utils/constants/sizes.dart';
import '../../../../controllers/users/create_user_controller.dart';

class UserProfilePicture extends StatelessWidget {
  const UserProfilePicture({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final userController = CreateUserController.instance;

    return Obx(
      () => Stack(
        children: [
          if (userController.selectedImage.value != null)
            TCircularImage(
              width: 100,
              height: 100,
              fit: BoxFit.contain,
              imageType: ImageType.memory,
              memoryImage: userController.selectedRInt8ListImage.value!,
            )
          else
            const TCircularImage(width: 100, height: 100, imageType: ImageType.asset, image: TImages.user),
          Positioned(
            bottom: 0,
            right: 0,
            child: TCircularIcon(
              size: TSizes.md,
              onPressed: () => userController.pickImage(),
              icon: Iconsax.edit_2,
              color: Colors.white,
              backgroundColor: TColors.primary.withOpacity(0.9),
            ),
          )
        ],
      ),
    );
  }
}
