import 'package:flutter/material.dart';
import 'package:mandi_admin_panel/routes/routes.dart';

import '../../../../../common/widgets/breadcrumbs/breadcrumb_with_heading.dart';
import '../../../../../utils/constants/sizes.dart';
import '../widgets/create_user_form.dart';

class CreateUserMobileScreen extends StatelessWidget {
  const CreateUserMobileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(TSizes.defaultSpace),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const TBreadcrumbsWithHeading(heading: 'Create New User', breadcrumbItems: [TRoutes.users, 'Create User']),
            const SizedBox(height: TSizes.spaceBtwSections),
            Container(
              padding: const EdgeInsets.all(TSizes.defaultSpace),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(TSizes.borderRadiusMd)),
              child: const CreateUserForm(),
            ),
          ],
        ),
      ),
    );
  }
}
