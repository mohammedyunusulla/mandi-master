import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:iconsax/iconsax.dart';

import '../../../../../utils/constants/sizes.dart';
import '../../../../../utils/device/device_utility.dart';
import '../../../../../utils/validators/validation.dart';
import '../../../../controllers/users/edit_user_controller.dart';
import '../../../../models/users/user_model.dart';
import 'user_profile_picture.dart';
import 'user_role_active.dart';

class EditUserForm extends StatelessWidget {
  const EditUserForm({super.key, required this.user});

  final UserModel user;

  @override
  Widget build(BuildContext context) {
    final userController = Get.put(EditUserController());
    userController.initFields(user);
    return Form(
      key: userController.formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // User Profile Picture and Role/Active Widget Section
          _buildProfileSection(context),

          const Divider(),
          const SizedBox(height: TSizes.spaceBtwItems),

          // Email, Password, Name, Phone Number, and Address Fields
          _buildInputFields(context),
          const SizedBox(height: TSizes.spaceBtwInputFields),
          TextFormField(
            controller: userController.address,
            decoration: const InputDecoration(labelText: 'Address', prefixIcon: Icon(Iconsax.location)),
          ),
          const SizedBox(height: TSizes.spaceBtwInputFields * 2),

          // Create Button
          _buildCreateButton(),
        ],
      ),
    );
  }

  // Widget to build the Profile Picture and Role/Active Widget Section
  Widget _buildProfileSection(BuildContext context) {
    return TDeviceUtils.isMobileScreen(context)
        ? const Column(
            children: [
              UserProfilePicture(),
              SizedBox(height: TSizes.spaceBtwSections),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [UserRoleAndActiveWidget()],
              ),
            ],
          )
        : const Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [UserProfilePicture(), UserRoleAndActiveWidget()],
          );
  }

  // Widget to build the Email, Password, Name, Phone Number, and Address Fields
  Widget _buildInputFields(BuildContext context) {
    final userController = EditUserController.instance;
    return TDeviceUtils.isMobileScreen(context)
        ? Column(
            children: [
              _buildTextField(
                controller: userController.email,
                validator: TValidator.validateEmail,
                labelText: '*Email',
                prefixIcon: Iconsax.main_component,
              ),
              const SizedBox(height: TSizes.spaceBtwInputFields),
              _buildTextField(
                controller: userController.name,
                labelText: 'Name',
                prefixIcon: Iconsax.user,
              ),
              const SizedBox(height: TSizes.spaceBtwInputFields),
              _buildTextField(
                controller: userController.phoneNumber,
                labelText: 'Phone Number',
                prefixIcon: Iconsax.mobile,
              ),
            ],
          )
        : Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: _buildTextField(
                      controller: userController.email,
                      validator: TValidator.validateEmail,
                      labelText: '*Email',
                      prefixIcon: Iconsax.main_component,
                    ),
                  ),
                  const SizedBox(width: TSizes.spaceBtwInputFields),
                  Expanded(
                    child: _buildTextField(
                      controller: userController.name,
                      labelText: 'Name',
                      prefixIcon: Iconsax.user,
                    ),
                  ),
                  const SizedBox(width: TSizes.spaceBtwInputFields),
                  Expanded(
                    child: _buildTextField(
                      controller: userController.phoneNumber,
                      labelText: 'Phone Number',
                      prefixIcon: Iconsax.mobile,
                    ),
                  ),
                ],
              ),
            ],
          );
  }

  // Widget to build a TextFormField
  Widget _buildTextField({
    required TextEditingController controller,
    required String labelText,
    IconData? prefixIcon,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      validator: validator,
      decoration: InputDecoration(
        labelText: labelText,
        prefixIcon: prefixIcon != null ? Icon(prefixIcon) : null,
      ),
    );
  }

  // Widget to build the Create Button
  Widget _buildCreateButton() {
    final userController = EditUserController.instance;
    return SizedBox(
      width: double.infinity,
      child: Obx(
        () => ElevatedButton(
          onPressed: userController.loading.value ? null : () => userController.updateUser(user),
          child: userController.loading.value ? const CircularProgressIndicator() : const Text('Update'),
        ),
      ),
    );
  }
}
