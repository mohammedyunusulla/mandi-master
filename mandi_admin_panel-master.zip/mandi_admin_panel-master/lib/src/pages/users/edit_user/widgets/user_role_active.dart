import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../utils/constants/enums.dart';
import '../../../../../utils/constants/sizes.dart';
import '../../../../controllers/users/edit_user_controller.dart';

class UserRoleAndActiveWidget extends StatelessWidget {
  const UserRoleAndActiveWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final userController = EditUserController.instance;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        const Text('User Role'),
        const SizedBox(width: TSizes.spaceBtwItems),
        Obx(
          () => DropdownButton<AppRole>(
            value: userController.selectedRole.value,
            onChanged: (AppRole? newValue) {
              if (newValue != null) {
                userController.changeRole(newValue);
              }
            },
            items: AppRole.values.map((AppRole role) {
              return DropdownMenuItem<AppRole>(
                value: role,
                child: Text(role.toString().split('.').last.capitalize.toString()), // Display the role without the enum class name
              );
            }).toList(),
          ),
        ),
        const SizedBox(width: TSizes.spaceBtwSections),
        Obx(
          () => CheckboxMenuButton(
            value: userController.active.value,
            onChanged: (value) => userController.active.value = value ?? false,
            child: const Text('Active'),
          ),
        ),
      ],
    );
  }
}
