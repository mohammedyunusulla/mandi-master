import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../common/widgets/layouts/templates/site_layout.dart';
import 'responsive_screens/edit_user_desktop.dart';
import 'responsive_screens/edit_user_mobile.dart';

class EditUserScreen extends StatelessWidget {
  const EditUserScreen({super.key});

  @override
  Widget build(BuildContext context) {
    dynamic userInArgument = Get.arguments[0];
    return TSiteTemplate(desktop: EditUserDesktopScreen(user: userInArgument), mobile: EditUserMobileScreen(user: userInArgument));
  }
}