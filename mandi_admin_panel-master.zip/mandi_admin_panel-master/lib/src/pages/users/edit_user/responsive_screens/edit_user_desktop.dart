import 'package:flutter/material.dart';
import 'package:mandi_admin_panel/routes/routes.dart';

import '../../../../../common/widgets/breadcrumbs/breadcrumb_with_heading.dart';
import '../../../../../utils/constants/sizes.dart';
import '../../../../models/users/user_model.dart';
import '../widgets/edit_user_form.dart';

class EditUserDesktopScreen extends StatelessWidget {
  const EditUserDesktopScreen({super.key, required this.user});

  final UserModel user;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(TSizes.defaultSpace),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const TBreadcrumbsWithHeading(heading: 'Edit User', breadcrumbItems: [TRoutes.users, 'Edit User']),
            const SizedBox(height: TSizes.spaceBtwSections),
            Container(
              padding: const EdgeInsets.all(TSizes.defaultSpace),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(TSizes.borderRadiusMd)),
              child: EditUserForm(user: user),
            ),
          ],
        ),
      ),
    );
  }
}
