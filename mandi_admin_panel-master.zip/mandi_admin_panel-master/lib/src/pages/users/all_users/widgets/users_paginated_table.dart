import 'package:data_table_2/data_table_2.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:iconsax/iconsax.dart';
import 'package:mandi_admin_panel/routes/routes.dart';
import 'package:mandi_admin_panel/utils/constants/colors.dart';
import 'package:mandi_admin_panel/utils/constants/sizes.dart';
import 'package:mandi_admin_panel/utils/device/device_utility.dart';

import '../../../../../common/widgets/data_table/paginated_data_table.dart';
import '../../../../controllers/users/user_controller.dart';
import '../../../../models/users/data_table_sources/users_data_table_source.dart';

class UsersPaginatedDataTable extends StatelessWidget {
  UsersPaginatedDataTable({super.key});

  final controller = Get.put(UserController());

  @override
  Widget build(BuildContext context) {
    return Obx(
      () => controller.loading.value
          ? const Center(child: CircularProgressIndicator())
          : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                /// Add, Search Bar and Download Button
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: TSizes.spaceBtwItems, horizontal: TSizes.sm),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      // Add Button
                      Expanded(
                        flex: !TDeviceUtils.isDesktopScreen(context) ? 1 : 3,
                        child: Row(
                          children: [
                            ElevatedButton(
                              onPressed: () => Get.toNamed(TRoutes.createUser),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(horizontal: TSizes.md),
                                child: Row(
                                  children: [
                                    const Icon(Iconsax.add),
                                    Text(' Add', style: Theme.of(context).textTheme.bodyMedium!.apply(color: Colors.white)),
                                  ],
                                ),
                              ),
                            ),
                            // const SizedBox(width: TSizes.spaceBtwItems),

                            // Download Icon Button
                            // IconButton(onPressed: () {}, icon: const Icon(Iconsax.document_download)),
                          ],
                        ),
                      ),

                      // Search
                      Expanded(
                        child: TextFormField(
                          controller: controller.searchTextController,
                          onChanged: (value) => controller.handleSearchQueryChange(),
                          decoration: InputDecoration(
                            hintText: 'Search...',
                            prefixIcon: const Icon(Iconsax.search_normal),
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: TColors.darkerGrey.withOpacity(0.6)),
                              borderRadius: BorderRadius.circular(TSizes.cardRadiusMd),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Visibility(visible: false, child: Text('Total Items: ${controller.filteredUsers.length} ${controller.selectedRows.length}')),
                TPaginatedDataTable(
                  sortColumnIndex: controller.sortColumnIndex.value,
                  columns: [
                    // DataColumn2(
                    //   label: Obx(
                    //     () => Checkbox(
                    //       value: controller.headerCheckbox.value,
                    //       onChanged: (value) {
                    //         controller.toggleSelectAll(value ?? false);
                    //       },
                    //     ),
                    //   ),
                    //   fixedWidth: 60,
                    //   onSort: (columnIndex, ascending) {
                    //     // Handle sorting if needed
                    //   },
                    // ),
                    DataColumn2(
                      label: const Text('Image'),
                      fixedWidth: 90,
                      onSort: (columnIndex, ascending) {},
                    ),
                    DataColumn2(
                      label: const Text('Name'),
                      onSort: (columnIndex, ascending) => controller.sortByName(columnIndex, ascending),
                    ),
                    const DataColumn2(label: Text('Email')),
                    const DataColumn2(label: Text('Role')),
                    const DataColumn2(label: Text('Phone Number')),
                    const DataColumn2(label: Text('Address')),
                    DataColumn2(
                      label: const Text('Created On'),
                      onSort: (columnIndex, ascending) => controller.sortByDate(columnIndex, ascending),
                    ),
                    const DataColumn2(label: Text('Status'), fixedWidth: 100),
                    const DataColumn2(label: SizedBox(), fixedWidth: 50),
                  ],
                  source: UsersDataTableSource(),
                  onPageChanged: (int page) {},
                ),
              ],
            ),
    );
  }
}
