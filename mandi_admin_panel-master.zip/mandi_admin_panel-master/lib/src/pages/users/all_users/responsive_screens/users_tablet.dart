import 'package:flutter/material.dart';
import 'package:mandi_admin_panel/src/pages/users/all_users/widgets/users_paginated_table.dart';

import '../../../../../utils/constants/sizes.dart';

class UsersTabletScreen extends StatelessWidget {
  const UsersTabletScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(child: Padding(padding: const EdgeInsets.all(TSizes.defaultSpace), child: UsersPaginatedDataTable())),
    );
  }
}
