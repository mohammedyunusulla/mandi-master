import 'package:flutter/material.dart';
import '../../../../../common/widgets/breadcrumbs/breadcrumb_with_heading.dart';
import '../../../../../utils/constants/sizes.dart';
import '../widgets/users_paginated_table.dart';

class UsersMobileScreen extends StatelessWidget {
  const UsersMobileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(TSizes.defaultSpace),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const TBreadcrumbsWithHeading(heading: 'Manage Users', breadcrumbItems: ['All Users']),
              const SizedBox(height: TSizes.spaceBtwSections),
              UsersPaginatedDataTable(),
            ],
          ),
        ),
      ),
    );
  }
}
