import 'package:flutter/material.dart';
import 'package:mandi_admin_panel/routes/routes.dart';
import '../../../../../utils/constants/sizes.dart';
import '../../../../common/widgets/breadcrumbs/breadcrumb_with_heading.dart';
import '../../../models/users/user_model.dart';
import '../widgets/transactions_paginated_table.dart';

class TransactionsDesktopScreen extends StatelessWidget {
  const TransactionsDesktopScreen({super.key, required this.user});

  final UserModel user;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(TSizes.defaultSpace),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const TBreadcrumbsWithHeading(heading: 'Manage Transactions', breadcrumbItems: [TRoutes.users, 'All Transactions']),
              const SizedBox(height: TSizes.spaceBtwSections),
              TransactionsPaginatedDataTable(user: user),
            ],
          ),
        ),
      ),
    );
  }
}
