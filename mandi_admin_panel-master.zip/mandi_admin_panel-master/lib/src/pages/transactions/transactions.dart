import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../common/widgets/layouts/templates/site_layout.dart';
import 'responsive_screens/transactions_desktop.dart';
import 'responsive_screens/transactions_mobile.dart';

class TransactionsScreen extends StatelessWidget {
  const TransactionsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    dynamic userInArgument = Get.arguments[0];
    return TSiteTemplate(desktop: TransactionsDesktopScreen(user: userInArgument), mobile: TransactionsMobileScreen(user: userInArgument));
  }
}