import 'package:data_table_2/data_table_2.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:iconsax/iconsax.dart';
import 'package:mandi_admin_panel/common/widgets/images/t_circular_image.dart';
import 'package:mandi_admin_panel/src/models/transactions/data_table_sources/transactions_data_table_source.dart';
import 'package:mandi_admin_panel/utils/constants/colors.dart';
import 'package:mandi_admin_panel/utils/constants/sizes.dart';
import 'package:mandi_admin_panel/utils/device/device_utility.dart';

import '../../../../../common/widgets/data_table/paginated_data_table.dart';
import '../../../../utils/constants/enums.dart';
import '../../../../utils/constants/image_strings.dart';
import '../../../controllers/users/transaction_controller.dart';
import '../../../models/users/user_model.dart';

class TransactionsPaginatedDataTable extends StatelessWidget {
  const TransactionsPaginatedDataTable({super.key, required this.user});

  final UserModel user;

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(TransactionController(user));

    return Obx(
      () => controller.loading.value
          ? const Center(child: CircularProgressIndicator())
          : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                /// Add, Search Bar and Download Button
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: TSizes.spaceBtwItems, horizontal: TSizes.sm),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      /// Download Button
                      Expanded(
                        flex: !TDeviceUtils.isDesktopScreen(context) ? 1 : 3,
                        child: Row(
                          children: [
                            Row(
                              children: [
                                TCircularImage(
                                  width: 40,
                                  height: 40,
                                  padding: 2,
                                  imageType: user.profilePicture.isNotEmpty ? ImageType.network : ImageType.asset,
                                  image: user.profilePicture.isNotEmpty ? user.profilePicture : TImages.user,
                                ),
                                const SizedBox(width: TSizes.sm),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(user.name, style: Theme.of(context).textTheme.labelMedium),
                                    Text(user.email, style: Theme.of(context).textTheme.bodyMedium),
                                  ],
                                ),
                              ],
                            ),
                            // const SizedBox(width: TSizes.spaceBtwItems),
                            // IconButton(onPressed: () {}, icon: const Icon(Iconsax.document_download)),
                          ],
                        ),
                      ),

                      /// Search
                      Expanded(
                        child: TextFormField(
                          controller: controller.searchTextController,
                          onChanged: (value) => controller.handleSearchQueryChange(),
                          decoration: InputDecoration(
                            hintText: 'Search...',
                            prefixIcon: const Icon(Iconsax.search_normal),
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: TColors.darkerGrey.withOpacity(0.6)),
                              borderRadius: BorderRadius.circular(TSizes.cardRadiusMd),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                /// Hidden filteredTransactions to update the UI
                Visibility(visible: false, child: Text('Total Items: ${controller.filteredTransactions.length}')),

                /// Table
                TPaginatedDataTable(
                  sortColumnIndex: controller.sortColumnIndex.value,
                  rowsPerPage: controller.filteredTransactions.length > 10
                      ? 10
                      : controller.filteredTransactions.isEmpty
                          ? 1
                          : controller.filteredTransactions.length,
                  columns: [
                    DataColumn2(
                      label: const Text('Date'),
                      onSort: (columnIndex, ascending) => controller.sortByDate(columnIndex, ascending),
                    ),
                    const DataColumn2(label: Text('Type')),
                    const DataColumn2(label: Text('Client Name')),
                    const DataColumn2(label: Text('Category')),
                    DataColumn2(
                      label: const Text('Quantity'),
                      onSort: (columnIndex, ascending) => controller.sortByQuantity(columnIndex, ascending),
                    ),
                    const DataColumn2(label: Text('Price')),
                    DataColumn2(
                      label: const Text('Total Price'),
                      onSort: (columnIndex, ascending) => controller.sortByTotalPrice(columnIndex, ascending),
                    ),
                    const DataColumn2(label: Text('labor')),
                    DataColumn2(
                      label: const Text('2% of Sold'),
                      onSort: (columnIndex, ascending) => controller.sortByDate(columnIndex, ascending),
                    ),
                  ],
                  source: TransactionsDataTableSource(),
                  onPageChanged: (int page) {},
                ),
              ],
            ),
    );
  }
}
