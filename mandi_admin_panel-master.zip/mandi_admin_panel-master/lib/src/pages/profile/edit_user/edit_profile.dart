import 'package:flutter/material.dart';
import '../../../../common/widgets/layouts/templates/site_layout.dart';
import 'responsive_screens/edit_profile_desktop.dart';
import 'responsive_screens/edit_profile_mobile.dart';

class EditProfileScreen extends StatelessWidget {
  const EditProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const TSiteTemplate(desktop: EditProfileDesktopScreen(), mobile: EditProfileMobileScreen());
  }
}