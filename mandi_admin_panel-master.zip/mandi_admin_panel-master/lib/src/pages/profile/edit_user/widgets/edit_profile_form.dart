import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:iconsax/iconsax.dart';
import 'package:mandi_admin_panel/src/controllers/users/admin_controller.dart';
import 'package:mandi_admin_panel/utils/helpers/cloud_helper_functions.dart';

import '../../../../../routes/routes.dart';
import '../../../../../utils/constants/sizes.dart';
import '../../../../../utils/constants/text_strings.dart';
import '../../../../../utils/device/device_utility.dart';
import '../../../../../utils/validators/validation.dart';
import 'profile_picture.dart';

class EditUserForm extends StatelessWidget {
  const EditUserForm({super.key});

  @override
  Widget build(BuildContext context) {
    final userController = AdminController.instance;
    return FutureBuilder(
        future: userController.getUserDetails(),
        builder: (context, snapshot) {
          final responseWidget = TCloudHelperFunctions.checkSingleRecordState(snapshot);
          if (responseWidget != null) return responseWidget;

          final user = snapshot.data!;
          userController.initFields(user);
          return Form(
            key: userController.formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // User Profile Picture and Role/Active Widget Section
                    _buildProfileSection(context),

                    // Forget Password
                    _buildForgetPasswordButton(),
                  ],
                ),

                const Divider(),
                const SizedBox(height: TSizes.spaceBtwItems),
                // Email, Password, Name, Phone Number, and Address Fields
                _buildInputFields(context),
                const SizedBox(height: TSizes.spaceBtwInputFields),
                TextFormField(
                  controller: userController.address,
                  decoration: const InputDecoration(labelText: 'Address', prefixIcon: Icon(Iconsax.location)),
                ),
                const SizedBox(height: TSizes.spaceBtwInputFields * 2),

                // Create Update Button
                _buildCreateButton(),
              ],
            ),
          );
        });
  }

  // Widget to build the Profile Picture and Role/Active Widget Section
  Widget _buildProfileSection(BuildContext context) => const Column(children: [ProfilePicture()]);

  // Widget to build the Email, Password, Name, Phone Number, and Address Fields
  Widget _buildInputFields(BuildContext context) {
    final userController = AdminController.instance;
    return TDeviceUtils.isMobileScreen(context)
        ? Column(
            children: [
              _buildTextField(
                controller: userController.email,
                validator: TValidator.validateEmail,
                labelText: '*Email',
                prefixIcon: Iconsax.main_component,
              ),
              const SizedBox(height: TSizes.spaceBtwInputFields),
              _buildTextField(
                controller: userController.name,
                labelText: 'Name',
                prefixIcon: Iconsax.user,
              ),
              const SizedBox(height: TSizes.spaceBtwInputFields),
              _buildTextField(
                controller: userController.phoneNumber,
                labelText: 'Phone Number',
                prefixIcon: Iconsax.mobile,
              ),
            ],
          )
        : Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: _buildTextField(
                      controller: userController.email,
                      validator: TValidator.validateEmail,
                      labelText: '*Email',
                      prefixIcon: Iconsax.main_component,
                    ),
                  ),
                  const SizedBox(width: TSizes.spaceBtwInputFields),
                  Expanded(
                    child: _buildTextField(
                      controller: userController.name,
                      labelText: 'Name',
                      prefixIcon: Iconsax.user,
                    ),
                  ),
                  const SizedBox(width: TSizes.spaceBtwInputFields),
                  Expanded(
                    child: _buildTextField(
                      controller: userController.phoneNumber,
                      labelText: 'Phone Number',
                      prefixIcon: Iconsax.mobile,
                    ),
                  ),
                ],
              ),
            ],
          );
  }

  // Widget to build a TextFormField
  Widget _buildTextField({
    required TextEditingController controller,
    required String labelText,
    IconData? prefixIcon,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      validator: validator,
      decoration: InputDecoration(
        labelText: labelText,
        prefixIcon: prefixIcon != null ? Icon(prefixIcon) : null,
      ),
    );
  }

  // Widget to build the Forget Password Button
  Widget _buildForgetPasswordButton() {
    return SizedBox(
      child: TextButton(
          onPressed: () => Get.toNamed(TRoutes.forgetPassword),
          child: const Text(TTexts.forgetPassword),
        ),
    );
  }

  // Widget to build the Create Button
  Widget _buildCreateButton() {
    final userController = AdminController.instance;
    return SizedBox(
      width: double.infinity,
      child: Obx(
        () => ElevatedButton(
          onPressed: userController.loading.value ? null : () => userController.updateData(),
          child: userController.loading.value ? const CircularProgressIndicator() : const Text('Update'),
        ),
      ),
    );
  }
}
