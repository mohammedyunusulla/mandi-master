import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mandi_admin_panel/common/widgets/layouts/sidebars/sidebar_controller.dart';
import 'package:mandi_admin_panel/data/repositories/authentication/authentication_repository.dart';
import 'package:mandi_admin_panel/src/pages/authentication/password_configuration/reset_password/reset_password.dart';
import 'package:mandi_admin_panel/src/pages/clients/clients.dart';
import 'package:mandi_admin_panel/src/pages/expenses/expenses.dart';
import 'package:mandi_admin_panel/src/pages/profile/edit_user/edit_profile.dart';
import 'package:mandi_admin_panel/src/pages/transactions/transactions.dart';
import 'package:mandi_admin_panel/src/pages/users/edit_user/edit_user.dart';
import '../src/pages/authentication/login/login.dart';
import '../src/pages/authentication/password_configuration/forget_password/forget_password.dart';
import '../src/pages/dashboard/dashboard.dart';
import '../src/pages/users/all_users/users.dart';
import '../src/pages/users/create_user/create_user.dart';
import 'routes.dart';

class TAppRoute {
  static final pages = [
    GetPage(name: TRoutes.login, page: () => const LoginScreen()),
    GetPage(name: TRoutes.forgetPassword, page: () => const ForgetPasswordScreen()),
    GetPage(name: TRoutes.resetPassword, page: () => const ResetPasswordScreen()),
    GetPage(name: TRoutes.dashboard, page: () => const DashboardScreen(), middlewares: [TRouteMiddleware()]),
    GetPage(name: TRoutes.users, page: () => const UsersScreen(), middlewares: [TRouteMiddleware()]),
    GetPage(name: TRoutes.createUser, page: () => const CreateUserScreen(), middlewares: [TRouteMiddleware()]),
    GetPage(name: TRoutes.editUser, page: () => const EditUserScreen(), middlewares: [TRouteMiddleware()]),
    GetPage(name: TRoutes.settings, page: () => const UsersScreen(), middlewares: [TRouteMiddleware()]),
    GetPage(name: TRoutes.transactions, page: () => const TransactionsScreen(), middlewares: [TRouteMiddleware()]),
    GetPage(name: TRoutes.expenses, page: () => const ExpensesScreen(), middlewares: [TRouteMiddleware()]),
    GetPage(name: TRoutes.clients, page: () => const ClientsScreen(), middlewares: [TRouteMiddleware()]),
    GetPage(name: TRoutes.profile, page: () => const EditProfileScreen(), middlewares: [TRouteMiddleware()]),
  ];
}

class RouteObservers extends GetObserver {
  @override
  void didPop(Route<dynamic>? route, Route<dynamic>? previousRoute) {
    final sidebarController = Get.put(SidebarController());

    if (previousRoute != null) {
      // Check the route name and update the active item accordingly
      for(var route in TRoutes.sideMenuItems) {
        if(previousRoute.settings.name == route){
          sidebarController.activeItem.value = route;
        }
      }

    }
  }
}

class TRouteMiddleware extends GetMiddleware {

  @override
  RouteSettings? redirect(String? route) {
    return AuthenticationRepository.instance.isAuthenticated ? null : const RouteSettings(name: TRoutes.login);
  }
}
