
// routes.dart

class TRoutes {
  static const login = '/login';
  static const forgetPassword = '/forgetPassword';
  static const resetPassword = '/resetPassword';
  static const dashboard = '/dashboard';
  static const users = '/users';
  static const createUser = '/createUser';
  static const editUser = '/editUser';
  static const transactions = '/transactions';
  static const clients = '/clients';
  static const expenses = '/expenses';
  static const settings = '/settings';
  static const profile = '/profile';
  static const bought = '/bought';
  static const sold = '/sold';


  static List sideMenuItems = [users, profile, 'logout'];
}