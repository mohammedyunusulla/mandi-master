package com.example.mandi_admin_panel

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
