import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:mandi_app/data/repositories/authentication/authentication_repository.dart';

import '../../../../src/models/client_advance_model.dart';
import '../../../../utils/exceptions/firebase_auth_exceptions.dart';
import '../../../../utils/exceptions/format_exceptions.dart';
import '../../../../utils/exceptions/platform_exceptions.dart';

/// Repository class for client-related operations.
class ClientAdvanceRepository extends GetxController {
  static ClientAdvanceRepository get instance => Get.find();

  final _db = FirebaseFirestore.instance;

  // final _firebaseStorage = FirebaseStorage.instance;

  /// Function to save client data to Firestore.
  Future<void> createAdvance(ClientAdvanceModel clientAdvance) async {
    try {
      await _db.collection("Advance").add(clientAdvance.toJson());
    } on FirebaseAuthException catch (e) {
      throw TFirebaseAuthException(e.code).getErrorMessage;
    } on FormatException catch (_) {
      throw const TFormatException();
    } on PlatformException catch (e) {
      throw TPlatformException(e.code).message;
    } catch (e) {
      throw 'Something went wrong. Please try again';
    }
  }

  /// Function to fetch client details based on client ID.
  Future<List<ClientAdvanceModel>> fetchAllAdvances(String clientId) async {
    try {
      final uid = AuthenticationRepository.instance.authUser?.uid;

      final querySnapshot = await _db
          .collection("Advance")
          .where('clientId', isEqualTo: clientId)
          .where('userId', isEqualTo: uid)
          .orderBy('advanceDate', descending: true)
          .get();
      // final querySnapshot = await _db.collection("Advance").where('userId', isEqualTo: uid).orderBy('advanceDate', descending: true).get();
      return querySnapshot.docs.map((doc) => ClientAdvanceModel.fromSnapshot(doc)).toList();
    } on FirebaseAuthException catch (e) {
      throw TFirebaseAuthException(e.code).getErrorMessage;
    } on FormatException catch (_) {
      throw const TFormatException();
    } on PlatformException catch (e) {
      throw TPlatformException(e.code).message;
    } catch (e) {
      if (kDebugMode) print('Something Went Wrong: $e');
      throw 'Something Went Wrong: $e';
    }
  }

  /// Function to fetch client details based on client ID.
  Future<ClientAdvanceModel> fetchAdvanceDetails() async {
    try {
      final documentSnapshot = await _db.collection("Advance").doc().get();
      if (documentSnapshot.exists) {
        return ClientAdvanceModel.fromSnapshot(documentSnapshot);
      } else {
        return ClientAdvanceModel.empty();
      }
    } on FirebaseAuthException catch (e) {
      throw TFirebaseAuthException(e.code).getErrorMessage;
    } on FormatException catch (_) {
      throw const TFormatException();
    } on PlatformException catch (e) {
      throw TPlatformException(e.code).message;
    } catch (e) {
      if (kDebugMode) print('Something Went Wrong: $e');
      throw 'Something Went Wrong: $e';
    }
  }

  /// Function to update client data in Firestore.
  // Future<void> updateClient(ClientModel updatedClient) async {
  //   try {
  //     await _db.collection("Clients").doc(updatedClient.id).update(updatedClient.toJson());
  //   } on FirebaseAuthException catch (e) {
  //     throw TFirebaseAuthException(e.code).getErrorMessage;
  //   } on FormatException catch (_) {
  //     throw const TFormatException();
  //   } on PlatformException catch (e) {
  //     throw TPlatformException(e.code).message;
  //   } catch (e) {
  //     throw 'Something went wrong. Please try again';
  //   }
  // }

  /// Function to remove client data from Firestore.
  // Future<void> removeClientRecord(String clientId) async {
  //   try {
  //     await _db.collection("Clients").doc(clientId).delete();
  //   } on FirebaseAuthException catch (e) {
  //     throw TFirebaseAuthException(e.code).getErrorMessage;
  //   } on FormatException catch (_) {
  //     throw const TFormatException();
  //   } on PlatformException catch (e) {
  //     throw TPlatformException(e.code).message;
  //   } catch (e) {
  //     throw 'Something went wrong. Please try again';
  //   }
  // }
  Future<void> updateAdvance(String advanceId, double updatedAdvance) async {
    try {
      await _db.collection("Advance").doc(advanceId).update({'advance': updatedAdvance});
    } on FirebaseAuthException catch (e) {
      throw TFirebaseAuthException(e.code).getErrorMessage;
    } on FormatException catch (_) {
      throw const TFormatException();
    } on PlatformException catch (e) {
      throw TPlatformException(e.code).message;
    } catch (e) {
      throw 'Something went wrong. Please try again';
    }
  }

  Future<void> deleteAdvance(String advanceId) async {
    try {
      await _db.collection("Advance").doc(advanceId).delete();
    } catch (e) {
      throw 'Failed to delete advance record: $e';
    }
  }
}
