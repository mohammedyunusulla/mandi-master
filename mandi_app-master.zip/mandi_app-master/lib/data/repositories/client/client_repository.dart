import 'dart:io';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:image_picker/image_picker.dart';
import 'package:mandi_app/data/repositories/authentication/authentication_repository.dart';
import '../../../src/models/client_model.dart';
import '../../../utils/exceptions/firebase_auth_exceptions.dart';
import '../../../utils/exceptions/format_exceptions.dart';
import '../../../utils/exceptions/platform_exceptions.dart';

/// Repository class for client-related operations.
class ClientRepository extends GetxController {
  static ClientRepository get instance => Get.find();

  final _db = FirebaseFirestore.instance;
  final _firebaseStorage = FirebaseStorage.instance;

  /// Function to save client data to Firestore.
  Future<void> createClient(ClientModel client) async {
    try {
      await _db.collection("Clients").add(client.toJson());
    } on FirebaseAuthException catch (e) {
      throw TFirebaseAuthException(e.code).getErrorMessage;
    } on FormatException catch (_) {
      throw const TFormatException();
    } on PlatformException catch (e) {
      throw TPlatformException(e.code).message;
    } catch (e) {
      throw 'Something went wrong. Please try again';
    }
  }

  /// Function to fetch client details based on client ID.
  Future<List<ClientModel>> fetchAllClients(int limit) async {
    try {
      final uid = AuthenticationRepository.instance.authUser?.uid;
      // final querySnapshot = limit == -1
      //     ? await _db.collection("Clients").where('userId', isEqualTo: uid).orderBy('createdAt', descending: true).get()
      //     : await _db.collection("Clients").where('userId', isEqualTo: uid).orderBy('createdAt', descending: true).limit(limit).get();

      final querySnapshot = await _db.collection("Clients").where('userId', isEqualTo: uid).orderBy('createdAt', descending: true).get();
      return querySnapshot.docs.map((doc) => ClientModel.fromSnapshot(doc)).toList();
    } on FirebaseAuthException catch (e) {
      throw TFirebaseAuthException(e.code).getErrorMessage;
    } on FormatException catch (_) {
      throw const TFormatException();
    } on PlatformException catch (e) {
      throw TPlatformException(e.code).message;
    } catch (e) {
      if (kDebugMode) print('Something Went Wrong: $e');
      throw 'Something Went Wrong: $e';
    }
  }

  /// Function to fetch client details based on client ID.
  Future<ClientModel> fetchClientDetails() async {
    try {
      final documentSnapshot = await _db.collection("Clients").doc().get();
      if (documentSnapshot.exists) {
        return ClientModel.fromSnapshot(documentSnapshot);
      } else {
        return ClientModel.empty();
      }
    } on FirebaseAuthException catch (e) {
      throw TFirebaseAuthException(e.code).getErrorMessage;
    } on FormatException catch (_) {
      throw const TFormatException();
    } on PlatformException catch (e) {
      throw TPlatformException(e.code).message;
    } catch (e) {
      if (kDebugMode) print('Something Went Wrong: $e');
      throw 'Something Went Wrong: $e';
    }
  }

  /// Function to update client data in Firestore.
  Future<void> updateClient(ClientModel updatedClient) async {
    try {
      await _db.collection("Clients").doc(updatedClient.id).update(updatedClient.toJson());
    } on FirebaseAuthException catch (e) {
      throw TFirebaseAuthException(e.code).getErrorMessage;
    } on FormatException catch (_) {
      throw const TFormatException();
    } on PlatformException catch (e) {
      throw TPlatformException(e.code).message;
    } catch (e) {
      throw 'Something went wrong. Please try again';
    }
  }

  /// Update any field in specific Clients Collection
  Future<void> updateSingleField(String docId, Map<String, dynamic> json) async {
    try {
      await _db.collection("Clients").doc(docId).update(json);
    } on FirebaseAuthException catch (e) {
      throw TFirebaseAuthException(e.code).getErrorMessage;
    } on FormatException catch (_) {
      throw const TFormatException();
    } on PlatformException catch (e) {
      throw TPlatformException(e.code).message;
    } catch (e) {
      throw 'Something went wrong. Please try again';
    }
  }

  /// Upload any Image
  Future<String> uploadImage(String path, XFile image) async {
    try {
      final ref = _firebaseStorage.ref(path).child(image.name);
      await ref.putFile(File(image.path));
      final url = await ref.getDownloadURL();
      return url;
    } on FirebaseException catch (e) {
      throw e.message!;
    } on SocketException catch (e) {
      throw e.message;
    } on PlatformException catch (e) {
      throw e.message!;
    } catch (e) {
      throw 'Something went wrong. Please try again';
    }
  }

  /// Function to remove client data from Firestore.
  Future<void> removeClientRecord(String clientId) async {
    try {
      await _db.collection("Clients").doc(clientId).delete();
    } on FirebaseAuthException catch (e) {
      throw TFirebaseAuthException(e.code).getErrorMessage;
    } on FormatException catch (_) {
      throw const TFormatException();
    } on PlatformException catch (e) {
      throw TPlatformException(e.code).message;
    } catch (e) {
      throw 'Something went wrong. Please try again';
    }
  }
}
