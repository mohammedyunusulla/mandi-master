import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mandi_app/utils/constants/colors.dart';
import 'package:mandi_app/utils/constants/image_strings.dart';
import 'package:mandi_app/utils/constants/sizes.dart';
import '../../../common/widgets/custom_shapes/containers/mandi_details_card.dart';
import '../../../common/widgets/drawer/drawer.dart';
import '../../../utils/helpers/helper_functions.dart';
import '../../controller/user/user_controller.dart';
import '../../models/main_card_values.dart';
import '../buy/buy_detail_screen.dart';
import '../clients/clients_form_screen.dart';
import '../expense/expense_details_screen.dart';
import '../reports/report_screen.dart';
import '../sell/sell_details_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final UserController controller = Get.put(UserController());
    bool isDarkMode = THelperFunctions.isDarkMode(context);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            image: DecorationImage(
              image: AssetImage('assets/images/background/mandifood.jpg'),
              fit: BoxFit.cover,
            ),
          ),
          child: Container(
            color: Colors.black.withOpacity(0.7),
          ),
        ),
        title: Obx(
              () => Text(
            controller.user.value.name,
            style: Theme.of(context).textTheme.titleLarge!.copyWith(
              color: isDarkMode ? TColors.light : TColors.light,
            ),
          ),
        ),
        iconTheme: IconThemeData(
          color: isDarkMode ? TColors.light : TColors.light,
        ),
      ),


      drawer: const TDrawer(),
      body: Stack(
        children: [
          // Background Image
          ImageFiltered(
            imageFilter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
            child: Container(
              width: double.infinity,
              height: double.infinity,
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('assets/images/background/mandifood.jpg'),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),

          SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(TSizes.defaultSpace),
              child: Column(
                children: [
                  // TCard Fixed Width & Height
                  TMandiDetailsCard(
                    onTap: () => Get.off(() => const BoughtDetailScreen()),
                    title: 'Buy',
                    subTitle: 'Bought Items Record',
                    leading: Image.asset(TImages.buyIcon),
                    backgroundColor: TColors.primary.withOpacity(0.7),
                    cardValues: [
                      MainCardValues(key: 'Transactions', value: '2563'),
                      MainCardValues(key: 'Rate', value: '2563'),
                      MainCardValues(key: 'Quantity', value: '2563'),
                    ],
                  ),
                  TMandiDetailsCard(
                    onTap: () => Get.off(() => const SellDetailScreen()),
                    title: 'Sell',
                    subTitle: 'Sold Items Record',
                    leading: Image.asset(TImages.sellIcon),
                    backgroundColor: Colors.purple.withOpacity(0.7),
                    cardValues: [
                      MainCardValues(key: 'Transactions', value: '2563'),
                      MainCardValues(key: 'Rate', value: '2563'),
                      MainCardValues(key: 'Quantity', value: '2563'),
                    ],
                  ),
                  TMandiDetailsCard(
                    onTap: () => Get.off(() => const ExpenseDetailsScreen()),
                    title: 'Expenses',
                    subTitle: 'All Expense Items Record',
                    leading: Image.asset(TImages.expenseIcon),
                    backgroundColor: Colors.red.withOpacity(0.7),
                    cardValues: [
                      MainCardValues(key: 'Last Expense :', value: ''),
                      MainCardValues(key: 'Name', value: 'Tea'),
                      MainCardValues(key: 'Cost', value: '2563'),
                    ],
                  ),
                  TMandiDetailsCard(
                    onTap: () => Get.off(() => const ReportsScreen()),
                    title: 'All Reports',
                    subTitle: 'Sold Items Record',
                    leading: Image.asset(TImages.reportsIcon),
                    backgroundColor: Colors.purple.withOpacity(0.7),
                    cardValues: [
                      MainCardValues(key: 'Buy', value: '10'),
                      MainCardValues(key: 'Sell', value: '100'),
                      MainCardValues(key: 'Expense', value: '200'),
                    ],
                  ),
                  // ... (other TMandiDetailsCard widgets)
                ],
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Get.to(() => const ClientFormScreen()),
        label: Text(
          'Add Client',
          style: Theme.of(context)
              .textTheme
              .bodyMedium!
              .apply(color: TColors.white),
        ),
        icon: const Icon(Icons.add, color: TColors.white),
        backgroundColor: TColors.primary,
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
    );
  }
}

// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:mandi_app/utils/constants/colors.dart';
// import 'package:mandi_app/utils/constants/image_strings.dart';
// import 'package:mandi_app/utils/constants/sizes.dart';
// import '../../../common/widgets/custom_shapes/containers/mandi_details_card.dart';
// import '../../../common/widgets/drawer/drawer.dart';
// import '../../../utils/helpers/helper_functions.dart';
// import '../../models/main_card_values.dart';
// import '../buy/buy_detail_screen.dart';
// import '../clients/clients_form_screen.dart';
// import '../expense/expense_details_screen.dart';
// import '../reports/report_screen.dart';
// import '../sell/sell_details_screen.dart';
//
// class DashboardScreen extends StatelessWidget {
//   const DashboardScreen({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Dashboard', style: Theme.of(context).textTheme.titleLarge),
//         iconTheme: IconThemeData(
//             color: THelperFunctions.isDarkMode(context)
//                 ? TColors.light
//                 : TColors.dark),
//       ),
//       drawer: const TDrawer(),
//       body: SingleChildScrollView(
//         child: Padding(
//           padding: const EdgeInsets.all(TSizes.defaultSpace),
//           child: Column(
//             children: [
//               // TCard Fixed Width & Height
//               TMandiDetailsCard (
//                 onTap: () => Get.off(() => const BoughtDetailScreen()),
//                 title: 'Buy',
//                 subTitle: 'Bought Items Record',
//                 leading: Image.asset(TImages.buyIcon),
//                 backgroundColor: TColors.primary.withOpacity(0.7),
//                 cardValues: [
//                   MainCardValues(key: 'Transactions', value: '2563'),
//                   MainCardValues(key: 'Rate', value: '2563'),
//                   MainCardValues(key: 'Quantity', value: '2563'),
//                 ],
//               ),
//               TMandiDetailsCard(
//                 onTap: () => Get.off(() => const SellDetailScreen()),
//                 title: 'Sell',
//                 subTitle: 'Sold Items Record',
//                 leading: Image.asset(TImages.sellIcon),
//                 backgroundColor: Colors.purple.withOpacity(0.7),
//                 cardValues: [
//                   MainCardValues(key: 'Transactions', value: '2563'),
//                   MainCardValues(key: 'Rate', value: '2563'),
//                   MainCardValues(key: 'Quantity', value: '2563'),
//                 ],
//               ),
//               TMandiDetailsCard(
//                 onTap: () => Get.off(() => const ExpenseDetailsScreen()),
//                 title: 'Expenses',
//                 subTitle: 'All Expense Items Record',
//                 leading: Image.asset(TImages.expenseIcon),
//                 backgroundColor: Colors.red.withOpacity(0.7),
//                 cardValues: [
//                   MainCardValues(key: 'Last Expense :', value: ''),
//                   MainCardValues(key: 'Name', value: 'Tea'),
//                   MainCardValues(key: 'Cost', value: '2563'),
//                 ],
//               ),
//               TMandiDetailsCard(
//                 onTap: () => Get.off(() => const ReportsScreen()),
//                 title: 'All Reports',
//                 subTitle: 'Sold Items Record',
//                 leading: Image.asset(TImages.reportsIcon),
//                 backgroundColor: Colors.purple.withOpacity(0.7),
//                 cardValues: [
//                   MainCardValues(key: 'Buy', value: '10'),
//                   MainCardValues(key: 'Sell', value: '100'),
//                   MainCardValues(key: 'Expense', value: '200'),
//                 ],
//               ),
//             ],
//           ),
//         ),
//       ),
//       floatingActionButton: FloatingActionButton.extended(
//         onPressed: () => Get.to(() => const ClientFormScreen()),
//         label: Text(
//           'Add Client',
//           style: Theme.of(context)
//               .textTheme
//               .bodyMedium!
//               .apply(color: TColors.white),
//         ),
//         icon: const Icon(Icons.add, color: TColors.white),
//         backgroundColor: TColors.primary,
//       ),
//       floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
//     );
//   }
// }
