import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:iconsax/iconsax.dart';
import 'package:mandi_app/src/controller/expense/expense_controller.dart';
import 'package:mandi_app/utils/constants/colors.dart';
import '../../../common/widgets/custom_shapes/containers/mandi_details_card.dart';
import '../../../common/widgets/custom_shapes/containers/rounded_container.dart';
import '../../../common/widgets/dates/from_to_dates.dart';
import '../../../common/widgets/drawer/drawer.dart';
import '../../../common/widgets/searchbar/searchbar.dart';
import '../../../utils/constants/sizes.dart';
import '../../../utils/constants/text_strings.dart';
import '../../../utils/helpers/helper_functions.dart';
import 'expense_edit_screen.dart';
import 'expense_create_screen.dart';

class ExpenseDetailsScreen extends StatelessWidget {
  const ExpenseDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    bool isDarkMode = THelperFunctions.isDarkMode(context);
    final controller = Get.put(ExpenseController());
    return Scaffold(
      /// Appbar with dropdown
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            image: DecorationImage(
              image: AssetImage('assets/images/background/mandifood.jpg'),
              fit: BoxFit.cover,
            ),
          ),
          child: Container(
            color: Colors.black.withOpacity(0.7),
          ),
        ),

        title: Text(TTexts.appName,
          style: Theme.of(context).textTheme.titleLarge!.copyWith(
            color: isDarkMode ? TColors.light : TColors.light,
          ),
        ),
        iconTheme: IconThemeData(
            color: THelperFunctions.isDarkMode(context)
                ? TColors.light
                : TColors.light),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: TSizes.sm),
            child: SizedBox(
              width: 100,
              child: Obx(
                () => DropdownButton<String>(
                  value: controller.limit.value.toString(),
                  onChanged: (String? newValue) {
                    if (newValue != null) {
                      controller.limit.value = int.parse(newValue);
                      controller.loadData();
                    }
                  },
                  items: const [
                    DropdownMenuItem<String>(
                      value: '7',
                      child: Text('7 Days'),
                    ),
                    DropdownMenuItem<String>(
                      value: '30',
                      child: Text('1 Month'),
                    ),
                    // DropdownMenuItem<String>(
                    //   value: '365',
                    //   child: Text('Year'),
                    // ),
                  ],
                  style: TextStyle(
                    color: Theme.of(context).brightness == Brightness.light
                        ? TColors.light // Light mode text color
                        : TColors.light, // Dark mode text color
                  ),
                  dropdownColor: Theme.of(context).brightness == Brightness.light
                      ? TColors.dark // Light mode dropdown background color
                      : TColors.dark, // Dark mode dropdown background color
                ),
              ),
            ),
          )
        ],
      ),
      drawer: const TDrawer(),
      body: Stack(
        children: [
          // Background Image
          ImageFiltered(
            imageFilter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
            child: Container(
              width: double.infinity,
              height: double.infinity,
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('assets/images/background/mandifood.jpg'),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),





          SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(TSizes.defaultSpace),
              child: Column(
                children: [
                  /// Searchbar and Download Report Button
                  Row(
                    children: [
                      Expanded(
                        child: TSearchbar(
                          controller: controller.searchTextController,
                          onChanged: (value) => controller.filterData(value),
                        ),
                      ),
                      //const SizedBox(width: TSizes.spaceBtwItems),
                      //_downloadReport(),
                    ],
                  ),
                  const SizedBox(height: TSizes.spaceBtwSections),

                  /// Expense Details Cards
                  _expenseList(controller),
                ],
              ),
            ),
          ),
        ],
      ),

      /// Add Expense floating button
      floatingActionButton: FloatingActionButton(
        onPressed: () => Get.to(() => const ExpenseCreateScreen()),
        backgroundColor: TColors.primary,
        child: const Icon(Icons.add, color: TColors.white),
      ),
    );
  }

  Obx _expenseList(ExpenseController controller) {
    return Obx(() {
      return controller.loading.value
          ? const CircularProgressIndicator()
          : ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: controller.filteredExpense.length,
              itemBuilder: (_, index) {
                final expense = controller.filteredExpense[index];
                return TMandiDetailsCard(
                  onTap: () =>
                      Get.to(() => ExpenseEditScreen(expense: expense)),
                  title: expense.name,
                  leading: const Image(
                      image: AssetImage(
                          'assets/icons/mandi_icons/expense_icon_2.png')),
                  subTitle: expense.amount.toString(),
                  backgroundColor: THelperFunctions.getBackgroundColors(index),
                );
                // return TCardExpense(
                //   onTap: () => Get.to(() => ExpenseEditScreen(expense: expense)),
                //   title: expense.name,
                //   image: TImages.user,
                //   subTitle: expense.amount.toString(),
                //   backgroundColor: THelperFunctions.getBackgroundColors(index),
                //
                // );
              },
            );
    });
  }

  /// Method to download reports
  TRoundedContainer _downloadReport() {
    return TRoundedContainer(
      showBorder: true,
      padding: const EdgeInsets.all(TSizes.sm),
      child: IconButton(
          onPressed: () => Get.bottomSheet(
                backgroundColor: TColors.white,
                Padding(
                  padding: const EdgeInsets.all(TSizes.defaultSpace),
                  child: TFromToDates(
                      from: (DateTime? value) {},
                      to: (DateTime? value) {},
                      onPressed: () {}),
                ),
              ),
          icon: const Icon(Iconsax.document_download)),
    );
  }
}
