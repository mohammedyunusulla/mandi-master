import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';
import '../../../../utils/constants/sizes.dart';
import '../../../controller/expense/expense_create_controller.dart';

class ExpenseCreateForm extends StatelessWidget {
  const ExpenseCreateForm({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final controller = ExpenseCreateController();
    return Form(
      key: controller.expenseForm,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextFormField(
             controller: controller.name,
            // validator: (value) => TValidator.validateEmptyText('Category', value),
            decoration: const InputDecoration(label: Text('Item Name'), prefixIcon: Icon(Iconsax.shopping_cart)),
          ),
          const SizedBox(height: TSizes.spaceBtwInputFields),
          TextFormField(
             controller: controller.rate,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(label: Text('Rate'), prefixIcon: Icon(Iconsax.money)),
          ),
          const SizedBox(height: TSizes.spaceBtwInputFields),
          TextFormField(
             controller: controller.paymentRemarks,
            decoration: const InputDecoration(label: Text('Remarks'), prefixIcon: Icon(Iconsax.note)),
          ),
          const SizedBox(height: TSizes.spaceBtwSections),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(onPressed: ()  => controller.createExpense(), child: const Text("Submit")),
          ),
        ],
      ),
    );
  }
}