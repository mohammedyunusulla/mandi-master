import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';
import '../../../../utils/constants/colors.dart';
import '../../../../utils/constants/sizes.dart';
import '../../../../utils/validators/validation.dart';
import '../../../controller/expense/expense_edit_controller.dart';
import '../../../models/expense_model.dart';

class ExpenseEditForm extends StatelessWidget {
  const ExpenseEditForm({
    super.key,
    required this.expense,
  });
    final ExpenseModel expense;
  @override
  Widget build(BuildContext context) {
    final controller = ExpenseUpdateController();
    controller.initExpenseData(expense);
    return Form(
      key: controller.expenseForm,
      child: Column(
        children: [
          TextFormField(
             controller: controller.name,
             validator: (value) => TValidator.validateEmptyText('name', value),
            decoration: const InputDecoration(label: Text('Item Name'), prefixIcon: Icon(Iconsax.shopping_cart)),
          ),
          const SizedBox(height: TSizes.spaceBtwInputFields),
          TextFormField(
             controller: controller.amount,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(label: Text('Amount'), prefixIcon: Icon(Iconsax.money)),
          ),
          const SizedBox(height: TSizes.spaceBtwInputFields),
          TextFormField(
             controller: controller.remarks,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(label: Text('Remarks'), prefixIcon: Icon(Iconsax.note)),
          ),
          const SizedBox(height: TSizes.spaceBtwSections),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(onPressed: () => controller.updateExpense(expense), child: const Text("Update")),
          ),
          const SizedBox(height: TSizes.spaceBtwSections),
          SizedBox(
            width: 200,
            child: TextButton(
              onPressed: () => controller.deleteExpense(expense),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Iconsax.trash, color: Colors.red, size: TSizes.iconSm),
                  Text(" Delete Client", style: Theme.of(context).textTheme.bodyLarge!.apply(color: TColors.error)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
