import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';
import '../../../../common/widgets/custom_shapes/containers/circular_container.dart';
import '../../../../utils/constants/colors.dart';
import '../../../../utils/constants/sizes.dart';


class TCardExpense extends StatelessWidget {
  const TCardExpense({
    super.key,
    required this.backgroundColor,
    required this.image,
    required this.title,
    required this.subTitle,
    this.onTap,
  });

  /// Card background color
  final Color backgroundColor;

  final String image, title, subTitle;


  final Function()? onTap;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 130,

      /// TCard Overall design
      child: Container(
        margin: const EdgeInsets.only(bottom: TSizes.spaceBtwItems),
        decoration: BoxDecoration(
          color: backgroundColor,
          borderRadius: BorderRadius.circular(TSizes.cardRadiusLg * 2),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [backgroundColor.withOpacity(0.7), backgroundColor],
          ),
        ),

        /// Use Stack in order to add White Circular Container in the BG
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(TSizes.cardRadiusLg * 2),
          child: Stack(
            children: [
              Positioned(
                bottom: -120,
                right: -180,
                child: TCircularContainer(width: 300, height: 300, backgroundColor: TColors.white.withOpacity(0.1)),
              ),

              /// Main Card Body
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: TSizes.sm, vertical: TSizes.md - 3),
                child: Column(
                  children: [
                    /// Upper List Tile
                    Row(
                      children: [
                        Expanded(
                          child: ListTile(
                            leading:  const Icon(Iconsax.money, color: TColors.white),
                            title: Text(title.toUpperCase(), style: Theme.of(context).textTheme.titleLarge!.apply(color: TColors.white)),
                            subtitle: Text(subTitle, style: Theme.of(context).textTheme.labelLarge!.apply(color: TColors.white)),
                            trailing: const Icon(Icons.download, color: TColors.white),
                          ),
                        )
                      ],
                    ),
                    const SizedBox(height: TSizes.spaceBtwItems),

                    /// Lower List Tile


                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
