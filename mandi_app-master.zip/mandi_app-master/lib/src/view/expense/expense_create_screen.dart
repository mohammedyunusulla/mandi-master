
import 'package:flutter/material.dart';
import 'package:mandi_app/src/view/expense/widget/expense_create_form.dart';


class ExpenseCreateScreen extends StatelessWidget {
  const ExpenseCreateScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Expense'),
      ),
      body: const Padding(
        padding: EdgeInsets.all(16.0),
        child: ExpenseCreateForm(),
      ),
    );
  }
}
