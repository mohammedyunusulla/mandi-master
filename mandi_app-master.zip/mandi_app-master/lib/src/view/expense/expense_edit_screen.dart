import 'package:flutter/material.dart';
import 'package:mandi_app/src/models/expense_model.dart';
import 'package:mandi_app/src/view/expense/widget/expense_edit_form.dart';


class ExpenseEditScreen extends StatelessWidget {
  const ExpenseEditScreen({super.key, required this.expense});

  final ExpenseModel expense;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: const Text('Edit Expense')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ExpenseEditForm(expense: expense),
      ),
    );
  }
}
