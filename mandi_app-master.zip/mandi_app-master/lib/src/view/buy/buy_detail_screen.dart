import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:iconsax/iconsax.dart';
import 'package:mandi_app/src/controller/buy/buy_controller.dart';
import 'package:mandi_app/utils/helpers/helper_functions.dart';
import '../../../common/widgets/custom_shapes/containers/buy_sell_card.dart';
import '../../../common/widgets/custom_shapes/containers/rounded_container.dart';
import '../../../common/widgets/dates/from_to_dates.dart';
import '../../../common/widgets/drawer/drawer.dart';
import '../../../common/widgets/images/t_circular_image.dart';
import '../../../common/widgets/searchbar/searchbar.dart';
import '../../../utils/constants/colors.dart';
import '../../../utils/constants/enums.dart';
import '../../../utils/constants/image_strings.dart';
import '../../../utils/constants/sizes.dart';
import '../../models/main_card_values.dart';
import '../reports/invoice.dart';
import '../reports/print_reports/buy_report.dart';
import 'buy_edit_screen.dart';
import 'buy_form_screen.dart';

class BoughtDetailScreen extends StatelessWidget {
  const BoughtDetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    bool isDarkMode = THelperFunctions.isDarkMode(context);
    final controller = Get.put(BuyController());
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            image: DecorationImage(
              image: AssetImage('assets/images/background/mandifood.jpg'),
              fit: BoxFit.cover,
            ),
          ),
          child: Container(
            color: Colors.black.withOpacity(0.7),
          ),
        ),



        title:  Text("Buy",
          style: Theme.of(context).textTheme.titleLarge!.copyWith(
            color: isDarkMode ? TColors.light : TColors.light,
          ),
        ),
        iconTheme: IconThemeData(
            color: THelperFunctions.isDarkMode(context)
                ? TColors.light
                : TColors.light),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: TSizes.sm),
            child: SizedBox(
              width: 100,
              child: Obx(
                () => DropdownButton<String>(
                  value: controller.limit.value.toString(),
                  onChanged: (String? newValue) {
                    if (newValue != null) {
                      controller.limit.value = int.parse(newValue);
                      controller.loadData();
                    }
                  },
                  items: const [
                    DropdownMenuItem<String>(value: '7', child: Text('7 Days')),
                    DropdownMenuItem<String>(value: '30', child: Text('1 Month')),
                  ],
                  style: TextStyle(
                    color: Theme.of(context).brightness == Brightness.light
                        ? TColors.light // Light mode text color
                        : TColors.light, // Dark mode text color
                  ),
                  dropdownColor: Theme.of(context).brightness == Brightness.light
                      ? TColors.dark // Light mode dropdown background color
                      : TColors.dark, // Dark mode dropdown background color
                ),
              ),
            ),
          )
        ],
      ),
      drawer: const TDrawer(),
      body: Stack(
        children: [
          // Background Image
          ImageFiltered(
            imageFilter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
            child: Container(
              width: double.infinity,
              height: double.infinity,
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('assets/images/background/mandifood.jpg'),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),

          SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(TSizes.defaultSpace),
              child: Column(
                children: [
                  /// Search and Download Button
                  Row(
                    children: [
                      Expanded(
                        child: TSearchbar(
                          controller: controller.searchTextController,
                          onChanged: (value) => controller.filterData(value),
                        ),
                      ),
                      const SizedBox(width: TSizes.spaceBtwItems),
                      _downloadReport(context),
                    ],
                  ),
                  const SizedBox(height: TSizes.spaceBtwSections),

                  /// All Clients
                  _buyList(controller),
                ],
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Get.to(() => const BoughtFormScreen()),
        backgroundColor: TColors.primary,
        child: const Icon(Icons.add, color: TColors.white),
      ),
    );
  }

  /// Buy Details List View of All Clients
  Obx _buyList(BuyController controller) {
    return Obx(() {
      return controller.loading.value
          ? const CircularProgressIndicator()
          : controller.filteredBought.isEmpty
              ? const Center(child: Text('No transaction found.'))
              : SingleChildScrollView(
                  child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: controller.filteredBought.length,
                    physics: const NeverScrollableScrollPhysics(),
                    itemBuilder: (_, index) {
                      final transaction = controller.filteredBought[index];
                      return TBuySellDetailsCard(
                        onTap: () => Get.to(
                            () => BoughtEditScreen(transaction: transaction)),
                        onPrintInvoice: () => Get.to(Invoice(transactionModel: transaction,)),
                        title: transaction.clientName,
                        leading: TCircularImage(
                          padding: 0,
                          image: transaction.clientProfilePicture.isNotEmpty
                              ? transaction.clientProfilePicture
                              : TImages.user,
                          imageType: transaction.clientProfilePicture.isNotEmpty
                              ? ImageType.network
                              : ImageType.asset,
                          // image: TImages.user
                        ),
                        subTitle: transaction.category,
                        backgroundColor:
                            THelperFunctions.getBackgroundColors(index),
                        cardValues: [
                          MainCardValues(
                              key: 'Rate', value: transaction.rate.toString()),
                          MainCardValues(
                              key: 'Qty',
                              value: transaction.quantity.toString()),
                          MainCardValues(
                              key: 'Labor',
                              value: transaction.labor.toString()),
                          MainCardValues(
                              key: 'Arrival No',
                              value: transaction.arrivalNo.toString()),

                        ],
                        cardDateValue: [
                          MainCardValues(
                              key: transaction.formattedTransactionDate,
                              value: ''),
                          MainCardValues(
                              key: transaction.paymentRemarks, value: ''),
                        ],
                      );
                    },
                  ),
                );
    });
  }

  /// Main
  TRoundedContainer _downloadReport(BuildContext context) {
    final dark = THelperFunctions.isDarkMode(context);
    return TRoundedContainer(
      showBorder: true,
      padding: const EdgeInsets.all(TSizes.sm),
      child: IconButton(
        onPressed: () => Get.bottomSheet(
          backgroundColor: dark ? TColors.dark : TColors.white,
          Padding(
            padding: const EdgeInsets.all(TSizes.defaultSpace),
            child: TFromToDates(
                from: (DateTime? value) {},
                to: (DateTime? value) {},
                onPressed: () => Get.to(BuyReport())),
          ),
        ),
        icon: const Icon(Iconsax.document_download),
      ),
    );
  }
}
