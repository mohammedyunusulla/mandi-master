
import 'package:date_field/date_field.dart';
import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';
import 'package:mandi_app/src/models/transaction_model.dart';
import '../../../common/widgets/images/t_circular_image.dart';
import '../../../common/widgets/shimmers/shimmer.dart';
import '../../../utils/constants/colors.dart';
import '../../../utils/constants/enums.dart';
import '../../../utils/constants/image_strings.dart';
import '../../../utils/constants/sizes.dart';
import '../../../utils/helpers/cloud_helper_functions.dart';
import '../../../utils/validators/validation.dart';
import '../../controller/buy/buy_edit_controller.dart';
import '../../models/client_model.dart';

class BoughtEditScreen extends StatelessWidget {
  const BoughtEditScreen({super.key, required this.transaction});

  final TransactionModel transaction;

  @override
  Widget build(BuildContext context) {
    final controller = BuyUpdateController();
    controller.initTransactionData(transaction);
    return Scaffold(
      appBar: AppBar(

        title: const Text('Edit Bought Item'),
      ),

      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(TSizes.defaultSpace),
          child: Column(
            children: [
              /// Form
              Form(
                key: controller.buyForm,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    DateTimeFormField(
                      decoration: const InputDecoration(
                          hintText: 'Transaction Date'),
                      mode: DateTimeFieldPickerMode.date,
                      onChanged: (DateTime? dateTime) =>
                      controller.transactionDate.value = dateTime,
                      initialPickerDateTime:
                      controller.transactionDate.value,
                      initialValue: controller.transactionDate.value,
                      validator: (value) {if (value == null) {return 'Transaction Date is required.';}return null;},
                    ),
                    const SizedBox(height: TSizes.spaceBtwInputFields),
                    /// Clients
                    const Text('Select Client'),
                    FutureBuilder(
                      future: controller.loadClients(),
                      builder: (context, snapshot) {
                        const loader = TShimmerEffect(
                            width: double.infinity, height: 25);
                        final widget =
                            TCloudHelperFunctions.checkMultiRecordState(
                                snapshot: snapshot, loader: loader);
                        if (widget != null) return widget;

                        final clients = snapshot.data!;
                        return DropdownButtonFormField<ClientModel>(
                          value: clients.firstWhere((element) =>
                              element.id == transaction.clientId),
                          decoration: const InputDecoration(
                              hintText: 'Select Client'),
                          onChanged: (newValue) =>
                              controller.selectedClient.value = newValue!,
                          items: clients
                              .map((item) => DropdownMenuItem(
                                    value: item,
                                    child: Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.end,
                                        children: [
                                          TCircularImage(
                                            width: 25,
                                            height: 25,
                                            padding: 0,
                                            image: item.profilePicture
                                                    .isNotEmpty
                                                ? item.profilePicture
                                                : TImages.user,
                                            imageType: item.profilePicture
                                                    .isNotEmpty
                                                ? ImageType.network
                                                : ImageType.asset,
                                          ),
                                          const SizedBox(
                                            width: TSizes.spaceBtwItems,
                                          ),
                                          Text(item.name),
                                          Text(' (${item.phoneNumber})',
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .labelLarge)
                                        ]),
                                  ))
                              .toList(),
                        );
                      },
                    ),
                    const SizedBox(height: TSizes.spaceBtwInputFields),
                    TextFormField(
                      controller: controller.category,
                      validator: (value) =>
                          TValidator.validateEmptyText('Category', value),
                      decoration: const InputDecoration(
                          label: Text('Category'),
                          prefixIcon: Icon(Iconsax.category)),
                    ),
                    const SizedBox(height: TSizes.spaceBtwInputFields),
                    TextFormField(
                      controller: controller.quantity,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                          label: Text('Quantity'),
                          prefixIcon: Icon(Iconsax.add)),
                    ),
                    const SizedBox(height: TSizes.spaceBtwInputFields),
                    TextFormField(
                      controller: controller.rate,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                          label: Text('Rate'),
                          prefixIcon: Icon(Iconsax.money)),
                    ),
                    const SizedBox(height: TSizes.spaceBtwInputFields),
                    TextFormField(
                      controller: controller.labor,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                          label: Text('Labor Charges'),
                          prefixIcon: Icon(Iconsax.user_octagon)),
                    ),
                    const SizedBox(height: TSizes.spaceBtwInputFields),
                    TextFormField(
                      controller: controller.paymentRemarks,
                      decoration: const InputDecoration(
                          label: Text('Payment Remarks'),
                          prefixIcon: Icon(Iconsax.note)),
                    ),
                    const SizedBox(height: TSizes.spaceBtwInputFields),
                    TextFormField(
                      controller: controller.additionalInfo,
                      decoration: const InputDecoration(
                          label: Text('Additional Info'),
                          prefixIcon: Icon(Iconsax.information)),
                    ),
                    const SizedBox(height: TSizes.spaceBtwInputFields),
                    TextFormField(
                      controller: controller.arrivalNo,
                      validator: (value) =>
                          TValidator.validateEmptyText('arrivalNo', value),
                      decoration: const InputDecoration(
                          label: Text('Arrival No'),
                          prefixIcon: Icon(Iconsax.car)),
                    ),
                    const SizedBox(height: TSizes.spaceBtwInputFields),
                  ],
                ),
              ),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                    onPressed: () =>
                        controller.updateTransaction(transaction),
                    child: const Text("Update")),
              ),
              const SizedBox(height: TSizes.spaceBtwSections),
              SizedBox(
                width: 200,
                child: TextButton(
                    onPressed: () =>
                        controller.deleteTransaction(transaction),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Iconsax.trash,
                            color: Colors.red, size: TSizes.iconSm),
                        Text(" Delete Client",
                            style: Theme.of(context)
                                .textTheme
                                .bodyLarge!
                                .apply(color: TColors.error)),
                      ],
                    )),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
