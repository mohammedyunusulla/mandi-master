import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import '../../../../common/widgets/appbar/appbar.dart';
import '../../../../utils/constants/enums.dart';
import '../../../../utils/formatters/formatter.dart';
import '../../../controller/reports/reports_all_controller.dart';


class AllReport extends StatelessWidget {
  AllReport({Key? key}) : super(key: key);

  final ReportController controller = Get.put(ReportController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const TAppBar(title: Text('Complete Statement')),
      body: PdfPreview(
        initialPageFormat: PdfPageFormat.legal.landscape,
        build: (format) => _generatePdf(format, 'Complete Statement'),
      ),
    );
  }

  Future<Uint8List> _generatePdf(PdfPageFormat format, String title) async {
    final customFormat = PdfPageFormat(format.width+100.0, format.height);
      final pdf = pw.Document(version: PdfVersion.pdf_1_5, compress: true);

    // Calculate the total number of rows required for the table
    final int totalRows = controller.allTransactions.length + 2; // Add 2 for header and total row
    // Calculate the maximum number of rows that can fit on one page
    final int maxRowsPerPage = (format.availableHeight / 21).floor();
    // Calculate the number of pages needed to accommodate all rows
    final int totalPages = (totalRows / maxRowsPerPage).ceil();

    for (int pageIndex = 0; pageIndex < totalPages; pageIndex++) {
      //calculate start and end index to print
      final int startIndex = pageIndex * maxRowsPerPage;
      final int endIndex = (pageIndex +1) * maxRowsPerPage;
      pdf.addPage(
        pw.Page(
          pageFormat: customFormat,
          build: (context) {
            return pw.Padding(
                padding: const pw.EdgeInsets.symmetric(horizontal: 15,vertical: 15),
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.Text("$title - Page ${pageIndex+1} of $totalPages",
                        style: pw.TextStyle(color: PdfColors.black, fontWeight: pw.FontWeight.bold)),
                    pw.SizedBox(height: 10),
                    _buildTable(startIndex, endIndex),
                    // Add the total row only on the last page
                    if (pageIndex == totalPages -1) _buildTotalRow(),
                  ],
                )
            );
          },
        ),
      );
    }

    return pdf.save();
  }

  pw.Widget _buildTable(int startIndex, int endIndex) {
    // sort list by date
    controller.allTransactions.sort((a, b) => (b.transactionDate ?? DateTime(0)).compareTo(a.transactionDate ?? DateTime(0)));

    return pw.Table(
      columnWidths: {
        0: const pw.FixedColumnWidth(1.3), // Total cell
        1: const pw.FixedColumnWidth(3), // Buy Quantity cell
        2: const pw.FixedColumnWidth(2), // Buy Price cell
        3: const pw.FixedColumnWidth(2), // Buy Price cell
        4: const pw.FixedColumnWidth(2.7), // Sell Quantity cell
        5: const pw.FixedColumnWidth(3), // Sell Price cell
        6: const pw.FixedColumnWidth(1.5), // Sell Price cell
        7: const pw.FixedColumnWidth(1.5), // Sell Price cell
        8: const pw.FixedColumnWidth(1.5), // Sell Price cell
        9: const pw.FixedColumnWidth(1.5), // Sell Price cell
      },
      border: pw.TableBorder.all(width: 1.0),
      children: [
        pw.TableRow(
          children: [
            _tableCell('Date', isHeader: true),
            _tableCell('Buy Party', isHeader: true),
            _tableCell('Buy Quantity (KG)', isHeader: true),
            _tableCell('Buy Price (INR)', isHeader: true),
            _tableCell('Category', isHeader: true),
            _tableCell('Sell Party', isHeader: true),
            _tableCell('Sell Quantity', isHeader: true),
            _tableCell('Sell Price (INR)', isHeader: true),
            _tableCell('Total Sell Price', isHeader: true),
            _tableCell('Commission', isHeader: true),
          ],
        ),
        if (controller.isLoading.value) ...[
          pw.TableRow(
            children: [
              for (int i = 0; i < 7; i++) _tableCell('Loading...'),
            ],
          ),
        ] else ...[
          for (var i = startIndex; i < endIndex && i < controller.allTransactions.length; i++) ...[
            if (controller.allTransactions[i].transactionType == TransactionType.buy)
              pw.TableRow(
                children: [
                  _tableCell(TFormatter.formatDate(controller.allTransactions[i].transactionDate).toString()),
                  _tableCell(controller.allTransactions[i].name),
                  _tableCell(controller.allTransactions[i].quantity.toString()),
                  _tableCell(controller.allTransactions[i].amount.toString()),
                  _tableCell(controller.allTransactions[i].category),
                  _tableCell(""),
                  _tableCell(""),
                  _tableCell(""),
                  _tableCell(""),
                  _tableCell(""),
                ],
              ),
            if (controller.allTransactions[i].transactionType == TransactionType.sell)
              pw.TableRow(
                children: [
                  _tableCell(TFormatter.formatDate(controller.allTransactions[i].transactionDate).toString()),
                  _tableCell(""),
                  _tableCell(""),
                  _tableCell(""),
                  _tableCell(controller.allTransactions[i].category),
                  _tableCell(controller.allTransactions[i].name),
                  _tableCell(controller.allTransactions[i].quantity.toString()),
                  _tableCell(controller.allTransactions[i].amount.toString()),
                  _tableCell((controller.allTransactions[i].quantity * controller.allTransactions[i].amount).toString()),
                  _tableCell(controller.allTransactions[i].commissionAmount.toString()),
                ],
              ),
          ],
          // Exclude the total row in this block
        ],
      ],
    );
  }

  pw.Widget _buildTotalRow() {
    double totalBuyPrice = 0.0;
    double totalSellPrice = 0.0;
    double totalBuyQty = 0.0;
    double totalSellQty = 0.0;
    double totalComissionQty = 0.0;
    // Calculate the total buy and sell prices for the entire list
    totalBuyPrice = controller.allTransactions
        .where((record) => record.transactionType == TransactionType.buy)
        .fold<double>(0.0, (previousValue, transaction) => previousValue + transaction.amount);

    totalSellPrice = controller.allTransactions
        .where((record) => record.transactionType == TransactionType.sell)
        .fold<double>(0.0, (previousValue, transaction) => previousValue + (transaction.amount * transaction.quantity));

    totalBuyQty = controller.allTransactions
        .where((record) => record.transactionType == TransactionType.buy)
        .fold<double>(0.0, (previousValue, transaction) => previousValue + transaction.quantity);

    totalSellQty = controller.allTransactions
        .where((record) => record.transactionType == TransactionType.sell)
        .fold<double>(0.0, (previousValue, transaction) => previousValue + transaction.quantity);
    totalComissionQty = controller.allTransactions
        .where((record) => record.transactionType == TransactionType.sell)
        .fold<double>(0.0, (previousValue, transaction) => previousValue + transaction.commissionAmount);

    return pw.Table(
      border: pw.TableBorder.all(width: 1.0),
      columnWidths: {
        0: const pw.FixedColumnWidth(4.3), // Total cell
        1: const pw.FixedColumnWidth(2), // Buy Quantity cell
        2: const pw.FixedColumnWidth(2), // Buy Price cell
        3: const pw.FixedColumnWidth(2.7), // Buy Price cell
        4: const pw.FixedColumnWidth(3), // Sell Quantity cell
        5: const pw.FixedColumnWidth(1.5), // Sell Price cell
        6: const pw.FixedColumnWidth(1.5), // Sell Price cell
        7: const pw.FixedColumnWidth(1.5), // Sell Price cell
        8: const pw.FixedColumnWidth(1.5), // Sell Price cell
      },
      children: [
        pw.TableRow(
          children: [
            _tableCell('Total', isHeader: true),
            _tableCell(totalBuyQty.toStringAsFixed(2)),
            _tableCell(totalBuyPrice.toStringAsFixed(2)),
            _tableCell(""),
            _tableCell(""),
            _tableCell(totalSellQty.toStringAsFixed(2)),
            _tableCell(''),
            _tableCell(totalSellPrice.toStringAsFixed(2)),
            _tableCell(totalComissionQty.toStringAsFixed(2)),
          ],
        ),
      ],
    );
  }

  pw.Widget _tableCell(String text, {bool isHeader = false}) {
    return pw.Padding(
      padding: const pw.EdgeInsets.symmetric(vertical: 2, horizontal: 4),
      child: pw.Container(
        child: pw.Text(
          text,
          style: isHeader ? pw.TextStyle(color: PdfColors.black, fontWeight: pw.FontWeight.bold) : null,
        ),
      ),

    );
  }
}
