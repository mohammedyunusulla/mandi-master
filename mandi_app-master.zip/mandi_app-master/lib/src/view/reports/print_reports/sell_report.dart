
import 'package:flutter/material.dart';
import 'dart:typed_data';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:get/get.dart';

import '../../../../common/widgets/appbar/appbar.dart';
import '../../../../utils/formatters/formatter.dart';
import '../../../controller/reports/reports_all_controller.dart';



class SellReport extends StatelessWidget {

  SellReport({Key? key}) : super(key: key);

  final controller = Get.put(ReportController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const TAppBar(title: Text('PRINT')),
      body: PdfPreview(
        initialPageFormat: PdfPageFormat.letter,

        build: (format) => _generatePdf(format, 'title'),
      ),
    );
  }

  Future<Uint8List> _generatePdf(PdfPageFormat format, String title) async {
    final customFormat = PdfPageFormat(format.width+100.0, format.height);
    final pdf = pw.Document(version: PdfVersion.pdf_1_5, compress: true,);

    // Calculate the total number of rows required for the table
    final int totalRows = controller.sellTransactions.length + 2; // Add 2 for header and total row
    // Calculate the maximum number of rows that can fit on one page
    final int maxRowsPerPage = (format.availableHeight / 25).floor();
    // Calculate the number of pages needed to accommodate all rows
    final int totalPages = (totalRows / maxRowsPerPage).ceil();


    ///Loop to create number of Pages according to number of rows
    for (int pageIndex = 0; pageIndex < totalPages; pageIndex++) {
      //calculate start and end index to print
      final int startIndex = pageIndex * maxRowsPerPage;
      final int endIndex = (pageIndex + 1) * maxRowsPerPage;

      ///Create page
      pdf.addPage(
        pw.Page(
          pageFormat: customFormat,
          build: (context) {
            return pw.Padding(
              padding: const pw.EdgeInsets.all(20),
              child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text("Sell Statement - Page ${pageIndex+1} of $totalPages",style: pw.TextStyle(color: PdfColors.black, fontWeight: pw.FontWeight.bold)),
                  pw.SizedBox(height: 10),
                  _buildTable(startIndex, endIndex),
                  if (pageIndex == totalPages - 1) _buildTotalRow(),
                ],
              )
            );
          },
        ),
      );
    }
    return pdf.save();
  }

  pw.Widget _buildTable(int startIndex, int endIndex) {
    return pw.Table(
      columnWidths: {
        0: const pw.FixedColumnWidth(1.7), // Total cell
        1: const pw.FixedColumnWidth(3.5), // Buy Quantity cell
        2: const pw.FixedColumnWidth(2.5), // Buy Price cell
        3: const pw.FixedColumnWidth(1.5), // Buy Price cell
        4: const pw.FixedColumnWidth(1.5), // Sell Quantity cell
        5: const pw.FixedColumnWidth(1.9), // Sell Price cell
        6: const pw.FixedColumnWidth(1.2), // Sell Price cell
        7: const pw.FixedColumnWidth(1.9), // Sell Price cell
      },
      border: pw.TableBorder.all(
        width: 2.0,
      ),
      children: [
        pw.TableRow(
          children: [
            _tableCell('Date', isHeader: true),
            _tableCell('Client Name', isHeader: true),
            _tableCell('Category', isHeader: true),
            _tableCell('Qty (KG)', isHeader: true),
            _tableCell('Sold Price', isHeader: true),
            _tableCell('Total Price', isHeader: true),
            _tableCell('Labor', isHeader: true),
            _tableCell('Commission', isHeader: true),
          ],
        ),
        // Generate rows from GetX controller data
        if (controller.isLoading.value) ...[
          pw.TableRow(
            children: [
              for (int i = 0; i < 7; i++) _tableCell('Loading...'),
            ],
          ),
        ] else ...[
          for (var i = startIndex; i < endIndex && i < controller.sellTransactions.length; i++)
            pw.TableRow(
              children: [
                _tableCell(TFormatter.formatDate(controller.sellTransactions[i].transactionDate).toString()),
                _tableCell(controller.sellTransactions[i].clientName),
                _tableCell(controller.sellTransactions[i].category),
                _tableCell(controller.sellTransactions[i].quantity.toString()),
                _tableCell(controller.sellTransactions[i].rate.toString()),
                _tableCell((controller.sellTransactions[i].quantity * controller.sellTransactions[i].rate).toString()),
                _tableCell(controller.sellTransactions[i].labor.toString()),
                _tableCell(controller.sellTransactions[i].commissionAmount.toString()),
              ],
            ),
        ],
      ],
    );
  }

  ///Total Row table
  pw.Widget _buildTotalRow() {
    // Calculate the total
    double totalBuyPrice = 0.0;
    double totalLabor = 0.0;
    double totalQuantity = 0.0;
    double totalCommission = 0.0;
    // Calculate the total buy price
    if (!controller.isLoading.value) {
      totalBuyPrice = controller.sellTransactions.fold<double>(0.0, (previousValue, transaction) => previousValue + (transaction.rate * transaction.quantity));
      totalLabor = controller.sellTransactions.fold<double>(0.0, (previousValue, transaction) => previousValue + transaction.labor);
      totalQuantity = controller.sellTransactions.fold<double>(0.0, (previousValue, transaction) => previousValue + transaction.quantity);
      totalCommission = controller.sellTransactions.fold<double>(0.0, (previousValue, transaction) => previousValue + transaction.commissionAmount);
    }

    return pw.Table(
      border: pw.TableBorder.all(
        width: 2.0,
      ),
      columnWidths: {
        0: const pw.FixedColumnWidth(5.2), // Buy Quantity cell
        1: const pw.FixedColumnWidth(2.5), // Buy Price cell
        2: const pw.FixedColumnWidth(1.5), // Buy Price cell
        3: const pw.FixedColumnWidth(1.5), // Sell Quantity cell
        4: const pw.FixedColumnWidth(1.9), // Sell Price cell
        5: const pw.FixedColumnWidth(1.2), // Sell Price cell
        6: const pw.FixedColumnWidth(1.9), // Sell Price cell
      },
      children: [
        // Total row
        pw.TableRow(
          children: [
            _tableCell(''),
            _tableCell('Total', isHeader: true),
            _tableCell(totalQuantity.toString()),
            _tableCell(''),
            _tableCell(totalBuyPrice.toString()),
            _tableCell(totalLabor.toString()),
            _tableCell(totalCommission.toString()),
          ],
        ),
      ],
    );
  }

  ///Design Table Cell
  pw.Widget _tableCell(String text, {bool isHeader = false}) {
    return pw.Padding(
      padding: const pw.EdgeInsets.symmetric(vertical: 2, horizontal: 2),
      child: pw.Text(
        text,
        style: isHeader ? pw.TextStyle(color: PdfColors.black, fontWeight: pw.FontWeight.bold) : null,
      ),
    );
  }
}