import 'package:flutter/material.dart';
import 'package:mandi_app/utils/formatters/formatter.dart';
import 'dart:typed_data';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:get/get.dart';

import '../../../../common/widgets/appbar/appbar.dart';
import '../../../controller/reports/reports_all_controller.dart';

class BuyReport extends StatelessWidget {
  BuyReport({Key? key}) : super(key: key);

  final controller = Get.put(ReportController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const TAppBar(title: Text('Print Buy Statement')),
      body: PdfPreview(
        initialPageFormat: PdfPageFormat.letter,
        build: (format) => _generatePdf(format, 'title'),
      ),
    );
  }

  Future<Uint8List> _generatePdf(PdfPageFormat format, String title) async {
    final customFormat = PdfPageFormat(format.width+100.0, format.height);
    final pdf = pw.Document(version: PdfVersion.pdf_1_5, pageMode: PdfPageMode.outlines);

    // Calculate the total number of rows required for the table
    final int totalRows = controller.buyTransactions.length + 2; // Add 2 for header and total row
    // Calculate the maximum number of rows that can fit on one page
    final int maxRowsPerPage = (format.availableHeight / 25).floor();
    // Calculate the number of pages needed to accommodate all rows
    final int totalPages = (totalRows / maxRowsPerPage).ceil();

    /// Loop through number of Pages to add a page
    for (int pageIndex = 0; pageIndex < totalPages; pageIndex++) {
      //calculate start and end index to print
      final int startIndex = pageIndex * maxRowsPerPage;
      final int endIndex = (pageIndex + 1) * maxRowsPerPage;
      /// Create page
      pdf.addPage(
        pw.Page(
          pageFormat: customFormat,
          build: (context) {
            return pw.Padding(
              padding: const pw.EdgeInsets.all(20),
              child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text("Buy Statement - Page ${pageIndex+1} of $totalPages",
                      style: pw.TextStyle(color: PdfColors.black, fontWeight: pw.FontWeight.bold)),
                  pw.SizedBox(height: 10),
                  _buildTable(startIndex, endIndex),
                  if (pageIndex == totalPages - 1) _buildTotalRow(),
                ],
              ),
            );
          },
        ),
      );
      // calculateEndIndex = calculateEndIndex+10;
    }

    return pdf.save();
  }

  pw.Widget _buildTable(int startIndex, int endIndex) {
    return pw.Table(
      columnWidths: {
        0: const pw.FixedColumnWidth(1.5), // Total cell
        1: const pw.FixedColumnWidth(3.5), // Buy Quantity cell
        2: const pw.FixedColumnWidth(2.5), // Buy Price cell
        3: const pw.FixedColumnWidth(1.5), // Buy Price cell
        4: const pw.FixedColumnWidth(1.5), // Sell Quantity cell
        5: const pw.FixedColumnWidth(1.5), // Sell Price cell
        6: const pw.FixedColumnWidth(1.5), // Sell Price cell
      },
      border: pw.TableBorder.all(
        width: 1.0,
      ),
      children: [
        pw.TableRow(
          children: [
            _tableCell('Date', isHeader: true),
            _tableCell('Client Name', isHeader: true),
            _tableCell('Category', isHeader: true),
            _tableCell('Quantity (KG)', isHeader: true),
            _tableCell('Buy Price', isHeader: true),
            _tableCell('Total Price', isHeader: true),
            _tableCell('Labor', isHeader: true),
          ],
        ),
        if (controller.isLoading.value) ...[
          pw.TableRow(
            children: [
              for (int i = 0; i < 7; i++) _tableCell('Loading...'),
            ],
          ),
        ] else ...[
          for (var i = startIndex; i < endIndex && i < controller.buyTransactions.length; i++)
            pw.TableRow(
              children: [
                _tableCell(TFormatter.formatDate(controller.buyTransactions[i].transactionDate).toString()),
                _tableCell(controller.buyTransactions[i].clientName),
                _tableCell(controller.buyTransactions[i].category),
                _tableCell(controller.buyTransactions[i].quantity.toString()),
                _tableCell(controller.buyTransactions[i].rate.toString()),
                _tableCell((controller.buyTransactions[i].quantity * controller.buyTransactions[i].rate).toString()),
                _tableCell(controller.buyTransactions[i].labor.toString()),
              ],
            ),
          // Total row
        ],
      ],
    );
  }

  pw.Widget _buildTotalRow() {
    // Calculate the total
    double totalLabor = 0.0;
    double totalBuyPrice = 0.0;
    double totalQuantity = 0.0;
    // Calculate the total buy price
    if (!controller.isLoading.value) {
      totalBuyPrice = controller.buyTransactions.fold<double>(0.0, (previousValue, transaction) => previousValue + (transaction.rate * transaction.quantity));
      totalLabor = controller.buyTransactions.fold<double>(0.0, (previousValue, transaction) => previousValue + transaction.labor);
      totalQuantity = controller.buyTransactions.fold<double>(0.0, (previousValue, transaction) => previousValue + transaction.quantity);
    }

    return pw.Table(
      border: pw.TableBorder.all(
        width: 1.0,
      ),
      columnWidths: {
        0: const pw.FixedColumnWidth(5), // Buy Quantity cell
        1: const pw.FixedColumnWidth(2.5), // Buy Price cell
        2: const pw.FixedColumnWidth(1.5), // Buy Price cell
        3: const pw.FixedColumnWidth(1.5), // Sell Quantity cell
        4: const pw.FixedColumnWidth(1.5), // Sell Price cell
        5: const pw.FixedColumnWidth(1.5), // Sell Price cell
      },
      children: [
        pw.TableRow(
          children: [
            _tableCell(''),
            _tableCell('Sub Total', isHeader: true),
            _tableCell(totalQuantity.toString()),
            _tableCell(''),
            _tableCell(totalBuyPrice.toString()), // Display the total buy price
            _tableCell(totalLabor.toString()),
          ],
        ),
      ],
    );
  }

  pw.Widget _tableCell(String text, {bool isHeader = false}) {
    return pw.Padding(
      padding: const pw.EdgeInsets.symmetric(vertical: 2, horizontal: 2),
      child: pw.Text(
        text,
        style: isHeader ? pw.TextStyle(color: PdfColors.black, fontWeight: pw.FontWeight.bold) : null,
      ),
    );
  }
}
