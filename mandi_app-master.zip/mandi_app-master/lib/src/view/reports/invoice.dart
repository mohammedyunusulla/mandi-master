import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mandi_app/src/models/transaction_model.dart';
import 'package:mandi_app/utils/formatters/formatter.dart';
import 'dart:typed_data';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import '../../controller/client/client_controller.dart';
import '../../controller/user/user_controller.dart';

class Invoice extends StatelessWidget {
  Invoice({
    super.key,
    required this.transactionModel,
  });

  final TransactionModel transactionModel;
  final UserController userController = Get.put(UserController());
  final ClientController clientController = Get.put(ClientController());

  @override
  Widget build(BuildContext context) {
    // bool isDarkMode = THelperFunctions.isDarkMode(context);
    clientController.loadData();
    return Scaffold(
      appBar: AppBar(
        title: Text(
            "Invoice",
            style: Theme.of(context).textTheme.titleLarge!.copyWith(),
          ),
      ),
      body: Obx(() {
        if (clientController.loading.value) {
          return const Center(
            child: CircularProgressIndicator(),
          );
        } else {
          return PdfPreview(build: (format) => _generatePdf(format, 'title'));
        }
      }),
    );
  }

  Future<Uint8List> _generatePdf(PdfPageFormat format, String title) async {
    final clientDetails = clientController.clients.firstWhere((client) => client.id == transactionModel.clientId);
    final totalAmount = transactionModel.quantity * transactionModel.rate;
    final pdf = pw.Document(version: PdfVersion.pdf_1_5, compress: true);

    pdf.addPage(
      pw.Page(
        pageFormat: format,
        build: (context) {
          return pw.Container(
            decoration: pw.BoxDecoration(border: pw.Border.all()),
            margin: const pw.EdgeInsets.all(20),
            child: pw.Column(
              children: [
                pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Padding(
                      padding: const pw.EdgeInsets.only(left: 10, top: 10, bottom: 10),
                      child: pw.Column(
                        crossAxisAlignment: pw.CrossAxisAlignment.start,
                        children: [
                          pw.Text(userController.user.value.name,
                              style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 16)),
                          pw.SizedBox(height: 8),
                          pw.Text(userController.user.value.address),
                        ],
                      ),
                    ),
                    pw.Container(
                      padding: const pw.EdgeInsets.only(right: 10),
                      alignment: pw.Alignment.bottomRight,
                      height: 80.5,
                      child: pw.Text('INVOICE', style: const pw.TextStyle(fontSize: 35, color: PdfColors.indigo800)),
                    ),
                  ],
                ),
                pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Expanded(
                      child: pw.Container(
                        decoration: pw.BoxDecoration(
                            border: pw.TableBorder.symmetric(inside: const pw.BorderSide(), outside: const pw.BorderSide())),
                        height: 75,
                        padding: const pw.EdgeInsets.only(left: 10, top: 10, bottom: 10),
                        child: pw.Column(
                          crossAxisAlignment: pw.CrossAxisAlignment.start,
                          children: [
                            pw.Text(clientDetails.address != "" ? clientDetails.address : 'no client address'),
                          ],
                        ),
                      ),
                    ),
                    pw.Expanded(
                      child: pw.Container(
                        height: 75,
                        decoration: pw.BoxDecoration(
                            border: pw.TableBorder.symmetric(inside: const pw.BorderSide(), outside: const pw.BorderSide())),
                        padding: const pw.EdgeInsets.only(left: 10, top: 10, bottom: 10),
                        child: pw.Column(
                          crossAxisAlignment: pw.CrossAxisAlignment.start,
                          children: [
                            pw.Text('Invoice No: INV-000003'),
                            pw.Text('Invoice Date: ${TFormatter.formatDate(DateTime.now())}'),
                            pw.Text('Transaction Date: ${TFormatter.formatDate(transactionModel.updatedAt)}'),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                pw.Table(
                  border: pw.TableBorder.symmetric(outside: const pw.BorderSide(), inside: const pw.BorderSide()),
                  columnWidths: <int, pw.TableColumnWidth>{
                    0: const pw.FixedColumnWidth(7),
                    1: const pw.FixedColumnWidth(50),
                    2: const pw.FixedColumnWidth(25),
                    3: const pw.FixedColumnWidth(15),
                    4: const pw.FixedColumnWidth(20),
                    5: const pw.FixedColumnWidth(23.4),
                  },
                  defaultVerticalAlignment: pw.TableCellVerticalAlignment.middle,
                  children: [
                    pw.TableRow(
                      decoration: const pw.BoxDecoration(border: pw.Border(bottom: pw.BorderSide())),
                      children: [
                        pw.Container(
                          padding: const pw.EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                          alignment: pw.Alignment.center,
                          color: PdfColors.indigo800,
                          child: pw.Text('#', style: const pw.TextStyle(fontSize: 13, color: PdfColors.white)),
                        ),
                        pw.Container(
                          color: PdfColors.indigo800,
                          padding: const pw.EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                          child: pw.Text('Customer Name', style: const pw.TextStyle(fontSize: 13, color: PdfColors.white)),
                        ),
                        pw.Container(
                          color: PdfColors.indigo800,
                          padding: const pw.EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                          child: pw.Text('Category', style: const pw.TextStyle(fontSize: 13, color: PdfColors.white)),
                        ),
                        pw.Container(
                          color: PdfColors.indigo800,
                          padding: const pw.EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                          child: pw.Text('Qty', style: const pw.TextStyle(fontSize: 13, color: PdfColors.white)),
                        ),
                        pw.Container(
                          color: PdfColors.indigo800,
                          padding: const pw.EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                          child: pw.Text('Rate', style: const pw.TextStyle(fontSize: 13, color: PdfColors.white)),
                        ),
                        pw.Container(
                          color: PdfColors.indigo800,
                          padding: const pw.EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                          child: pw.Text('Amount', style: const pw.TextStyle(fontSize: 13, color: PdfColors.white)),
                        ),
                      ],
                    ),
                    pw.TableRow(
                      decoration: const pw.BoxDecoration(border: pw.Border(bottom: pw.BorderSide())),
                      children: [
                        pw.Container(
                          alignment: pw.Alignment.center,
                          padding: const pw.EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                          child: pw.Text('1', style: const pw.TextStyle(fontSize: 13)),
                        ),
                        pw.Container(
                          padding: const pw.EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                          child: pw.Text(transactionModel.clientName, style: const pw.TextStyle(fontSize: 13)),
                        ),
                        pw.Container(
                          padding: const pw.EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                          child: pw.Text(transactionModel.category, style: const pw.TextStyle(fontSize: 13)),
                        ),
                        pw.Container(
                          padding: const pw.EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                          child: pw.Text(transactionModel.quantity.toString(), style: const pw.TextStyle(fontSize: 13)),
                        ),
                        pw.Container(
                          padding: const pw.EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                          child: pw.Text(transactionModel.rate.toString(), style: const pw.TextStyle(fontSize: 13)),
                        ),
                        pw.Container(
                          alignment: pw.Alignment.centerRight,
                          padding: const pw.EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                          child: pw.Text(totalAmount.toString(), style: const pw.TextStyle(fontSize: 13)),
                        ),
                      ],
                    ),
                  ],
                ),
                pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.end,
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.Container(
                      width: 177,
                      padding: const pw.EdgeInsets.only(left: 10, right: 5, bottom: 10, top: 5),
                      decoration: pw.BoxDecoration(
                        border: pw.TableBorder.symmetric(inside: const pw.BorderSide(), outside: const pw.BorderSide()),
                        color: PdfColors.indigo200,
                      ),
                      child: pw.Column(
                        children: [
                          pw.SizedBox(height: 5),
                          pw.Row(
                            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                            children: [
                              pw.Text('Sub Total', style: pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
                              pw.Text(totalAmount.toString(),
                                  style: pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                pw.Container(
                  padding: const pw.EdgeInsets.symmetric(horizontal: 10),
                  child: pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: [
                      pw.SizedBox(height: 20),
                      pw.Text('Terms and Conditions: '),
                      pw.SizedBox(height: 5),
                      pw.Text('Full Payment is due upon receipt of this invoice. Late'
                          'payments may incur additional charges or interest as per the applicable laws.'),
                    ],
                  ),
                ),
                pw.Container(
                  padding: const pw.EdgeInsets.only(left: 10),
                  child: pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: [
                      pw.SizedBox(height: 20),
                      pw.Text('Thanks For Your Business'),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );

    return pdf.save();
  }
}
