import 'package:flutter/material.dart';
import 'package:mandi_app/utils/constants/colors.dart';

import '../../../../utils/constants/sizes.dart';

class ReportTableForBuy extends StatelessWidget {
  const ReportTableForBuy({super.key, });

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Padding(
          padding: const EdgeInsets.all(TSizes.defaultSpace),
          child: SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(" Buy Statement", style: Theme.of(context).textTheme.headlineSmall!.apply(color: TColors.black),),
                  DataTable(
                    border: TableBorder.all(
                      width: 2.0,
                      color:TColors.black,),
                    columns:  <DataColumn>[
                      DataColumn(label: Text('Date', style: Theme.of(context).textTheme.titleLarge!.apply(color: TColors.black),)),
                      DataColumn(label: Text('Client Name',style: Theme.of(context).textTheme.titleLarge!.apply(color: TColors.black))),
                      DataColumn(label: Text('Category',style: Theme.of(context).textTheme.titleLarge!.apply(color: TColors.black))),
                      DataColumn(label: Text('Quantity (KG)',style: Theme.of(context).textTheme.titleLarge!.apply(color: TColors.black))),
                      DataColumn(label: Text('Buy Price (INR)',style: Theme.of(context).textTheme.titleLarge!.apply(color: TColors.black))),
                      DataColumn(label: Text('Total Price (INR)',style: Theme.of(context).textTheme.titleLarge!.apply(color: TColors.black))),
                      DataColumn(label: Text('Labor',style: Theme.of(context).textTheme.titleLarge!.apply(color: TColors.black))),
                    ],
                    rows: List<DataRow>.generate(
                      4+1,
                      (index) => index < 4 ? DataRow(
                        cells: <DataCell>[
                          DataCell(Text('Date $index')),
                          DataCell(Text('Client $index')),
                          const DataCell(Text('Bada-mi')),
                          DataCell(Text('${100 + index}')),
                          DataCell(Text('${10 + index}')),
                          DataCell(Text('${(10 + index) * (100 + index)}')),
                          DataCell(Text('${100 + index}')),
                        ],
                      ) : DataRow(
                        cells: <DataCell>[
                          const DataCell(Text('')),
                          const DataCell(Text('')),
                          DataCell(Text('Total', style: Theme.of(context).textTheme.titleLarge!.apply(color: TColors.black),)),
                          DataCell(Text('${100 + index}')),
                          DataCell(Text('${10 + index}')),
                          DataCell(Text('${(10 + index) * (100 + index)}')),
                          DataCell(Text('${100 + index}')),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
