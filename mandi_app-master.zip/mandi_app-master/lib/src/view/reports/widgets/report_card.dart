import 'package:flutter/material.dart';
import '../../../../common/widgets/custom_shapes/containers/circular_container.dart';
import '../../../../utils/constants/colors.dart';
import '../../../../utils/constants/sizes.dart';


class TCardReport extends StatelessWidget {
  const TCardReport({
    super.key,
    required this.backgroundColor,
    required this.image,
    required this.title,
    required this.icon,
    this.onTap,
  });

  /// Card background color
  final Color backgroundColor;

  final String image, title;
  final IconData icon;


  final Function()? onTap;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: TSizes.spaceBtwItems),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(TSizes.cardRadiusLg * 2),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [backgroundColor.withOpacity(0.7), backgroundColor],
        ),
      ),

      /// Use Stack in order to add White Circular Container in the BG
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(TSizes.cardRadiusLg * 2),
        child: Stack(
          children: [
            Positioned(
              bottom: -120,
              right: -180,
              child: TCircularContainer(width: 300, height: 200, backgroundColor: TColors.white.withOpacity(0.1)),
            ),

            /// Main Card Body
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: TSizes.sm, vertical: TSizes.md - 3),
              child: Column(
                children: [
                  /// Upper List Tile
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Expanded(
                        child: ListTile(
                          leading: Icon(icon, color: TColors.white),
                          title: Center(child: Text(title.toUpperCase(), style: Theme.of(context).textTheme.headlineSmall!.apply(color: TColors.white))),
                          trailing: const Icon(Icons.download, color: TColors.white),
                        ),
                      )
                    ],
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
