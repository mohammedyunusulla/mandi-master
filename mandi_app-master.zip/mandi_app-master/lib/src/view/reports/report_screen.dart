import 'package:date_field/date_field.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:iconsax/iconsax.dart';
import 'package:mandi_app/src/view/reports/widgets/report_card.dart';
import '../../../common/widgets/drawer/drawer.dart';
import '../../../utils/constants/colors.dart';
import '../../../utils/constants/image_strings.dart';
import '../../../utils/constants/sizes.dart';
import '../../../utils/helpers/helper_functions.dart';
import '../../controller/reports/reports_all_controller.dart';

class ReportsScreen extends StatelessWidget {
  const ReportsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    bool isDarkMode = THelperFunctions.isDarkMode(context);
    final ReportController reportController = Get.put(ReportController());
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Reports",
          style: Theme.of(context).textTheme.titleLarge!.copyWith(
                color: isDarkMode ? TColors.light : TColors.dark,
              ),
        ),
        iconTheme: IconThemeData(
            color: THelperFunctions.isDarkMode(context)
                ? TColors.light
                : TColors.dark),
      ),
      drawer: const TDrawer(),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(TSizes.defaultSpace),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: DateTimeFormField(
                      decoration: const InputDecoration(labelText: 'Date From'),
                      mode: DateTimeFieldPickerMode.date,
                      onChanged: (DateTime? value) {
                        reportController.fromDate.value = value;
                      },
                    ),
                  ),
                  const SizedBox(width: TSizes.defaultSpace),
                ],
              ),
              const SizedBox(height: TSizes.defaultSpace),
              Row(
                children: [
                  Expanded(
                    child: DateTimeFormField(
                      decoration: const InputDecoration(labelText: 'Date To'),
                      mode: DateTimeFieldPickerMode.date,
                      onChanged: (DateTime? value) {
                        reportController.toDate.value = value;
                      },
                    ),
                  ),
                  const SizedBox(width: TSizes.defaultSpace),
                ],
              ),
              const SizedBox(height: TSizes.defaultSpace),
              // Rest of your UI...

              const SizedBox(height: TSizes.spaceBtwItems),
              TCardReport(
                onTap: () => reportController.fetchTransactions('buy'),
                title: 'Buy',
                image: TImages.user,
                backgroundColor: Colors.purple.withOpacity(0.7),
                icon: Iconsax.shopping_bag,
              ),
              const SizedBox(height: TSizes.spaceBtwItems),
              TCardReport(
                onTap: () => reportController.fetchTransactions('sell'),
                title: 'Sell',
                image: TImages.user,
                backgroundColor: TColors.primary.withOpacity(0.7),
                icon: Iconsax.shopping_cart,
              ),
              const SizedBox(height: TSizes.spaceBtwItems),
              TCardReport(
                onTap: () => reportController.fetchTransactions('all'),
                title: 'Complete Statement',
                image: TImages.user,
                backgroundColor: Colors.red.withOpacity(0.7),
                icon: Iconsax.money,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
