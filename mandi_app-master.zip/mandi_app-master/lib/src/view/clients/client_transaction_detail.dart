import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mandi_app/src/models/client_model.dart';
import '../../../utils/constants/colors.dart';
import '../../controller/client/client_transaction_controller.dart';
import '../../controller/client/edit_client_controller.dart';
import '../../models/transaction_model.dart';
import 'advance_details/widgets/client_advance_details.dart';
import 'advance_details/widgets/client_details_with_edit.dart';
import '../../../common/widgets/custom_shapes/containers/mandi_details_card.dart';
import '../../../common/widgets/images/t_circular_image.dart';
import '../../../utils/constants/enums.dart';
import '../../../utils/constants/image_strings.dart';
import '../../../utils/constants/sizes.dart';
import '../../../utils/helpers/helper_functions.dart';

class ClientTransaction extends StatelessWidget {
  ClientTransaction({
    super.key,
    required this.client,
  });

  final ClientModel client;
  final co = Get.put(ClientUpdateController());

  @override
  Widget build(BuildContext context) {

    final controller = ClientTransactionController();
    controller.fetchClientTransactions(client.id);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            image: DecorationImage(
              image: AssetImage('assets/images/background/mandifood.jpg'),
              fit: BoxFit.cover,
            ),
          ),
          child: Container(
            color: Colors.black.withOpacity(0.7),
          ),
        ),
        title: Text(
          'Client Transactions',
          style: Theme.of(context).textTheme.titleLarge!.copyWith(
                color: TColors.light,
              ),
        ),
        iconTheme: const IconThemeData(
          color: TColors.light,
        ),
      ),
      body: Stack(
        children: [
          ///Background Image of the screen
          ImageFiltered(
            imageFilter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: Container(
              width: double.infinity,
              height: double.infinity,
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('assets/images/background/mandifood.jpg'),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),

          ///Body Design
          SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(TSizes.defaultSpace),
              child: Column(
                children: [

                  /// Client Details
                  ClientDetails(client: client),
                  /// Client details end

                  const SizedBox(height: TSizes.spaceBtwSections),

                  ///Advance Details
                  ClientAdvanceDetails(client: client, buyTransactions: controller.buyTransactions),
                  ///Advance Details ends
                  const SizedBox(height: TSizes.spaceBtwSections),
                  // Buy Transactions of client
                  _transactionList("Buy Transactions", controller.buyTransactions,controller),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _transactionList(String title, RxList<TransactionModel> transactions, ClientTransactionController controller) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: TColors.white),
        ),
        const SizedBox(height: 10),
        Obx(() {
          return controller.loading.value
              ? const Center(child: CircularProgressIndicator())
              : transactions.isEmpty
              ? const Text('No transactions available.')
              : ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: transactions.length,
                  itemBuilder: (_, index) {
                    final transaction = transactions[index];
                    return TMandiDetailsCard(
                      onTap: () {
                        // Add your logic for handling the transaction tap
                      },
                      title: transaction.quantity.toString(),
                      // Replace with actual transaction details
                      leading: const TCircularImage(
                        padding: 0,
                        image: TImages.user,
                        imageType: ImageType.asset,
                      ),
                      subTitle: transaction.rate.toString(),
                      // Replace with actual transaction details
                      backgroundColor: THelperFunctions.getBackgroundColors(index),
                    );
                  },
                );
        }),
        const SizedBox(height: 20),
      ],
    );
  }
}

