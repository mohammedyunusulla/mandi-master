import 'package:date_field/date_field.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:iconsax/iconsax.dart';

import '../../../../common/widgets/custom_shapes/containers/advance_card.dart';
import '../../../../utils/constants/sizes.dart';
import '../../../../utils/helpers/helper_functions.dart';
import '../../../../utils/validators/validation.dart';
import '../../../controller/client/client_advance_controller.dart';
import 'edit_advance_screen.dart';

class ClientAdvanceScreen extends StatelessWidget {
  ClientAdvanceScreen({super.key, required this.clientId, this.userId});

  final String clientId;
  final String? userId;

  final controller = Get.put(ClientAdvanceController());

  @override
  Widget build(BuildContext context) {
    controller.loadData(clientId);
    return Scaffold(
      appBar: AppBar(title: const Text('Advance Details')),
      body: Padding(
        padding: const EdgeInsets.all(TSizes.defaultSpace),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Form(
              key: controller.clientAdvanceForm,
              child: Column(
                children: [
                  DateTimeFormField(
                    decoration: const InputDecoration(hintText: 'Select Date'),
                    mode: DateTimeFieldPickerMode.date,
                    onChanged: (DateTime? dateTime) => controller.advanceDate.value = dateTime,
                    initialPickerDateTime: controller.advanceDate.value,
                    initialValue: controller.advanceDate.value,
                  ),
                  const SizedBox(height: TSizes.spaceBtwInputFields),
                  TextFormField(
                    // Todo: Add Digits Only Format
                    keyboardType: TextInputType.number,
                    inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.digitsOnly],
                    controller: controller.advanceTextField,
                    validator: (value) => TValidator.validateEmptyText('Advance', value),
                    decoration: const InputDecoration(
                      label: Text('Advance Price'),
                      prefixIcon: Icon(Iconsax.money),
                    ),
                  ),
                  const SizedBox(height: TSizes.spaceBtwSections),
                  SizedBox(
                    width: double.infinity,
                    child:
                        ElevatedButton(onPressed: () => controller.createClientAdvance(clientId, userId), child: const Text("Add Advance")),
                  ),
                ],
              ),
            ),

            const SizedBox(height: TSizes.spaceBtwSections),

            /// All Advances
            const Text("All Advances", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: TSizes.spaceBtwItems),
            Expanded(
              child: _advanceList(),
            )
          ],
        ),
      ),
    );
  }

  Obx _advanceList() {
    return Obx(() {
      return controller.loading.value
          ? const Center(child: CircularProgressIndicator())
          : controller.filteredAdvances.isEmpty
              ? const Center(child: Text('No advances found.'))
              : ListView.builder(
                  shrinkWrap: true,
                  itemCount: controller.filteredAdvances.length,
                  itemBuilder: (_, index) {
                    final advance = controller.filteredAdvances[index];
                    return GestureDetector(
                      onTap: () => Get.to(EditAdvanceScreen(advance: advance)),
                      child: TAdvanceCard(
                        title: "Advance Given: ${advance.advance.toString()}",
                        subTitle: "Date: ${advance.formattedAdvanceDate}",
                        backgroundColor: THelperFunctions.getBackgroundColors(index),
                      ),
                    );
                  },
                );
    });
  }

// Obx _advanceList() {
//   return Obx(() {
//     return controller.loading.value
//         ? const Center(child: CircularProgressIndicator())
//         : controller.filteredAdvances.isEmpty
//         ? const Center(child: Text('No advances found.'))
//         : SingleChildScrollView(
//       child: ListView.builder(
//         shrinkWrap: true,
//         itemCount: controller.filteredAdvances.length,
//         physics: const NeverScrollableScrollPhysics(),
//         itemBuilder: (_, index) {
//           final advance = controller.filteredAdvances[index];
//           return TAdvanceCard(
//             title: "Advance Given: ${advance.advance.toString()}",
//             subTitle: "Date: ${advance.formattedAdvanceDate}",
//             backgroundColor: THelperFunctions.getBackgroundColors(index),
//           );
//         },
//       ),
//     );
//   });
// }
}
