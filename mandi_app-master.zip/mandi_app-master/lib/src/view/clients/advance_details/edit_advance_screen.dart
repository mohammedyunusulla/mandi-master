import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:iconsax/iconsax.dart';
import '../../../../common/widgets/appbar/appbar.dart';
import '../../../../utils/constants/colors.dart';
import '../../../../utils/constants/sizes.dart';
import '../../../controller/client/client_advance_controller.dart';
import '../../../models/client_advance_model.dart'; // Import your controller

class EditAdvanceScreen extends StatelessWidget {
  final ClientAdvanceModel advance;

  const EditAdvanceScreen({Key? key, required this.advance}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<ClientAdvanceController>();

    return Scaffold(
      appBar: const TAppBar(
        title: Text(
          'Edit Advance',
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(TSizes.defaultSpace),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Form(
              child: Column(
                children: [
                  const SizedBox(height: TSizes.spaceBtwInputFields),
                  TextFormField(
                    initialValue: advance.advance.toString(),
                    onChanged: (value) {
                      // Update advance value in the controller
                      controller.updateAdvance(value);
                    },
                    decoration: const InputDecoration(
                      labelText: 'Edit Advance Price',
                      prefixIcon: Icon(Iconsax.money),
                    ),
                  ),
                  const SizedBox(height: TSizes.spaceBtwSections),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        // Call the method to update the advance price
                        controller.updateClientAdvance(advance);
                      },
                      child: const Text("Update Advance"),
                    ),
                  ),
                  const SizedBox(height: TSizes.spaceBtwSections),
                  SizedBox(
                    width: 200,
                    child: TextButton(
                        onPressed: () {
                          controller.deleteClientAdvance(advance.id);
                          Navigator.of(context).pop();
                        },
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Iconsax.trash,
                                color: Colors.red, size: TSizes.iconSm),
                            Text(" Delete Client Advance",
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyLarge!
                                    .apply(color: TColors.error)),
                          ],
                        )),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
