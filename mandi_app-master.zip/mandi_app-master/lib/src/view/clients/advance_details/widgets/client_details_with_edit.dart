import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mandi_app/common/widgets/custom_shapes/containers/rounded_container.dart';

import '../../../../../utils/constants/colors.dart';
import '../../../../../utils/constants/sizes.dart';
import '../../../../controller/client/edit_client_controller.dart';
import '../../../../models/client_model.dart';
import '../../client_edit_screen.dart';

class ClientDetails extends StatelessWidget {
  ClientDetails({
    super.key,
    required this.client,
  });

  final ClientModel client;
  final controller = Get.find<ClientUpdateController>();

  @override
  Widget build(BuildContext context) {
    controller.initClientData(client);
    return Container(
      decoration: BoxDecoration(color: TColors.primary.withOpacity(0.5), borderRadius: BorderRadius.circular(20)),
      padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 20),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Client Details',
                  style: TextStyle(color: TColors.white, fontSize: TSizes.fontSizeMd, fontWeight: FontWeight.bold)),
              TRoundedContainer(
                backgroundColor: TColors.primary.withOpacity(0.6),
                padding: const EdgeInsets.all(0),
                child: TextButton(
                  onPressed: () => Get.to(() => ClientEditScreen(client: client)),
                  child: const Text('Edit', style: TextStyle(color: TColors.white)),
                ),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                client.name,
                style: const TextStyle(color: TColors.white, fontSize: TSizes.fontSizeSm),
              ),
            ],
          ),
          const SizedBox(
            height: 10,
          ),
          Row(
            children: [
              Text(client.phoneNumber, style: const TextStyle(color: TColors.white, fontSize: TSizes.fontSizeSm)),
            ],
          ),
        ],
      ),
    );
  }
}
