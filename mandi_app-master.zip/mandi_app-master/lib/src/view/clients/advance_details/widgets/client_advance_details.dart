import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mandi_app/common/widgets/custom_shapes/containers/rounded_container.dart';
import 'package:mandi_app/data/repositories/authentication/authentication_repository.dart';
import 'package:mandi_app/src/models/transaction_model.dart';

import '../../../../../utils/constants/colors.dart';
import '../../../../../utils/constants/sizes.dart';
import '../../../../controller/client/client_advance_controller.dart';
import '../../../../models/client_model.dart';
import '../client_advance_screen.dart';

class ClientAdvanceDetails extends StatelessWidget {
  ClientAdvanceDetails({
    super.key,
    required this.client, required this.buyTransactions,
  });

  final ClientModel client;
  final RxList<TransactionModel> buyTransactions;
  final controller = Get.put(ClientAdvanceController());

  @override
  Widget build(BuildContext context) {
    controller.loadData(client.id);
    return Container(
      decoration: BoxDecoration(color: TColors.primary.withOpacity(0.5), borderRadius: BorderRadius.circular(20)),
      padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 20),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Advance Details',
                  style: TextStyle(color: TColors.white, fontSize: TSizes.fontSizeMd, fontWeight: FontWeight.bold)),
              TRoundedContainer(
                backgroundColor: TColors.primary.withOpacity(0.6),
                padding: const EdgeInsets.all(0),
                child: TextButton(
                  onPressed: () => Get.to(() => ClientAdvanceScreen(
                    clientId: client.id,
                    userId: AuthenticationRepository.instance.authUser?.uid,
                  )),
                  child: const Text('View All', style: TextStyle(color: TColors.white)),
                ),
              ),
            ],
          ),

          _totalAdvance(),
          _totalTransactions(),
          const SizedBox(height: 10),
          _totalBalance(),
          const SizedBox(height: TSizes.spaceBtwItems),
          // ShowBottomSheet(clientId: client.id, userId: AuthenticationRepository.instance.authUser?.uid),
        ],
      ),
    );
  }

  Widget _totalAdvance() {
    return Obx(
          () => Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            'Total Advance: ${controller.calculateTotalAdvance(controller.filteredAdvances).toStringAsFixed(1)}',
            style: const TextStyle(
              color: Colors.white,
              fontSize: TSizes.fontSizeSm,
            ),
          ),
        ],
      ),
    );
  }
  Widget _totalTransactions() {
    return Obx(
          () => Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            'Total Transactions: ${controller.calculateTotalTransaction(buyTransactions).toStringAsFixed(1)}',
            style: const TextStyle(
              color: Colors.white,
              fontSize: TSizes.fontSizeSm,
            ),
          ),
        ],
      ),
    );
  }
  Widget _totalBalance() {
    return Obx(
          () => Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            "Balance Amount: ${controller.calculateTotalAdvance(controller.filteredAdvances) - controller.calculateTotalTransaction(buyTransactions)}",
            style: const TextStyle(
              color: Colors.white,
              fontSize: TSizes.fontSizeSm,
            ),
          ),
        ],
      ),
    );
  }
}


