import 'package:date_field/date_field.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:iconsax/iconsax.dart';

import '../../../../../utils/constants/sizes.dart';
import '../../../../../utils/validators/validation.dart';
import '../../../../controller/client/client_advance_controller.dart';

class ShowBottomSheet extends StatelessWidget {
  const ShowBottomSheet({super.key, required this.clientId, required this.userId});

  final String clientId;
  final String? userId;


  @override
  Widget build(BuildContext context) {
    ClientAdvanceController controller = Get.find();
    return SizedBox(
      width: double.infinity,

      child: ElevatedButton(
        style: const ButtonStyle(padding: MaterialStatePropertyAll(EdgeInsets.all(0))),
        child: const Text('Add Advance'),

        onPressed: () {
          showModalBottomSheet(
            context: context,
            builder: (BuildContext context) {

              return SizedBox(
                height: 400,
                child: Padding(
                  padding: const EdgeInsets.all(20),

                  child: Form(
                    key: controller.clientAdvanceForm,
                    child: Column(
                      children: [
                        const Text("Advance", style: TextStyle(fontSize: TSizes.fontSizeLg, fontWeight: FontWeight.bold)),
                        const SizedBox(
                          height: TSizes.spaceBtwSections,
                        ),
                        DateTimeFormField(
                            decoration: InputDecoration(hintText: 'Select Date',hintStyle: TextStyle(color: Colors.grey[600],)),
                            mode: DateTimeFieldPickerMode.date,
                            onChanged: (DateTime? dateTime) => controller.advanceDate.value = dateTime,
                            initialPickerDateTime: controller.advanceDate.value,
                            initialValue: controller.advanceDate.value,
                            ),
                        const SizedBox(height: TSizes.spaceBtwInputFields),
                        TextFormField(
                          controller: controller.advanceTextField,
                          validator: (value) => TValidator.validateEmptyText('Advance', value),
                          decoration: InputDecoration(
                            label: Text('Advance Price', style: TextStyle(color: Colors.grey[600])),
                            prefixIcon: const Icon(Iconsax.money),
                          ),
                        ),
                        const SizedBox(height: TSizes.spaceBtwSections),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(onPressed: () => controller.createClientAdvance(clientId,userId), child: const Text("Submit")),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
