
import 'package:flutter/material.dart';
import '../../../utils/constants/sizes.dart';
import 'client_create_form.dart';

class ClientFormScreen extends StatelessWidget {
  const ClientFormScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: const Text('Add Client')),
      body: const SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(TSizes.defaultSpace),
          child: MyForm(),
        ),
      ),
    );
  }
}
