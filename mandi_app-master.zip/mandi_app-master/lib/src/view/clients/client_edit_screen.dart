import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:iconsax/iconsax.dart';
import 'package:mandi_app/src/controller/client/edit_client_controller.dart';
import 'package:mandi_app/src/models/client_model.dart';
import 'package:mandi_app/utils/constants/colors.dart';
import '../../../common/widgets/images/t_circular_image.dart';
import '../../../utils/constants/enums.dart';
import '../../../utils/constants/image_strings.dart';
import '../../../utils/constants/sizes.dart';
import '../../../utils/constants/text_strings.dart';
import '../../../utils/validators/validation.dart';

class ClientEditScreen extends StatelessWidget {
  const ClientEditScreen({
    super.key,
    required this.client,
  });

  final ClientModel client;

  @override
  Widget build(BuildContext context) {
    final controller = ClientUpdateController();
    controller.initClientData(client);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Clients'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            key: controller.clientForm,
            child: Column(
              children: [
                /// Image
                Obx(() {
                  final localImage = controller.localSelectedImage.value;

                  return localImage != null
                      ? TCircularImage(file: File(localImage.path), width: 120, height: 120, imageType: ImageType.file)
                      : client.profilePicture.isNotEmpty
                          ? TCircularImage(image: client.profilePicture, width: 120, height: 120, imageType: ImageType.network)
                          : const TCircularImage(image: TImages.user, width: 120, height: 120);
                }),

                TextButton(onPressed: () => controller.pickImage(), child: const Text('Upload Image')),
                const SizedBox(height: TSizes.spaceBtwSections),

                /// Text Fields
                TextFormField(
                  controller: controller.name,
                  validator: (value) => TValidator.validateEmptyText('Name', value),
                  decoration: const InputDecoration(label: Text('Name'), prefixIcon: Icon(Iconsax.user)),
                ),
                const SizedBox(height: TSizes.spaceBtwInputFields),
                TextFormField(
                  controller: controller.email,
                  decoration: const InputDecoration(labelText: TTexts.email, prefixIcon: Icon(Iconsax.direct)),
                ),
                const SizedBox(height: TSizes.spaceBtwInputFields),
                TextFormField(
                  controller: controller.mobileNo,
                  decoration: const InputDecoration(label: Text('Mobile No'), prefixIcon: Icon(Iconsax.mobile)),
                ),
                const SizedBox(height: TSizes.spaceBtwInputFields),
                TextFormField(
                  controller: controller.address,
                  decoration: const InputDecoration(label: Text('Address'), prefixIcon: Icon(Iconsax.location)),
                ),
                const SizedBox(height: TSizes.spaceBtwSections * 1.5),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(onPressed: () => controller.updateClient(client), child: const Text("Update")),
                ),
                const SizedBox(height: TSizes.spaceBtwSections),
                SizedBox(
                  width: 200,
                  child: TextButton(
                      onPressed: () => controller.deleteClient(client),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Iconsax.trash, color: Colors.red, size: TSizes.iconSm),
                          Text(" Delete Client", style: Theme.of(context).textTheme.bodyLarge!.apply(color: TColors.error)),
                        ],
                      )),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
