import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:iconsax/iconsax.dart';
import 'package:mandi_app/src/controller/client/create_client_controller.dart';
import 'package:mandi_app/utils/constants/enums.dart';
import 'package:mandi_app/utils/validators/validation.dart';

import '../../../common/widgets/images/t_circular_image.dart';
import '../../../utils/constants/image_strings.dart';
import '../../../utils/constants/sizes.dart';
import '../../../utils/constants/text_strings.dart';

class MyForm extends StatelessWidget {
  const MyForm({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final controller = CreateClientController();
    return Form(
      key: controller.clientForm,
      child: Column(
        children: [
          /// Image
          Obx(() {
            final imageUrl = controller.profileImageUrl.value;

            return imageUrl != null
                ? TCircularImage(image: TImages.user, width: 120, height: 120, imageType: ImageType.file, file: File(imageUrl.path))
                : const TCircularImage(image: TImages.user, width: 120, height: 120);
          }),

          TextButton(onPressed: () => controller.pickImage(), child: const Text('Upload Image')),
          const SizedBox(height: TSizes.spaceBtwSections),

          /// Text Fields
          TextFormField(
            controller: controller.name,
            validator: (value) => TValidator.validateEmptyText('Name', value),
            decoration: const InputDecoration(label: Text('Name'), prefixIcon: Icon(Iconsax.user)),
          ),
          const SizedBox(height: TSizes.spaceBtwInputFields),
          TextFormField(
            controller: controller.email,
            decoration: const InputDecoration(labelText: TTexts.email, prefixIcon: Icon(Iconsax.direct)),
          ),
          const SizedBox(height: TSizes.spaceBtwInputFields),
          TextFormField(
            controller: controller.mobileNo,
            decoration: const InputDecoration(label: Text('Mobile No'), prefixIcon: Icon(Iconsax.mobile)),
            validator: (value) => TValidator.validateEmptyText('Mobile No', value),
          ),
          const SizedBox(height: TSizes.spaceBtwInputFields),
          TextFormField(
            controller: controller.address,
            decoration: const InputDecoration(label: Text('Address'), prefixIcon: Icon(Iconsax.location)),
          ),
          const SizedBox(height: TSizes.spaceBtwSections * 1.5),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(onPressed: () => controller.createClient(), child: const Text("Submit")),
          ),
        ],
      ),
    );
  }
}
