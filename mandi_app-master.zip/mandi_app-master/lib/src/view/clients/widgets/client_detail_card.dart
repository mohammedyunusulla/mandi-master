import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';
import 'package:mandi_app/utils/constants/enums.dart';
import '../../../../common/widgets/custom_shapes/containers/circular_container.dart';
import '../../../../common/widgets/images/t_circular_image.dart';
import '../../../../utils/constants/colors.dart';
import '../../../../utils/constants/image_strings.dart';
import '../../../../utils/constants/sizes.dart';

class TClientCard extends StatelessWidget {
  const TClientCard({
    super.key,
    required this.backgroundColor,
    required this.image,
    required this.title,
    required this.subTitle,
    required this.address,
    required this.phoneNo,
    this.onTap,
  });

  /// Card background color
  final Color backgroundColor;

  final String image, title, subTitle, address, phoneNo;

  final Function()? onTap;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 200,

      /// TCard Overall design
      child: Container(
        margin: const EdgeInsets.only(bottom: TSizes.spaceBtwItems),
        decoration: BoxDecoration(
          color: backgroundColor,
          borderRadius: BorderRadius.circular(TSizes.cardRadiusLg * 2),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [backgroundColor.withOpacity(0.7), backgroundColor],
          ),
        ),

        /// Use Stack in order to add White Circular Container in the BG
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(TSizes.cardRadiusLg * 2),
          child: Stack(
            children: [
              Positioned(
                bottom: -120,
                right: -180,
                child: TCircularContainer(width: 300, height: 300, backgroundColor: TColors.white.withOpacity(0.1)),
              ),

              /// Main Card Body
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: TSizes.sm, vertical: TSizes.md - 3),
                child: Column(
                  children: [
                    /// Upper List Tile | Image, Name, Email and Download Button
                    Row(
                      children: [
                        Expanded(
                          child: ListTile(
                            leading: TCircularImage(
                              image: image.isNotEmpty ? image : TImages.user,
                              imageType: image.isNotEmpty ? ImageType.network : ImageType.asset,
                              padding: 0,
                            ),
                            title: Text(title.toUpperCase(), style: Theme.of(context).textTheme.titleLarge!.apply(color: TColors.white)),
                            subtitle: Text(subTitle, style: Theme.of(context).textTheme.labelLarge!.apply(color: TColors.white)),
                            trailing: const Icon(Icons.download, color: TColors.white),
                          ),
                        )
                      ],
                    ),
                    const SizedBox(height: TSizes.spaceBtwItems),

                    /// Phone
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: TSizes.md),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          const Icon(Iconsax.call, size: TSizes.iconSm, color: TColors.white),
                          const SizedBox(width: 10.0), // Add some space between icon and text
                          Text(phoneNo.toUpperCase(), style: Theme.of(context).textTheme.labelLarge!.apply(color: TColors.white)),
                        ],
                      ),
                    ),
                    const SizedBox(height: TSizes.spaceBtwItems / 2),

                    /// Location
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: TSizes.md),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          const Icon(Iconsax.location, size: TSizes.iconSm, color: TColors.white),
                          const SizedBox(width: TSizes.spaceBtwItems / 2), // Add some space between icon and text
                          Expanded(
                            child: Text(
                              maxLines: 2,
                              address.toUpperCase(),
                              style: Theme.of(context).textTheme.labelLarge!.apply(color: TColors.white, overflow: TextOverflow.ellipsis),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
