import 'package:flutter/material.dart';
import '../../../../common/widgets/custom_shapes/containers/circular_container.dart';
import '../../../../common/widgets/images/t_circular_image.dart';
import '../../../../src/models/main_card_values.dart';
import '../../../../utils/constants/colors.dart';
import '../../../../utils/constants/image_strings.dart';
import '../../../../utils/constants/sizes.dart';


class TBuyDetailsCard extends StatelessWidget {
  const TBuyDetailsCard({
    super.key,
    required this.backgroundColor,
    required this.image,
    required this.title,
    required this.subTitle,
    required this.cardValues,
    required this.cardDateValue,
    this.onTap,
  });

  /// Card background color
  final Color backgroundColor;

  final String image, title, subTitle;

  final List<MainCardValues> cardValues;
  final List<MainCardValues> cardDateValue;

  final Function()? onTap;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 200,

      /// TCard Overall design
      child: Container(
        margin: const EdgeInsets.only(bottom: TSizes.spaceBtwItems),
        decoration: BoxDecoration(
          color: backgroundColor,
          borderRadius: BorderRadius.circular(TSizes.cardRadiusLg * 2),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [backgroundColor.withOpacity(0.7), backgroundColor],
          ),
        ),

        /// Use Stack in order to add White Circular Container in the BG
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(TSizes.cardRadiusLg * 2),
          child: Stack(
            children: [
              Positioned(
                bottom: -120,
                right: -180,
                child: TCircularContainer(width: 300, height: 300, backgroundColor: TColors.white.withOpacity(0.1)),
              ),

              /// Main Card Body
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: TSizes.sm, vertical: TSizes.md - 3),
                child: Column(
                  children: [
                    /// Upper List Tile
                    Row(
                      children: [
                        Expanded(
                          child: ListTile(
                            leading: const TCircularImage(image: TImages.user, padding: 0),
                            title: Text(title.toUpperCase(), style: Theme.of(context).textTheme.titleLarge!.apply(color: TColors.white)),
                            subtitle: Text(subTitle, style: Theme.of(context).textTheme.labelLarge!.apply(color: TColors.white)),
                            trailing: const Icon(Icons.download, color: TColors.white),
                          ),
                        )
                      ],
                    ),
                    const SizedBox(height: TSizes.spaceBtwItems),
              
                    /// Lower List Tile
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: cardValues
                          .map(
                            (cardValue) => Row(
                              crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(cardValue.key, style: Theme.of(context).textTheme.labelSmall!.apply(color: TColors.white)),
                            const SizedBox(width: TSizes.sm),
                            Text(cardValue.value, style: Theme.of(context).textTheme.titleLarge!.apply(color: TColors.white)),

                          ],
                        ),
                      )
                          .toList(),
                    ),
                    const SizedBox(height: 5),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: cardDateValue
                          .map(
                            (cardDateValue) => Column(
                          children: [
                            Text(cardDateValue.value, style: Theme.of(context).textTheme.headlineSmall!.apply(color: TColors.white)),
                            Text(cardDateValue.key, style: Theme.of(context).textTheme.labelSmall!.apply(color: TColors.white, fontWeightDelta: 1)),
                          ],
                        ),
                      )
                          .toList(),
                      ),
                    )
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
