import 'package:date_field/date_field.dart';
import 'package:flutter/material.dart';
import '../../../../../utils/constants/sizes.dart';

class TSoldForm extends StatelessWidget {
  const TSoldForm({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Form(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          DateTimeFormField(
            decoration: const InputDecoration(labelText: 'Enter Date'),
            mode: DateTimeFieldPickerMode.date,
            onChanged: (DateTime? value) {
              print(value);
            },
          ),
          const SizedBox(height: TSizes.spaceBtwItems),
          TextFormField(
            decoration: const InputDecoration(
                label: Text('Category of Fruit'),
                prefixIcon: Icon(Icons.food_bank)),
          ),
          const SizedBox(height: TSizes.spaceBtwItems),
          TextFormField(
            decoration: const InputDecoration(
                label: Text('Quantity'),
                prefixIcon: Icon(Icons.production_quantity_limits)),
          ),
          const SizedBox(height: TSizes.spaceBtwItems),
          TextFormField(
            decoration: const InputDecoration(
                label: Text('Rate'), prefixIcon: Icon(Icons.payment_rounded)),
          ),
          const SizedBox(height: TSizes.spaceBtwItems),
          TextFormField(
            decoration: const InputDecoration(
                label: Text('Payment'), prefixIcon: Icon(Icons.payment)),
          ),
          const SizedBox(height: TSizes.spaceBtwItems),

        ],
      ),
    );
  }
}
