import 'package:date_field/date_field.dart';
import 'package:flutter/material.dart';
import '../../../../../utils/constants/sizes.dart';

class TBoughtEditForm extends StatelessWidget {
  TBoughtEditForm({
    Key? key,
  }) : super(key: key);

  final TextEditingController dropdownController = TextEditingController();
  final List<String> dropdownItems = const [
    'Option 1',
    'Option 2',
    'Option 3',
    'Option 4'
  ];

  @override
  Widget build(BuildContext context) {
    return Form(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Select Fruit:'),
          MyDropdown(
            label: 'Choose an option',
            items: dropdownItems,
            controller: dropdownController,
          ),
          const SizedBox(height: 20.0),
          DateTimeFormField(
            decoration: const InputDecoration(labelText: 'Enter Date'),
            mode: DateTimeFieldPickerMode.date,
            onChanged: (DateTime? value) {
              value;
            },
          ),
          const SizedBox(height: TSizes.tFormHeight - 20),
          TextFormField(
            decoration: const InputDecoration(
                label: Text('Category of Fruit'),
                prefixIcon: Icon(Icons.food_bank)),
          ),
          const SizedBox(height: TSizes.tFormHeight - 20),
          TextFormField(
            decoration: const InputDecoration(
                label: Text('Quantity'),
                prefixIcon: Icon(Icons.production_quantity_limits)),
          ),
          const SizedBox(height: TSizes.tFormHeight - 20),
          TextFormField(
            decoration: const InputDecoration(
                label: Text('Rate'), prefixIcon: Icon(Icons.payment_rounded)),
          ),
          const SizedBox(height: TSizes.tFormHeight - 20),
          TextFormField(
            decoration: const InputDecoration(
                label: Text('Payment'), prefixIcon: Icon(Icons.payment)),
          ),
          const SizedBox(height: TSizes.tFormHeight - 10),

        ],
      ),
    );
  }
}

class MyDropdown extends StatelessWidget {
  final String label;
  final List<String> items;
  final TextEditingController controller;

  const MyDropdown(
      {super.key,
        required this.label,
        required this.items,
        required this.controller});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        DropdownButtonFormField(
          decoration: InputDecoration(
            hintText: label,
          ),
          onChanged: (newValue) {
            controller.text = newValue.toString();
          },
          items: items.map((item) {
            return DropdownMenuItem(
              value: item,
              child: Text(item),
            );
          }).toList(),
        ),
      ],
    );
  }
}
