import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:iconsax/iconsax.dart';
import 'package:mandi_app/src/view/reports/print_reports/sell_report.dart';
import 'package:mandi_app/src/view/sell/sell_edit_screen.dart';
import 'package:mandi_app/src/view/sell/sell_form_screen.dart';
import 'package:mandi_app/utils/helpers/helper_functions.dart';
import '../../../common/widgets/custom_shapes/containers/buy_sell_card.dart';
import '../../../common/widgets/custom_shapes/containers/rounded_container.dart';
import '../../../common/widgets/dates/from_to_dates.dart';
import '../../../common/widgets/drawer/drawer.dart';
import '../../../common/widgets/images/t_circular_image.dart';
import '../../../common/widgets/searchbar/searchbar.dart';
import '../../../utils/constants/colors.dart';
import '../../../utils/constants/enums.dart';
import '../../../utils/constants/image_strings.dart';
import '../../../utils/constants/sizes.dart';
import '../../controller/sell/sell_controller.dart';
import '../../models/main_card_values.dart';
import '../reports/invoice.dart';

class SellDetailScreen extends StatelessWidget {
  const SellDetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    bool isDarkMode = THelperFunctions.isDarkMode(context);
    final controller = Get.put(SellController());
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            image: DecorationImage(
              image: AssetImage('assets/images/background/mandifood.jpg'),
              fit: BoxFit.cover,
            ),
          ),
          child: Container(
            color: Colors.black.withOpacity(0.7),
          ),
        ),
        title: Text("Sell",
          style: Theme.of(context).textTheme.titleLarge!.copyWith(
            color: isDarkMode ? TColors.light : TColors.light,
          ),),
        iconTheme: IconThemeData(
            color: THelperFunctions.isDarkMode(context)
                ? TColors.light
                : TColors.light),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: TSizes.sm),
            child: SizedBox(
              width: 100,
              child: Obx(
                () => DropdownButton<String>(
                  value: controller.limit.value.toString(),
                  onChanged: (String? newValue) {
                    if (newValue != null) {
                      controller.limit.value = int.parse(newValue);
                      controller.loadData();
                    }
                  },
                  items: const [
                    DropdownMenuItem<String>(
                      value: '7',
                      child: Text('7 Days'),
                    ),
                    DropdownMenuItem<String>(
                      value: '30',
                      child: Text('1 Month'),
                    ),
                    // DropdownMenuItem<String>(
                    //   value: '365',
                    //   child: Text('Year'),
                    // ),
                  ],
                  style: TextStyle(
                    color: Theme.of(context).brightness == Brightness.light
                        ? TColors.light // Light mode text color
                        : TColors.light, // Dark mode text color
                  ),
                  dropdownColor: Theme.of(context).brightness == Brightness.light
                      ? TColors.dark // Light mode dropdown background color
                      : TColors.dark, // Dark mode dropdown background color
                ),
              ),
            ),
          )
        ],
      ),
      drawer: const TDrawer(),
      body: Stack(
        children: [
          // Background Image
          ImageFiltered(
            imageFilter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
            child: Container(
              width: double.infinity,
              height: double.infinity,
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('assets/images/background/mandifood.jpg'),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),

          SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(TSizes.defaultSpace),
              child: Column(
                children: [
                  /// Search and Download Button
                  Row(
                    children: [
                      Expanded(
                        child: TSearchbar(
                          controller: controller.searchTextController,
                          onChanged: (value) => controller.filterData(value),
                        ),
                      ),
                      const SizedBox(width: TSizes.spaceBtwItems),
                      _downloadReport(context),
                    ],
                  ),
                  const SizedBox(height: TSizes.spaceBtwSections),

                  /// All Clients
                  _sellList(controller),
                ],
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Get.to(() => const SellFormScreen()),
        backgroundColor: TColors.primary,
        child: const Icon(Icons.add, color: TColors.white),
      ),
    );
  }

  Obx _sellList(SellController controller) {
    return Obx(() {
      return controller.loading.value
          ? const CircularProgressIndicator()
          : controller.filteredSell.isEmpty
              ? const Center(child: Text('No transaction found.'))
              : ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: controller.filteredSell.length,
                  itemBuilder: (_, index) {
                    final transaction = controller.filteredSell[index];
                    return TBuySellDetailsCard(
                      onTap: () => Get.to(
                          () => SellEditScreen(transaction: transaction)),
                      onPrintInvoice: () => Get.to(Invoice(transactionModel: transaction,)),
                      title: transaction.clientName,
                      leading: TCircularImage(
                        padding: 0,
                        image: transaction.clientProfilePicture.isNotEmpty
                            ? transaction.clientProfilePicture
                            : TImages.user,
                        imageType: transaction.clientProfilePicture.isNotEmpty
                            ? ImageType.network
                            : ImageType.asset,
                        // image: TImages.user
                      ),
                      subTitle: transaction.category,
                      backgroundColor:
                          THelperFunctions.getBackgroundColors(index),
                      cardValues: [
                        MainCardValues(
                            key: 'Rate', value: transaction.rate.toString()),
                        MainCardValues(
                            key: 'Qty', value: transaction.quantity.toString()),
                        MainCardValues(
                            key: 'Total', value: transaction.totalPrice),
                        MainCardValues(
                            key: 'Vehicle No', value: transaction.vehicleNo),
                      ],
                      cardDateValue: [
                        MainCardValues(
                            key: transaction.formattedTransactionDate,
                            value: ''),
                        MainCardValues(
                            key: transaction.paymentRemarks, value: ''),
                      ],
                    );
                  },
                );
    });
  }

  TRoundedContainer _downloadReport(BuildContext context) {
    final dark = THelperFunctions.isDarkMode(context);
    return TRoundedContainer(
      showBorder: true,
      padding: const EdgeInsets.all(TSizes.sm),
      child: IconButton(
          onPressed: () => Get.bottomSheet(
                backgroundColor: dark ? TColors.dark : TColors.white,
                Padding(
                  padding: const EdgeInsets.all(TSizes.defaultSpace),
                  child: TFromToDates(
                      from: (DateTime? value) {},
                      to: (DateTime? value) {},
                      onPressed: () => Get.to(SellReport())),
                ),
              ),
          icon: const Icon(Iconsax.document_download)),
    );
  }
}
