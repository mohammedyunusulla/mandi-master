
import 'package:flutter/material.dart';
import 'package:mandi_app/src/view/profile/profile_form_screen.dart';

import '../../../common/styles/spacing_styles.dart';
import '../../../common/widgets/drawer/drawer.dart';
import '../../../utils/constants/colors.dart';
import '../../../utils/helpers/helper_functions.dart';

class ProfileDetailScreen extends StatelessWidget {
  const ProfileDetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit Profile'),
        iconTheme: IconThemeData(
            color: THelperFunctions.isDarkMode(context)
                ? TColors.light
                : TColors.dark),
      ),
      drawer: const TDrawer(),
      body: const SingleChildScrollView(
        child: Padding(
          padding: TSpacingStyle.paddingWithAppBarHeight,
          child: Column(
            children: [
              /// Form
              ProfileFormScreen(),
            ],
          ),
        ),
      ),
    );
  }
}
