import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:iconsax/iconsax.dart';
import 'package:mandi_app/src/controller/user/edit_user_controller.dart';
import 'package:mandi_app/src/controller/user/user_controller.dart';
import '../../../common/widgets/images/t_circular_image.dart';
import '../../../utils/constants/enums.dart';
import '../../../utils/constants/image_strings.dart';
import '../../../utils/constants/sizes.dart';
import '../../../utils/constants/text_strings.dart';
import '../../../utils/validators/validation.dart';

class ProfileFormScreen extends StatelessWidget {
  const ProfileFormScreen({super.key});


  @override
  Widget build(BuildContext context) {
    final controller = EditUserController();
    UserController userController=Get.find();

    final user = userController.user.value;
    // final user = UserController.instance.user.value;
    controller.initFields(user);

    return  Form(
      key: controller.profileFormKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          /// Image
          Obx(() {
            final localImage = controller.localSelectedImage.value;

            return localImage != null
                ? TCircularImage(file: File(localImage.path), width: 120, height: 120, imageType: ImageType.file)
                : user.profilePicture.isNotEmpty
                ? TCircularImage(image: user.profilePicture, width: 120, height: 120, imageType: ImageType.network)
                : const TCircularImage(image: TImages.user, width: 120, height: 120);
          }),

          TextButton(onPressed: () => controller.pickImage(), child: const Text('Upload Image')),
          const SizedBox(height: TSizes.spaceBtwSections),


          TextFormField(
            controller: controller.name,
            validator: (value) => TValidator.validateEmptyText('Name', value),
            decoration: const InputDecoration(label: Text('Name'), prefixIcon: Icon(Iconsax.user)),
          ),
          const SizedBox(height: TSizes.spaceBtwInputFields),
          TextFormField(
            controller: controller.email,
            decoration: const InputDecoration(labelText: TTexts.email, prefixIcon: Icon(Iconsax.direct)),
          ),
          const SizedBox(height: TSizes.spaceBtwInputFields),
          TextFormField(
           controller: controller.phoneNumber,
            decoration: const InputDecoration(label: Text('Mobile No'), prefixIcon: Icon(Iconsax.mobile)),
          ),
          const SizedBox(height: TSizes.spaceBtwInputFields),
          TextFormField(
            controller: controller.address,
            decoration: const InputDecoration(label: Text('Address'), prefixIcon: Icon(Iconsax.location)),
          ),
          const SizedBox(height: TSizes.spaceBtwSections * 1.5),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(onPressed: ()=> controller.updateUser(user), child: const Text("Update")),
          ),

        ],
      ),
    );
  }
}
