import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import '../../../data/repositories/authentication/authentication_repository.dart';
import '../../../utils/constants/image_strings.dart';
import '../../../utils/helpers/network_manager.dart';
import '../../../utils/popups/full_screen_loader.dart';
import '../../../utils/popups/loaders.dart';
import '../../view/dashboard/dashboard_screen.dart';
import '../user/user_controller.dart';


class LoginController extends GetxController {
  static LoginController get instance => Get.find();

  final isLoading = false.obs;
  final hidePassword = true.obs;
  final rememberMe = false.obs;
  final localStorage = GetStorage();
  final email = TextEditingController();
  final password = TextEditingController();
  final userController = Get.put(UserController());
  GlobalKey<FormState> loginFormKey = GlobalKey<FormState>();
  final authRepository = Get.put(AuthenticationRepository());


  @override
  void onInit() {
    super.onInit();
    initRememberData();
  }


  void initRememberData() {
    email.text = localStorage.read('REMEMBER_ME_EMAIL') ?? '';
    password.text = localStorage.read('REMEMBER_ME_PASSWORD') ?? '';
  }

  /// -- Email and Password SignIn
  Future<void> emailAndPasswordSignIn() async {
    try {
      // Start Loading
      isLoading.value = true;
      TFullScreenLoader.openLoadingDialog('Logging you in...', TImages.docerAnimation);

      // Check Internet Connectivity
      final isConnected = await NetworkManager.instance.isConnected();
      if (!isConnected) {
        isLoading.value = false;
        TFullScreenLoader.stopLoading();
        return;
      }

      // Form Validation
      if (!loginFormKey.currentState!.validate()) {
        isLoading.value = false;
        TFullScreenLoader.stopLoading();
        return;
      }

      // Save Data if Remember Me is selected
      if (rememberMe.value) {
        localStorage.write('REMEMBER_ME_EMAIL', email.text.trim());
        localStorage.write('REMEMBER_ME_PASSWORD', password.text.trim());
      }

      // Login user using EMail & Password Authentication
      await authRepository.loginWithEmailAndPassword(email.text.trim(), password.text.trim());

      // Assign user data to RxUser of UserController to use in app
      final user = await userController.fetchUserRecord();

      // Remove Loader
      TFullScreenLoader.stopLoading();

      // If user is not active => Logout
      if (user.active != true) {
        TLoaders.errorSnackBar(title: 'Oh Snap', message: "Invalid Credentials, contact Admin");
        await authRepository.logout();
      } else {
        // Redirect
        Get.offAll(() => const DashboardScreen());
      }
    } catch (e) {
      isLoading.value = false;
      TFullScreenLoader.stopLoading();
      // Handle errors from TLoaders.errorSnackBar cautiously
      try {
        TLoaders.errorSnackBar(title: 'Oh Snap', message: e.toString());
      } catch (error) {
        print('Error occurred while showing error snackbar: $error');
      }
    }
  }

  //     // Redirect
  //     AuthenticationRepository.instance.screenRedirect();
  //   } catch (e) {
  //     isLoading.value = false;
  //     TFullScreenLoader.stopLoading();
  //     TLoaders.errorSnackBar(title: 'Oh Snap',  message: e.toString());
  //   }
  // }


}