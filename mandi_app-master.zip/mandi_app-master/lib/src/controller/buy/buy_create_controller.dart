import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mandi_app/data/repositories/transaction/transaction_repository.dart';
import 'package:mandi_app/src/controller/buy/buy_controller.dart';
import 'package:mandi_app/src/models/client_model.dart';
import 'package:mandi_app/src/models/transaction_model.dart';
import 'package:mandi_app/utils/constants/enums.dart';

import '../../../data/repositories/client/client_repository.dart';
import '../../../utils/constants/image_strings.dart';
import '../../../utils/helpers/network_manager.dart';
import '../../../utils/popups/full_screen_loader.dart';
import '../../../utils/popups/loaders.dart';

class BuyCreateController extends GetxController {
  static BuyCreateController get instance => Get.find();

  final selectedClient = ClientModel.empty().obs;
  final transactionDate  = Rx<DateTime?>(null);
  final category = TextEditingController();
  final arrivalNo = TextEditingController();
  final labor = TextEditingController();
  final quantity = TextEditingController();
  final rate = TextEditingController();
  final paymentRemarks = TextEditingController();
  final additionalInfo = TextEditingController();
  final clientRepository = Get.put(ClientRepository());
  final transactionRepository = Get.put(TransactionRepository());
  GlobalKey<FormState> buyForm = GlobalKey<FormState>();

  Future<List<ClientModel>> loadClients() async {
    try {
      final List<ClientModel> clients = await clientRepository.fetchAllClients(-1);
      return clients;
    } catch (e) {
      TLoaders.errorSnackBar(title: 'Something went wrong.', message: e.toString());
      return [];
    }
  }

  Future<void> createTransaction() async {
    try {
      // Check Selected Client
      if(selectedClient.value.id.isEmpty){
        TLoaders.errorSnackBar(title: 'Select Client', message: 'Select client in order to add details');
        return;
      }

      // Start Loading
      TFullScreenLoader.openLoadingDialog('Adding New Bought Transaction...', TImages.docerAnimation);

      // Check Internet Connectivity
      final isConnected = await NetworkManager.instance.isConnected();
      if (!isConnected) {
        TFullScreenLoader.stopLoading();
        return;
      }

      // Form Validation
      if (!buyForm.currentState!.validate()) {
        TFullScreenLoader.stopLoading();
        return;
      }

      //Map Buy on a Model
      final buy = TransactionModel(
        clientId: selectedClient.value.id,
        clientName: selectedClient.value.name,
        category: category.text.trim(),
        arrivalNo: arrivalNo.text.trim(),
        labor: int.tryParse(labor.text.trim()) ?? 0,
        quantity: int.tryParse(quantity.text.trim()) ?? 0,
        rate: double.tryParse(rate.text.trim()) ?? 0,
        paymentRemarks: paymentRemarks.text.trim(),
        additionalInfo: additionalInfo.text.trim(),
        transactionType: TransactionType.buy,
        createdAt: DateTime.now(),
        transactionDate : transactionDate.value,
        clientProfilePicture: selectedClient.value.profilePicture,
      );

      // Login user using EMail & Password Authentication
      await transactionRepository.createTransaction(buy);

      // Remove Loader
      TFullScreenLoader.stopLoading();

      // Refresh List
      final buyController = Get.put(BuyController());
      await buyController.loadData();

      // Redirect
      TLoaders.customToast(message: '🎊 Bought Item has been added');
      Get.back();
    } catch (e) {
      TFullScreenLoader.stopLoading();
      TLoaders.errorSnackBar(title: 'Oh Snap', message: e.toString());
    }
  }
}
