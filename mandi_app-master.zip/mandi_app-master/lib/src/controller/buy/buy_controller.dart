import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mandi_app/data/repositories/transaction/transaction_repository.dart';
import 'package:mandi_app/utils/constants/enums.dart';

import '../../../utils/popups/loaders.dart';
import '../../models/transaction_model.dart';

class BuyController extends GetxController {
  static BuyController get instance => Get.find();

  RxInt limit = 7.obs;
  RxBool loading = false.obs;
  final searchTextController = TextEditingController();
  final buyRepository = Get.put(TransactionRepository());
  RxList<TransactionModel> allBought = <TransactionModel>[].obs;
  RxList<TransactionModel> filteredBought = <TransactionModel>[].obs;

 @override
  void onInit() {
    loadData();
    super.onInit();
  }

  Future<void> loadData() async {
    try {
      loading.value = true;
          final List<TransactionModel> newData = await buyRepository.fetchAllTransactions(TransactionType.buy, limit.value);
      allBought.assignAll(newData);
      filteredBought.assignAll(allBought);
      update();
    } catch (e) {
      TLoaders.errorSnackBar(title: 'Something went wrong.', message: e.toString());
    } finally {
      loading.value = false;
    }
  }


  filterData(String query) {
    filteredBought.assignAll(
      allBought.where(
        (buy) =>
            buy.clientName.toLowerCase().contains(query.toLowerCase()) ||
            buy.category.toLowerCase().contains(query.toLowerCase()) ||
            buy.rate.toString().contains((query.toLowerCase())),
      ),
    );

    update();
  }
}
