import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../data/repositories/expense/expense_repository.dart';
import '../../../utils/constants/image_strings.dart';
import '../../../utils/helpers/network_manager.dart';
import '../../../utils/popups/full_screen_loader.dart';
import '../../../utils/popups/loaders.dart';
import '../../models/expense_model.dart';
import 'expense_controller.dart';

class ExpenseCreateController extends GetxController {
  static ExpenseCreateController get instance => Get.find();

  final name = TextEditingController();
  final rate = TextEditingController();
  final paymentRemarks = TextEditingController();
  final expenseRepository = Get.put(ExpenseRepository());
  GlobalKey<FormState> expenseForm = GlobalKey<FormState>();

  Future<List<ExpenseModel>> loadExpense() async {
    try {
      final List<ExpenseModel> expenses = await expenseRepository.fetchAllExpenses(-1);
      return expenses;
    } catch (e) {
      TLoaders.errorSnackBar(title: 'Something went wrong.', message: e.toString());
      return [];
    }
  }

  Future<void> createExpense() async {
    try {
      // Start Loading
      TFullScreenLoader.openLoadingDialog('Adding New Expense Expense...', TImages.docerAnimation);

      // Check Internet Connectivity
      final isConnected = await NetworkManager.instance.isConnected();
      if (!isConnected) {
        TFullScreenLoader.stopLoading();
        return;
      }

      // Form Validation
      if (!expenseForm.currentState!.validate()) {
        TFullScreenLoader.stopLoading();
        return;
      }

      //Map Expense on a Model
      final expense = ExpenseModel(
        name: name.text.trim(),
        amount: double.tryParse(rate.text.trim()) ?? 0,
        remarks: paymentRemarks.text.trim(),
        createdAt: DateTime.now(),
      );

      // Login user using EMail & Password Authentication
      await expenseRepository.createExpense(expense);

      // Remove Loader
      TFullScreenLoader.stopLoading();

      // Refresh List
      final expenseController = Get.put(ExpenseController());
      await expenseController.loadData();

      // Redirect
      TLoaders.customToast(message: '🎊 Bought Item has been added');
      Get.back();
    } catch (e) {
      TFullScreenLoader.stopLoading();
      TLoaders.errorSnackBar(title: 'Oh Snap', message: e.toString());
    }
  }
}
