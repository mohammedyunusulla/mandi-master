import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mandi_app/utils/constants/colors.dart';
import 'package:mandi_app/utils/constants/sizes.dart';
import '../../../data/repositories/expense/expense_repository.dart';
import '../../../data/repositories/transaction/transaction_repository.dart';
import '../../../utils/constants/image_strings.dart';
import '../../../utils/helpers/network_manager.dart';
import '../../../utils/popups/full_screen_loader.dart';
import '../../../utils/popups/loaders.dart';
import '../../models/expense_model.dart';
import 'expense_controller.dart';

class ExpenseUpdateController extends GetxController {
  static ExpenseUpdateController get instance => Get.find();

  ExpenseModel expense = ExpenseModel.empty();
  final name = TextEditingController();
  final amount = TextEditingController();
  final remarks = TextEditingController();
  final expenseRepository = Get.put(ExpenseRepository());
  final transactionRepository = Get.put(TransactionRepository());
  GlobalKey<FormState> expenseForm = GlobalKey<FormState>();

    void initExpenseData(ExpenseModel expense) {
    name.text = expense.name;
    amount.text = expense.amount.toString();
    remarks.text = expense.remarks;
  }


  Future<void> updateExpense(ExpenseModel expense) async {
    try {
      if (expense.id.isEmpty) {
        TLoaders.errorSnackBar(title: 'Oh Snap', message: 'Transaction not found.');
        return;
      }

      // Start Loading
      TFullScreenLoader.openLoadingDialog('Updating Transaction Info...', TImages.docerAnimation);

      // Check Internet Connectivity
      final isConnected = await NetworkManager.instance.isConnected();
      if (!isConnected) {
        TFullScreenLoader.stopLoading();
        return;
      }

      // Form Validation
      if (!expenseForm.currentState!.validate()) {
        TFullScreenLoader.stopLoading();
        return;
      }

      // Map expense's new Data
      expense.name = name.text.trim();
      expense.amount = double.tryParse(amount.text.trim()) ?? 0;
      expense.remarks = remarks.text.trim();

      // Login user using EMail & Password Authentication
      await expenseRepository.updateExpense(expense);

      // Refresh List
      final expenseController = Get.put(ExpenseController());
      await expenseController.loadData();

      // Remove Loader
      TFullScreenLoader.stopLoading();

      // Redirect
      TLoaders.customToast(message: '🎊 Transaction data has been updated', color: TColors.success);
      Get.back();
    } catch (e) {
      TFullScreenLoader.stopLoading();
      TLoaders.errorSnackBar(title: 'Oh Snap', message: e.toString());
    }
  }

  /// Delete Expense
  Future<void> deleteExpense(ExpenseModel expense) async {
    Get.defaultDialog(
      title: 'Delete Bought Transaction',
      content: const Padding(
        padding: EdgeInsets.all(TSizes.sm),
        child: Text('Are you sure you want to remove this expense?', textAlign: TextAlign.center),
      ),
      confirm: SizedBox(width: 100, child: ElevatedButton(onPressed: () => delete(expense), child: const Text('Delete'))),
      cancel: OutlinedButton(onPressed: () => Get.back(), child: const Text('Cancel')),
    );
  }

  delete(ExpenseModel expense) async {
    try {
      if (expense.id.isEmpty) {
        TLoaders.errorSnackBar(title: 'Oh Snap', message: 'Transaction not found.');
        return;
      }

      // Start Loading
      TFullScreenLoader.openLoadingDialog('Deleting Transaction...', TImages.docerAnimation);

      // Check Internet Connectivity
      final isConnected = await NetworkManager.instance.isConnected();
      if (!isConnected) {
        TFullScreenLoader.stopLoading();
        return;
      }

      // Login user using EMail & Password Authentication
      await expenseRepository.removeExpenseRecord(expense.id);

      // Refresh List
      final expenseController = Get.put(ExpenseController());
      await expenseController.loadData();

      // Remove Loader
      TFullScreenLoader.stopLoading();

      // Close Popup
      Get.back();

      // Redirect
      TLoaders.customToast(message: '🎊 Expense Transaction record Deleted', color: TColors.warning);
      Get.back();
    } catch (e) {
      TFullScreenLoader.stopLoading();
      TLoaders.errorSnackBar(title: 'Oh Snap', message: e.toString());
    }
  }
}
