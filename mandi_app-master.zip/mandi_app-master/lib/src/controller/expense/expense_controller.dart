import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../data/repositories/expense/expense_repository.dart';
import '../../../utils/popups/loaders.dart';
import '../../models/expense_model.dart';

class ExpenseController extends GetxController {
  static ExpenseController get instance => Get.find();

  RxInt limit = 7.obs;
  RxBool loading = false.obs;
  final searchTextController = TextEditingController();
  final expenseRepository = Get.put(ExpenseRepository());
  RxList<ExpenseModel> allExpense = <ExpenseModel>[].obs;
  RxList<ExpenseModel> filteredExpense = <ExpenseModel>[].obs;

  @override
  void onInit() {
    loadData();
    super.onInit();
  }

  Future<void> loadData() async {
    try {
      loading.value = true;
      final List<ExpenseModel> newData = await expenseRepository.fetchAllExpenses(limit.value);
      allExpense.assignAll(newData);
      filteredExpense.assignAll(allExpense);
      update();
    } catch (e) {
      TLoaders.errorSnackBar(title: 'Something went wrong.', message: e.toString());
    } finally {
      loading.value = false;
    }
  }

  filterData(String query) {
    filteredExpense.assignAll(
      allExpense.where(
        (expense) =>
            expense.name.toLowerCase().contains(query.toLowerCase()) ||
            expense.amount.toString().contains(query.toLowerCase()) ||
            expense.remarks.toString().contains((query.toLowerCase())),
      ),
    );

    update();
  }
}
