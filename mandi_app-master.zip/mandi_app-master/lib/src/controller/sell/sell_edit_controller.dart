import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mandi_app/src/controller/sell/sell_controller.dart';
import 'package:mandi_app/src/models/transaction_model.dart';
import 'package:mandi_app/utils/constants/colors.dart';
import 'package:mandi_app/utils/constants/sizes.dart';

import '../../../data/repositories/client/client_repository.dart';
import '../../../data/repositories/transaction/transaction_repository.dart';
import '../../../utils/constants/image_strings.dart';
import '../../../utils/helpers/network_manager.dart';
import '../../../utils/popups/full_screen_loader.dart';
import '../../../utils/popups/loaders.dart';
import '../../models/client_model.dart';

class SellUpdateController extends GetxController {
  static SellUpdateController get instance => Get.find();

  final selectedClient = ClientModel.empty().obs;
  final transactionDate = Rx<DateTime?>(null);
  ClientModel client = ClientModel.empty();
  final category = TextEditingController();
  final labor = TextEditingController();
  final quantity = TextEditingController();
  final rate = TextEditingController();
  final commissionAmount = TextEditingController();
  final paymentRemarks = TextEditingController();
  final vehicleNo = TextEditingController();
  final clientRepository = Get.put(ClientRepository());
  final transactionRepository = Get.put(TransactionRepository());
  GlobalKey<FormState> sellForm = GlobalKey<FormState>();

  void initTransactionData(TransactionModel transaction) {
    category.text = transaction.category;
    labor.text = transaction.labor.toString();
    rate.text = transaction.rate.toString();
    commissionAmount.text = transaction.commissionAmount.toString();
    quantity.text = transaction.quantity.toString();
    paymentRemarks.text = transaction.paymentRemarks.toString();
    vehicleNo.text = transaction.vehicleNo.toString();
    transactionDate.value = transaction.transactionDate;
  }


  Future<List<ClientModel>> loadClients() async {
    try {
      final List<ClientModel> clients = await clientRepository.fetchAllClients(-1);
      return clients;
    } catch (e) {
      TLoaders.errorSnackBar(title: 'Something went wrong.', message: e.toString());
      return [];
    }
  }


  Future<void> updateTransaction(TransactionModel transaction) async {
    try {
      if (transaction.id.isEmpty) {
        TLoaders.errorSnackBar(title: 'Oh Snap', message: 'Transaction not found.');
        return;
      }

      // Start Loading
      TFullScreenLoader.openLoadingDialog('Updating Transaction Info...', TImages.docerAnimation);

      // Check Internet Connectivity
      final isConnected = await NetworkManager.instance.isConnected();
      if (!isConnected) {
        TFullScreenLoader.stopLoading();
        return;
      }

      // Form Validation
      if (!sellForm.currentState!.validate()) {
        TFullScreenLoader.stopLoading();
        return;
      }

      // Map Transaction's new Data
      transaction.clientId = selectedClient.value.id.isEmpty ? transaction.clientId : selectedClient.value.id;
      transaction.clientName = selectedClient.value.id.isEmpty ? transaction.clientName : selectedClient.value.name;
      transaction.category = category.text.trim();
      transaction.quantity = int.tryParse(quantity.text.trim()) ?? 0;
      transaction.rate = double.tryParse(rate.text.trim()) ?? 0;
      transaction.commissionAmount = double.tryParse(commissionAmount.text.trim()) ?? 0;
      transaction.labor = int.tryParse(labor.text.trim()) ?? 0;
      transaction.paymentRemarks = paymentRemarks.text.trim();
      transaction.vehicleNo = vehicleNo.text.trim();
      transaction.clientProfilePicture = selectedClient.value.profilePicture.isEmpty ? transaction.clientProfilePicture : selectedClient.value.profilePicture;
      if(transactionDate.value != null) {
        transaction.transactionDate = transactionDate.value;
      }


      // Login user using EMail & Password Authentication
      await transactionRepository.updateTransaction(transaction);

      // Refresh List
      final sellController = Get.put(SellController());
      await sellController.loadData();

      // Remove Loader
      TFullScreenLoader.stopLoading();

      // Redirect
      TLoaders.customToast(message: '🎊 Transaction data has been updated', color: TColors.success);
      Get.back();
    } catch (e) {
      TFullScreenLoader.stopLoading();
      TLoaders.errorSnackBar(title: 'Oh Snap', message: e.toString());
    }
  }

  /// Delete Sell
  Future<void> deleteTransaction(TransactionModel transaction) async {
    Get.defaultDialog(
      title: 'Delete Sold Transaction',
      content: const Padding(
        padding: EdgeInsets.all(TSizes.sm),
        child: Text('Are you sure you want to remove this transaction?', textAlign: TextAlign.center),
      ),
      confirm: SizedBox(width: 100, child: ElevatedButton(onPressed: () => delete(transaction), child: const Text('Delete'))),
      cancel: OutlinedButton(onPressed: () => Get.back(), child: const Text('Cancel')),
    );
  }

  delete(TransactionModel transaction) async {
    try {
      if (transaction.id.isEmpty) {
        TLoaders.errorSnackBar(title: 'Oh Snap', message: 'Transaction not found.');
        return;
      }

      // Start Loading
      TFullScreenLoader.openLoadingDialog('Deleting Transaction...', TImages.docerAnimation);

      // Check Internet Connectivity
      final isConnected = await NetworkManager.instance.isConnected();
      if (!isConnected) {
        TFullScreenLoader.stopLoading();
        return;
      }

      // Login user using EMail & Password Authentication
      await transactionRepository.removeTransactionRecord(transaction.id);

      // Refresh List
      final sellController = Get.put(SellController());
      await sellController.loadData();

      // Remove Loader
      TFullScreenLoader.stopLoading();

      // Close Popup
      Get.back();

      // Redirect
      TLoaders.customToast(message: '🎊 Sold Transaction record Deleted', color: TColors.warning);
      Get.back();
    } catch (e) {
      TFullScreenLoader.stopLoading();
      TLoaders.errorSnackBar(title: 'Oh Snap', message: e.toString());
    }
  }
}
