import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mandi_app/data/repositories/transaction/transaction_repository.dart';
import 'package:mandi_app/utils/constants/enums.dart';

import '../../../utils/popups/loaders.dart';
import '../../models/transaction_model.dart';

class SellController extends GetxController {
  static SellController get instance => Get.find();

  RxInt limit = 7.obs;
  RxBool loading = false.obs;
  final searchTextController = TextEditingController();
  final sellRepository = Get.put(TransactionRepository());
  RxList<TransactionModel> allSell = <TransactionModel>[].obs;
  RxList<TransactionModel> filteredSell = <TransactionModel>[].obs;

  @override
  void onInit() {
    loadData();
    super.onInit();
  }

  Future<void> loadData() async {
    try {
      loading.value = true;
      final List<TransactionModel> newData = await sellRepository.fetchAllTransactions(TransactionType.sell, limit.value);
      allSell.assignAll(newData);
      filteredSell.assignAll(allSell);
      update();
    } catch (e) {
      TLoaders.errorSnackBar(title: 'Something went wrong.', message: e.toString());
    } finally {
      loading.value = false;
    }
  }

  filterData(String query) {
    filteredSell.assignAll(
      allSell.where(
        (sell) =>
            sell.clientName.toLowerCase().contains(query.toLowerCase()) ||
            sell.category.toLowerCase().contains(query.toLowerCase()) ||
            sell.rate.toString().contains((query.toLowerCase())),
      ),
    );

    update();
  }
}
