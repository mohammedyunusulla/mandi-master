import 'package:get/get.dart';
import 'package:mandi_app/src/view/reports/print_reports/all_report.dart';
import 'package:mandi_app/src/view/reports/print_reports/sell_report.dart';
import 'package:mandi_app/utils/constants/image_strings.dart';
import 'package:mandi_app/utils/popups/full_screen_loader.dart';
import 'package:mandi_app/utils/popups/loaders.dart';

import '../../../data/repositories/transaction/transaction_repository.dart';
import '../../../utils/constants/enums.dart';
import '../../models/all_record_model.dart';
import '../../models/transaction_model.dart';
import '../../view/reports/print_reports/buy_report.dart';

class ReportController extends GetxController {
  static ReportController get instance => Get.find();

  RxBool isLoading = false.obs;
  var toDate = Rx<DateTime?>(null);
  var fromDate = Rx<DateTime?>(null);
  var allTransactions = <AllRecordModel>[].obs;
  var buyTransactions = <TransactionModel>[].obs;
  var sellTransactions = <TransactionModel>[].obs;
  final repository = Get.put(TransactionRepository());

  void fetchTransactions(String type) async {
    try {
      TFullScreenLoader.openLoadingDialog('Fetching Records', TImages.docerAnimation);

      if (fromDate.value == null) {
        DateTime today = DateTime.now();
        DateTime lastSevenDays = today.subtract(const Duration(days: 7));
        // If fromDate is not selected, set it to last 7 days
        fromDate.value = lastSevenDays;

        // If toDate is not selected, set it to today
        toDate.value = today;
      }

      if (type == 'buy') {
        await getBuyTransactions();
        Get.to(() => BuyReport());
      } else if (type == 'sell') {
        await getSellTransactions();
        Get.to(() => SellReport());
      } else if (type == 'all') {
        await getAllTransactions();
        Get.to(() => AllReport());
      }
    } catch (error) {
      TFullScreenLoader.stopLoading();
      TLoaders.errorSnackBar(title: 'Oh Snap', message: 'Something went wrong, please try again');
    }
  }

  Future<void> getBuyTransactions() async {
    final newData = await repository.fetchReportTransactions(TransactionType.buy, fromDate.value!, toDate.value!);

    buyTransactions.assignAll(newData);
    TFullScreenLoader.stopLoading();
  }

  Future<void> getSellTransactions() async {
    final newData = await repository.fetchReportTransactions(TransactionType.sell, fromDate.value!, toDate.value!);

    sellTransactions.assignAll(newData);
    TFullScreenLoader.stopLoading();
  }

  Future<void> getAllTransactions() async {
    final data = await repository.fetchAllReports(fromDate.value!, toDate.value!);

    // Convert allTransactions to AllRecordModel and add to allRecords
    allTransactions.assignAll(
      data.map((transaction) => AllRecordModel.fromTransaction(transaction)),
    );
    TFullScreenLoader.stopLoading();
  }
}
