import 'package:get/get.dart';

import '../../../data/repositories/transaction/transaction_repository.dart';
import '../../../utils/constants/enums.dart';
import '../../models/transaction_model.dart'; // Replace with the actual path

class ReportSellController extends GetxController {
  static ReportSellController get instance => Get.find();

  final sellRepository = Get.put(TransactionRepository());
  var transactions = <TransactionModel>[].obs;
  var isLoading = false.obs;
  RxInt limit = 7.obs;
  var fromDate = Rx<DateTime?>(null);
  var toDate = Rx<DateTime?>(null);

  @override
  void onInit() {
    fetchTransactions();
    super.onInit();
  }

  void fetchTransactions() async {
    try {
      isLoading.value = true;


      if(fromDate.value ==null){
        DateTime today = DateTime.now();
        DateTime lastSevenDays = today.subtract(const Duration(days: 6));
        // If fromDate is not selected, set it to last 7 days
        fromDate.value ??= lastSevenDays;

        // If toDate is not selected, set it to today
        toDate.value ??= today;
      }
      final List<TransactionModel> newData = await sellRepository.fetchReportTransactions(
        TransactionType.sell,
        fromDate.value ?? DateTime(2000),
        toDate.value ?? DateTime.now(),
      );

      transactions.assignAll(newData);
    } catch (error) {
      print('Error fetching transactions: $error');
    } finally {
      isLoading.value = false;
    }
  }

}
