import 'package:get/get.dart';

import '../../../data/repositories/transaction/transaction_repository.dart';
import '../../../utils/constants/enums.dart';
import '../../models/transaction_model.dart'; // Replace with the actual path

class ReportBuyController extends GetxController {
  static ReportBuyController get instance => Get.find();

  final buyRepository = Get.put(TransactionRepository());
  var transactions = <TransactionModel>[].obs;
  var isLoading = false.obs;
  var fromDate = Rx<DateTime?>(null);
  var toDate = Rx<DateTime?>(null);

  // void selectFromDate(BuildContext context) async {
  //   final pickedDate = await showDatePicker(
  //     context: context,
  //     initialDate: DateTime.now(),
  //     firstDate: DateTime(2000),
  //     lastDate: DateTime.now(),
  //   );
  //
  //   if (pickedDate != null ) {
  //     fromDate.value = pickedDate;
  //     fetchTransactions();
  //   }
  // }
  //
  // void selectToDate(BuildContext context) async {
  //   final pickedDate = await showDatePicker(
  //     context: context,
  //     initialDate: DateTime.now(),
  //     firstDate: DateTime(2000),
  //     lastDate: DateTime.now(),
  //   );
  //
  //   if (pickedDate != null) {
  //     toDate.value = pickedDate;
  //     fetchTransactions();
  //   }
  // }

  @override
  void onInit() {
    fetchTransactions();
    super.onInit();
  }

  void fetchTransactions() async {
    try {
      isLoading.value = true;

      /// If date is null calculate last 7 days
      if(fromDate.value ==null && toDate.value == null){
        DateTime today = DateTime.now();
        DateTime lastSevenDays = today.subtract(const Duration(days: 7));
        // If fromDate is not selected, set it to last 7 days
        fromDate.value ??= lastSevenDays;

        // If toDate is not selected, set it to today
        toDate.value ??= today;
      }

      final List<TransactionModel> newData = await buyRepository.fetchReportTransactions(
        TransactionType.buy,
        fromDate.value!,
        toDate.value!,
      );

      transactions.assignAll(newData);
    } catch (error) {
      print('Error fetching transactions: $error');
    } finally {
      isLoading.value = false;
    }
  }
}
