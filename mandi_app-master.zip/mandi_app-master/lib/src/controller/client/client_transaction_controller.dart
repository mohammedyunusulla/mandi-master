import 'package:get/get.dart';
import 'package:mandi_app/src/models/transaction_model.dart';
import '../../../data/repositories/transaction/transaction_repository.dart';

class ClientTransactionController extends GetxController {
  static ClientTransactionController get instance => Get.find();
  RxBool loading = false.obs;
  RxInt limit = 7.obs;

  RxList<TransactionModel> buyTransactions = <TransactionModel>[].obs;

  final TransactionRepository transactionRepository = Get.put(TransactionRepository());

  Future<void> fetchClientTransactions(String clientId) async {
    try {
      loading.value = true;
      // Fetch buy transactions
      buyTransactions.assignAll(await transactionRepository.fetchClientTransactions(clientId, 7));
      loading.value = false;
    } catch (e) {
      // Handle error
      print('Error fetching client transactions: $e');
    }
  }
}
