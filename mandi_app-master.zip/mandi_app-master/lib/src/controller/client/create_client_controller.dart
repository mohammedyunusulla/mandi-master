import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:mandi_app/src/controller/client/client_controller.dart';

import '../../../data/repositories/client/client_repository.dart';
import '../../../utils/constants/image_strings.dart';
import '../../../utils/helpers/network_manager.dart';
import '../../../utils/popups/full_screen_loader.dart';
import '../../../utils/popups/loaders.dart';
import '../../models/client_model.dart';

class CreateClientController extends GetxController {
  static CreateClientController get instance => Get.find();

  final imageUploading = false.obs;
  Rx<XFile?> profileImageUrl = Rx<XFile?>(null);

  final name = TextEditingController();
  final email = TextEditingController();
  final mobileNo = TextEditingController();
  final address = TextEditingController();
  final clientRepository = Get.put(ClientRepository());
  GlobalKey<FormState> clientForm = GlobalKey<FormState>();

  Future<void> createClient() async {
    try {
      // Start Loading
      TFullScreenLoader.openLoadingDialog('Creating New Client...', TImages.docerAnimation);

      // Check Internet Connectivity
      final isConnected = await NetworkManager.instance.isConnected();
      if (!isConnected) {
        TFullScreenLoader.stopLoading();
        return;
      }

      // Form Validation
      if (!clientForm.currentState!.validate()) {
        TFullScreenLoader.stopLoading();
        return;
      }

      // Upload Profile Picture If Selected
      String url = '';
      if (profileImageUrl.value != null) {
        final uploadedImage = await clientRepository.uploadImage('Users/Images/Profile/', profileImageUrl.value!);
        url = uploadedImage;
      }

      //Map Client on a Model
      final client = ClientModel(
        profilePicture: url,
        name: name.text.trim(),
        email: email.text.trim(),
        phoneNumber: mobileNo.text.trim(),
        address: address.text.trim(),
        createdAt: DateTime.now(),
      );

      // Login user using EMail & Password Authentication
      await clientRepository.createClient(client);

      // Remove Loader
      TFullScreenLoader.stopLoading();

      // Refresh List
      final clientController = Get.put(ClientController());
      await clientController.loadData();

      // Redirect
      TLoaders.customToast(message: '🎊 Client has been created');
      Get.back();
    } catch (e) {
      TFullScreenLoader.stopLoading();
      TLoaders.errorSnackBar(title: 'Oh Snap', message: e.toString());
    }
  }

  /// Function to pick an image
  Future<void> pickImage() async {
    final imagePicker = ImagePicker();
    final pickedFile = await imagePicker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      profileImageUrl.value = XFile(pickedFile.path);
    }
  }
}
