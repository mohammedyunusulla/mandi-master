import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../data/repositories/client/advance/client_advance_repository.dart';
import '../../../utils/constants/image_strings.dart';
import '../../../utils/helpers/network_manager.dart';
import '../../../utils/popups/full_screen_loader.dart';
import '../../../utils/popups/loaders.dart';
import '../../models/client_advance_model.dart';
import '../../models/client_model.dart';
import '../../models/transaction_model.dart';

class ClientAdvanceController extends GetxController {
  String? clientId;

  static ClientAdvanceController get instance => Get.find();

  RxBool loading = false.obs;
  final advanceDate = Rx<DateTime?>(null);
  final selectedClient = ClientModel.empty().obs;
  final advanceTextField = TextEditingController();
  final clientAdvanceRepository = Get.put(ClientAdvanceRepository());
  GlobalKey<FormState> clientAdvanceForm = GlobalKey<FormState>();
  RxList<ClientAdvanceModel> filteredAdvances = <ClientAdvanceModel>[].obs;
  RxList<ClientAdvanceModel> allAdvances = <ClientAdvanceModel>[].obs;

  Future<void> createClientAdvance(String clientId, String? userId) async {
    try {
      // Start Loading
      TFullScreenLoader.openLoadingDialog('Creating New Advance...', TImages.docerAnimation);

      // Check Internet Connectivity
      final isConnected = await NetworkManager.instance.isConnected();
      if (!isConnected) {
        TFullScreenLoader.stopLoading();
        return;
      }

      // Form Validation
      if (!clientAdvanceForm.currentState!.validate()) {
        TFullScreenLoader.stopLoading();
        return;
      }

      //Map Client Advance on a Model
      final clientAdvance = ClientAdvanceModel(
        userId: userId!,
        clientId: clientId,
        advanceDate: advanceDate.value,
        advance: double.tryParse(advanceTextField.text.trim()) ?? 0,
      );

      await clientAdvanceRepository.createAdvance(clientAdvance);

      // Remove Loader
      TFullScreenLoader.stopLoading();

      // Refresh List
      final clientAdvanceController = Get.put(ClientAdvanceController());
      await clientAdvanceController.loadData(clientId);

      // Redirect
      TLoaders.customToast(message: '🎊 Advance has been created');
    } catch (e) {
      TFullScreenLoader.stopLoading();
      TLoaders.errorSnackBar(title: 'Oh Snap', message: e.toString());
    }
  }

  Future<void> loadData(String clientId) async {
    try {
      loading.value = true;
      final List<ClientAdvanceModel> newData = await clientAdvanceRepository.fetchAllAdvances(clientId);
      allAdvances.assignAll(newData);
      filteredAdvances.assignAll(allAdvances);
      update();
    } catch (e) {
      TLoaders.errorSnackBar(title: 'Something went wrong.', message: e.toString());
    } finally {
      loading.value = false;
    }
  }

  void updateAdvance(String value) {
    advanceTextField.text = value;
  }

  Future<void> updateClientAdvance(ClientAdvanceModel clientAdvance) async {
    try {
      // Start Loading
      TFullScreenLoader.openLoadingDialog('Updating Advance...', TImages.docerAnimation);

      // Check Internet Connectivity
      final isConnected = await NetworkManager.instance.isConnected();
      if (!isConnected) {
        TFullScreenLoader.stopLoading();
        return;
      }

      // Form Validation
      if (!clientAdvanceForm.currentState!.validate()) {
        TFullScreenLoader.stopLoading();
        return;
      }

      // Update Advance
      final updatedAdvance = double.tryParse(advanceTextField.text.trim()) ?? 0;
      clientAdvance.advance = updatedAdvance;
      await clientAdvanceRepository.updateAdvance(clientAdvance.id, updatedAdvance);

      advanceTextField.text = '';

      // Remove Loader
      TFullScreenLoader.stopLoading();

      // Refresh List
      final itemIndex = ClientAdvanceController.instance.filteredAdvances.indexWhere((i) => i == clientAdvance);
      if (itemIndex != -1) {
        ClientAdvanceController.instance.filteredAdvances[itemIndex] = clientAdvance;
      }

      ClientAdvanceController.instance.filteredAdvances.refresh(); // Refresh the UI to reflect the changes

      Get.back();
      // Redirect
      TLoaders.customToast(message: '🎊 Advance has been updated');
    } catch (e) {
      TFullScreenLoader.stopLoading();
      TLoaders.errorSnackBar(title: 'Oh Snap', message: e.toString());
    }
  }

  filterData(String query) {
    filteredAdvances.assignAll(
      allAdvances.where(
        (allAdvance) => allAdvance.advance.toString().contains((query.toLowerCase())),
      ),
    );
    update();
  }

  Future<void> deleteClientAdvance(String advanceId) async {
    try {
      await clientAdvanceRepository.deleteAdvance(advanceId);
      if (clientId != null) {
        // Refresh List
        await loadData(clientId!);
      }
      TLoaders.customToast(message: 'Advance record deleted successfully');
    } catch (e) {
      TLoaders.errorSnackBar(title: 'Error', message: 'Failed to delete advance record: $e');
    }
  }

  double calculateTotalAdvance(RxList<ClientAdvanceModel> advances) {
    double totalAdvance = 0;
    for (var advance in advances) {
      totalAdvance += advance.advance;
    }
    return totalAdvance;
  }

  double calculateTotalTransaction(RxList<TransactionModel> transactions) {
    double totalTransactions = 0;
    for (var transaction in transactions) {
      totalTransactions += transaction.rate * transaction.quantity;
    }
    return totalTransactions;
  }
}
