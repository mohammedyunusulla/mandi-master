import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../data/repositories/client/client_repository.dart';
import '../../../utils/popups/loaders.dart';
import '../../models/client_model.dart';

class ClientController extends GetxController {
  static ClientController get instance => Get.find();

  RxInt limit = 7.obs;
  RxBool loading = false.obs;
  final searchTextController = TextEditingController();
  final clientRepository = Get.put(ClientRepository());
  RxList<ClientModel> clients = <ClientModel>[].obs;
  RxList<ClientModel> filteredClients = <ClientModel>[].obs;

  @override
  void onInit() {
    loadData();
    super.onInit();
  }

  Future<void> loadData() async {
    try {
      loading.value = true;
      final List<ClientModel> newData = await clientRepository.fetchAllClients(limit.value);
      clients.assignAll(newData);
      filteredClients.assignAll(clients);
      update();
    } catch (e) {
      TLoaders.errorSnackBar(title: 'Something went wrong.', message: e.toString());
    } finally {
      loading.value = false;
    }
  }

  filterData(String query) {
    filteredClients.assignAll(
      clients.where(
        (client) =>
            client.name.toLowerCase().contains(query.toLowerCase()) ||
            client.email.toLowerCase().contains(query.toLowerCase()) ||
            client.phoneNumber.contains(query.toLowerCase()),
      ),
    );

    update();
  }
}
