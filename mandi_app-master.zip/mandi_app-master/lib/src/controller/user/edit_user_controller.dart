import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:mandi_app/src/controller/user/user_controller.dart';

import '../../../../data/repositories/user/user_repository.dart';
import '../../../utils/constants/enums.dart';
import '../../../utils/constants/image_strings.dart';
import '../../../utils/helpers/network_manager.dart';
import '../../../utils/popups/full_screen_loader.dart';
import '../../../utils/popups/loaders.dart';
import '../../models/user_model.dart';

class EditUserController extends GetxController {
  static EditUserController get instance => Get.find();

  RxBool loading = false.obs;
  Rx<XFile?> localSelectedImage = Rx<XFile?>(null);

  Rx<AppRole> selectedRole = AppRole.user.obs;
  RxBool active = true.obs;
  GlobalKey<FormState> profileFormKey = GlobalKey<FormState>();
  final name = TextEditingController();
  final email = TextEditingController();
  final password = TextEditingController();
  final phoneNumber = TextEditingController();
  final address = TextEditingController();
  final userRepository = Get.put(UserRepository());
  RxString selectedImage = ''.obs;

  void initFields(UserModel user) {
    selectedImage.value = user.profilePicture;
    active.value = user.active;
    selectedRole.value = user.role;
    name.text = user.name;
    email.text = user.email;
    phoneNumber.text = user.phoneNumber;
    address.text = user.address;
  }

  void changeRole(AppRole newValue) {
    selectedRole.value = newValue;
  }

  Future<void> pickImage() async {
    final image = await ImagePicker().pickImage(source: ImageSource.gallery);
    localSelectedImage.value = image;
  }

  Future<void> updateUser(UserModel user) async {
    try {
      // Start Loading
      // loading.value = true;

      // Start Loading
      TFullScreenLoader.openLoadingDialog('Updating Profile Info...', TImages.docerAnimation);

      // Check Internet Connectivity
      final isConnected = await NetworkManager.instance.isConnected();
      if (!isConnected) {
        // loading.value = false;
        TFullScreenLoader.stopLoading();
        return;
      }

      // Form Validation
      if (!profileFormKey.currentState!.validate()) {
        // loading.value = false;
        TFullScreenLoader.stopLoading();
        return;
      }

      //Upload Profile Picture If Selected
      String url = '';
      if (localSelectedImage.value != null) {
        final uploadedImage = await userRepository.uploadImage('Users/Images/Profile/', localSelectedImage.value!);
        url = uploadedImage;
      }

      // Map Data
      user.name = name.text.trim();
      user.email = email.text.trim();
      user.phoneNumber = phoneNumber.text.trim();
      user.address = address.text.trim();
      user.updatedAt = DateTime.now();
      user.role = selectedRole.value;
      user.active = active.value;
      user.profilePicture = url.isEmpty ? user.profilePicture : url;

      // Call Repository to Create New User
      await UserRepository.instance.updateUserDetails(user);

      // Remove Loader
      // loading.value = false;
      TFullScreenLoader.stopLoading();
      UserController userController = Get.put(UserController());
      // Update Global User Data
      userController.user.value = user;
      // UserController.instance.user.value = user;
      update();

      // Success Message & Redirect
      TLoaders.successSnackBar(title: 'Success', message: 'User record has been updated');
    } catch (e) {
      // loading.value = false;
      TFullScreenLoader.stopLoading();
      TLoaders.errorSnackBar(title: 'Oh Snap', message: e.toString());
    }
  }
}