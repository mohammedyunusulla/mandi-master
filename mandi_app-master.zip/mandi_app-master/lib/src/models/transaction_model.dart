import 'package:cloud_firestore/cloud_firestore.dart';

import '../../../utils/formatters/formatter.dart';
import '../../data/repositories/authentication/authentication_repository.dart';
import '../../utils/constants/enums.dart';

/// Model class representing user data.
class TransactionModel {
  final String id;
  String userId;
  String clientId;
  String clientName;
  String clientProfilePicture;
  String category;
  String arrivalNo;
  String vehicleNo;
  int quantity;
  int labor;
  double rate;
  double commissionAmount;
  String paymentRemarks;
  String additionalInfo;
  DateTime? createdAt;
  DateTime? transactionDate;
  DateTime? updatedAt;
  TransactionType transactionType;

  /// Constructor for UserModel.
  TransactionModel({
    this.id = '',
    this.userId = '',
    required this.clientId,
    required this.clientName,
    this.clientProfilePicture = '',
    required this.transactionType,
    this.updatedAt,
    this.createdAt,
    this.transactionDate,
    this.category = '',
    this.arrivalNo = '',
    this.vehicleNo = '',
    this.quantity = 0,
    this.labor = 0,
    this.rate = 0,
    this.commissionAmount = 0,
    this.paymentRemarks = '',
    this.additionalInfo = '',
  });

  /// Helper function to format phone number.
  String get totalPrice => (rate * quantity).toStringAsFixed(1);

  String get soldTax => ((rate * quantity) * 0.02).toStringAsFixed(2);

  String get formattedCreatedAtDate => TFormatter.formatDate(createdAt);

  String get formattedTransactionDate => TFormatter.formatDate(transactionDate);

  String get formattedUpdatedAtDate => TFormatter.formatDate(updatedAt);

  /// Static function to create an empty user model.
  static TransactionModel empty() => TransactionModel(userId: '', clientId: '', transactionType: TransactionType.buy, updatedAt: DateTime.now(), clientName: '');

  /// Convert model to JSON structure for storing data in Firebase.
  Map<String, dynamic> toJson() {
    return {
      'userId': AuthenticationRepository.instance.authUser!.uid,
      'clientId': clientId,
      'clientName': clientName,
      'clientProfilePicture': clientProfilePicture,
      'category': category,
      'arrivalNo': arrivalNo,
      'vehicleNo': vehicleNo,
      'quantity': quantity,
      'labor': labor,
      'rate': rate,
      'commissionAmount': commissionAmount,
      'paymentRemarks': paymentRemarks,
      'additionalInfo': additionalInfo,
      'createdAt': createdAt,
      'transactionDate': transactionDate,
      'updatedAt': updatedAt = DateTime.now(),
      'transactionType': transactionType.name.toString(),
    };
  }

  /// Factory method to create a UserModel from a Firebase document snapshot.
  factory TransactionModel.fromSnapshot(DocumentSnapshot<Map<String, dynamic>> document) {
    if (document.data() != null) {
      final data = document.data()!;
      return TransactionModel(
        id: document.id,
        userId: data.containsKey('userId') ? data['userId'] ?? '' : '',
        clientId: data.containsKey('clientId') ? data['clientId'] ?? '' : '',
        clientName: data.containsKey('clientName') ? data['clientName'] ?? '' : '',
        clientProfilePicture: data['clientProfilePicture'] ?? '',
        category: data.containsKey('category') ? data['category'] ?? '' : '',
        arrivalNo: data.containsKey('arrivalNo') ? data['arrivalNo'] ?? '' : '',
        vehicleNo: data.containsKey('vehicleNo') ? data['vehicleNo'] ?? '' : '',
        quantity: data.containsKey('quantity') ? data['quantity'] ?? 0 : 0,
        labor: data.containsKey('labor') ? data['labor'] ?? 0 : 0,
        rate: data.containsKey('rate') ? data['rate'] ?? 0 : 0,
        commissionAmount: data.containsKey('commissionAmount') ? data['commissionAmount'] ?? 0 : 0,
        paymentRemarks: data.containsKey('paymentRemarks') ? data['paymentRemarks'] ?? '' : '',
        additionalInfo: data.containsKey('additionalInfo') ? data['additionalInfo'] ?? '' : '',
        createdAt: data.containsKey('createdAt') ? data['createdAt']?.toDate() ?? DateTime.now() : DateTime.now(),
        transactionDate: data.containsKey('transactionDate') ? data['transactionDate']?.toDate() ?? DateTime.now() : DateTime.now(),
        updatedAt: data.containsKey('updatedAt') ? data['updatedAt']?.toDate() ?? DateTime.now() : DateTime.now(),
        transactionType: data.containsKey('transactionType')
            ? (data['transactionType'] ?? TransactionType.sell.name) == TransactionType.buy.name.toString()
                ? TransactionType.buy
                : TransactionType.sell
            : TransactionType.sell,
      );
    } else {
      return empty();
    }
  }
}
