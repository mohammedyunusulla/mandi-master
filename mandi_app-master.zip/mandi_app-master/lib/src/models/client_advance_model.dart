  import 'package:cloud_firestore/cloud_firestore.dart';
  import 'package:mandi_app/data/repositories/authentication/authentication_repository.dart';
  import '../../../utils/formatters/formatter.dart';

  class ClientAdvanceModel {
    final String id;
    String userId;
    String clientId;
    double advance;
    DateTime? advanceDate;

    /// Constructor for ClientModel
    ClientAdvanceModel({
      this.id = '',
      required this.userId,
      required this.clientId,
      this.advance = 0.0,
      this.advanceDate,
    });

    /// Helper function to format phone number.
    String get formattedAdvanceDate => TFormatter.formatDate(advanceDate);

    /// Static function to create an empty user model.
    static ClientAdvanceModel empty() => ClientAdvanceModel(userId: '', clientId: ''); // Default createdAt to current time

    /// Convert model to JSON structure for storing data in Firebase.
    Map<String, dynamic> toJson() {
      return {
        'userId': AuthenticationRepository.instance.authUser?.uid,
        'clientId': clientId,
        'advance': advance,
        'advanceDate': advanceDate,
      };
    }

    /// Factory method to create a ClientModel from a Firebase document snapshot.
    factory ClientAdvanceModel.fromSnapshot(DocumentSnapshot<Map<String, dynamic>> document) {
      if (document.data() != null) {
        final data = document.data()!;
        return ClientAdvanceModel(
          id: document.id,
          userId: data['userId'] ?? '',
          clientId: data['clientId'] ?? '',
          advance: data['advance'] ?? '',
          advanceDate: data.containsKey('advanceDate') ? data['advanceDate']?.toDate() ?? DateTime.now() : DateTime.now(), // Convert to DateTime, default to current time if not available
        );
      } else {
        return empty();
      }
    }
  }
