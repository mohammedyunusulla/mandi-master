import 'package:mandi_app/src/models/transaction_model.dart';

import '../../utils/constants/enums.dart';
import '../../utils/formatters/formatter.dart';
import 'expense_model.dart';

enum RecordType { transaction, expense }

class AllRecordModel {
  final String id;
  final String userId;
  final String clientId;
  final String name; // Client name for transactions, expense name for expenses
  final double amount; // Rate for transactions, amount for expenses
  final int quantity; // Only for transactions
  final double labor; // Only for transactions
  final String remarks; // Payment remarks for transactions, remarks for expenses
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final RecordType recordType;
  final String category; // Category for transactions
  final TransactionType transactionType;
  final double commissionAmount;
  final DateTime? transactionDate;

  // Constructor
  AllRecordModel({
    required this.id,
    required this.userId,
    required this.name,
    required this.amount,
    this.quantity = 0,
    this.labor = 0.0,
    required this.remarks,
    required this.createdAt,
    required this.transactionDate,
    required this.updatedAt,
    required this.recordType,
    required this.clientId,
    required this.category,
    required this.transactionType,
    this.commissionAmount = 0,
  });

  // A method to format createdAt date
  String get formattedCreatedAtDate => TFormatter.formatDate(createdAt);

  // Factory method to create an AllRecordModel from a TransactionModel
  factory AllRecordModel.fromTransaction(TransactionModel transaction) {
    return AllRecordModel(
      id: transaction.id,
      userId: transaction.userId,
      clientId: transaction.clientId,
      name: transaction.clientName,
      amount: transaction.rate,
      quantity: transaction.quantity,
      labor: transaction.labor.toDouble(),
      remarks: transaction.paymentRemarks,
      createdAt: transaction.createdAt,
      updatedAt: transaction.updatedAt,
      recordType: RecordType.transaction,
      category: transaction.category,
      commissionAmount: transaction.commissionAmount,
      transactionType: transaction.transactionType,
      transactionDate: transaction.transactionDate,
    );
  }

  // Factory method to create an AllRecordModel from an ExpenseModel
  factory AllRecordModel.fromExpense(ExpenseModel expense) {
    return AllRecordModel(
      id: expense.id,
      userId: expense.userId,
      clientId: '',
      name: expense.name,
      amount: expense.amount,
      remarks: expense.remarks,
      createdAt: expense.createdAt,
      updatedAt: expense.updatedAt,
      recordType: RecordType.expense,
      quantity: 0,
      labor: 0.0,
      category: '',
      transactionType: TransactionType.sell,
      transactionDate: null,
    );
  }
}
