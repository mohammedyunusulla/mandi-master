import 'package:cloud_firestore/cloud_firestore.dart';

import '../../../utils/formatters/formatter.dart';
import '../../data/repositories/authentication/authentication_repository.dart';

/// Model class representing user data.
class ExpenseModel {
  final String id;
  String userId;
  String name;
  double amount;
  String remarks;
  DateTime? createdAt;
  DateTime? updatedAt;

  /// Constructor for UserModel.
  ExpenseModel({
    this.id = '',
    this.userId = '',
    required this.name,
    this.createdAt,
    this.amount = 0,
    this.remarks = '',
    this.updatedAt,
  });

  /// Helper function to format phone number.
  String get formattedCreatedAtDate => TFormatter.formatDate(createdAt);

  String get formattedUpdatedAtDate => TFormatter.formatDate(updatedAt);

  /// Static function to create an empty user model.
  static ExpenseModel empty() => ExpenseModel(name: '');

  /// Convert model to JSON structure for storing data in Firebase.
  Map<String, dynamic> toJson() {
    return {
      'userId': AuthenticationRepository.instance.authUser!.uid,
      'name': name,
      'amount': amount,
      'remarks': remarks,
      'createdAt': createdAt,
      'updatedAt': updatedAt = DateTime.now(),
    };
  }

  /// Factory method to create a UserModel from a Firebase document snapshot.
  factory ExpenseModel.fromSnapshot(DocumentSnapshot<Map<String, dynamic>> document) {
    if (document.data() != null) {
      final data = document.data()!;
      return ExpenseModel(
        id: document.id,
        userId: data.containsKey('userId') ? data['userId'] ?? '' : '',
        name: data.containsKey('name') ? data['name'] ?? '' : '',
        amount: data.containsKey('amount') ? data['amount'] ?? 0 : 0,
        remarks: data.containsKey('remarks') ? data['remarks'] ?? '' : '',
        createdAt: data.containsKey('createdAt') ? data['createdAt']?.toDate() ?? DateTime.now() : DateTime.now(),
        updatedAt: data.containsKey('updatedAt') ? data['updatedAt']?.toDate() ?? DateTime.now() : DateTime.now(),
      );
    } else {
      return empty();
    }
  }
}
