
import 'package:flutter/cupertino.dart';

class MainCardValues {
  final String key;
  final String value;
  final TextOverflow? overflow;

  MainCardValues({required this.key, required this.value,this.overflow,});
}
