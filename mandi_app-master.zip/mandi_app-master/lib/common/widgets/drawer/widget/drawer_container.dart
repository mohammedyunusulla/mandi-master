import 'package:flutter/material.dart';
import 'package:mandi_app/common/widgets/images/t_circular_image.dart';
import 'package:mandi_app/utils/constants/image_strings.dart';
import 'package:mandi_app/utils/constants/sizes.dart';

import '../../../../utils/constants/enums.dart';

class TDrawerContainer extends StatelessWidget {
  const TDrawerContainer({
    super.key,
    required this.imageType,
    required this.title,
    required this.subtitle,
    this.containerWidth = 400.0,
    this.containerHeight = 400.0,
    this.backgroundColor = Colors.grey,
    this.image,
  });

  // final ImageProvider<Object>? backgroundImage;
  final ImageType imageType;
  final String? image;
  final String title;
  final String subtitle;
  final double? containerWidth;
  final double? containerHeight;
  final Color backgroundColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: containerWidth,
      height: containerHeight,
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(TSizes.borderRadiusLg),
        // image: DecorationImage(image: backgroundImage, fit: BoxFit.cover),
      ),
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TCircularImage(
                width: 48,
                height: 48,
                padding: 0,
                image: imageType == ImageType.asset
                    ? TImages.user
                   : (image == null || image!.isEmpty)
                        ? TImages.user
                        : image,
                imageType: (image == null || image!.isEmpty)
                    ? ImageType.asset : ImageType.network,
              ),
              const SizedBox(width: 16.0), // Add some spacing
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 18.0,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      subtitle,
                      style: const TextStyle(
                        fontSize: 14.0,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
