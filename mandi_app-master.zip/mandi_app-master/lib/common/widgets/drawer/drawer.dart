import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:iconsax/iconsax.dart';
import 'package:mandi_app/common/widgets/drawer/widget/drawer_container.dart';
import 'package:mandi_app/utils/constants/enums.dart';
import '../../../src/controller/user/user_controller.dart';
import '../../../src/view/buy/buy_detail_screen.dart';
import '../../../src/view/clients/client_details_screen.dart';
import '../../../src/view/expense/expense_details_screen.dart';
import '../../../src/view/dashboard/dashboard_screen.dart';
import '../../../src/view/profile/profile_screen.dart';
import '../../../src/view/reports/report_screen.dart';
import '../../../src/view/sell/sell_details_screen.dart';
import '../../../utils/constants/sizes.dart';
import '../shimmers/shimmer.dart';

class TDrawer extends StatelessWidget {
  const TDrawer({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final UserController controller = Get.put(UserController());

    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
            decoration: const BoxDecoration(color: Colors.blue),
            child: Column(
              children: [
                Obx(
                      () => controller.user.value.email.isNotEmpty
                      ? TDrawerContainer(
                    imageType: ImageType.network,
                    image: controller.user.value.profilePicture,
                    title: controller.user.value.name,
                    subtitle: controller.user.value.email,
                    backgroundColor: Colors.blue,
                    containerWidth: double.infinity,
                    containerHeight: 80.0,
                  )
                      : const Row(
                        children: [
                          TShimmerEffect(width: 60, height: 60.0, radius: 60),
                          SizedBox(width: TSizes.spaceBtwItems),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              TShimmerEffect(width: 70, height: 15),
                              SizedBox(height: TSizes.spaceBtwItems / 2),
                              TShimmerEffect(width: 90, height: 12),
                            ],
                          ),
                        ],
                      ),
                ),
              ],
            ),
          ),
          ListTile(
            leading: const Icon(Iconsax.home),
            title: const Text('Dashboard'),
            onTap: () {
              // Handle item 1 tap
              Navigator.pop(context); // Close the drawer
              Get.off(() => const DashboardScreen());
            },
          ),
          ListTile(
            leading: const Icon(Iconsax.shopping_bag),
            title: const Text('Buy'),
            onTap: () {
              // Handle item 2 tap
              Navigator.pop(context); // Close the drawer
              Get.off(() => const BoughtDetailScreen());
            },
          ),
          ListTile(
            leading: const Icon(Iconsax.shopping_cart),
            title: const Text('Sell'),
            onTap: () {
              // Handle item 1 tap
              Navigator.pop(context); // Close the drawer
              Get.off(() => const SellDetailScreen());
            },
          ),
          ListTile(
            leading: const Icon(Iconsax.money),
            title: const Text('Expense'),
            onTap: () {
              // Handle item 2 tap
              Navigator.pop(context); // Close the drawer
              Get.off(() => const ExpenseDetailsScreen());
            },
          ),
          ListTile(
            leading: const Icon(Iconsax.people),
            title: const Text('Clients'),
            onTap: () {
              // Handle item 2 tap
              Navigator.pop(context); // Close the drawer
              Get.off(() => const ClientDetailsScreen());
            },
          ),
          ListTile(
            leading: const Icon(Iconsax.document),
            title: const Text('Reports'),
            onTap: () => Get.off(() => const ReportsScreen()),
          ),
          ListTile(
            leading: const Icon(Iconsax.profile_tick),
            title: const Text('Profile'),
            onTap: () {
              // Handle item 2 tap
              Navigator.pop(context); // Close the drawer
              Get.off(() => const ProfileDetailScreen());
            },
          ),

          const SizedBox(height: TSizes.spaceBtwSections),
          SizedBox(width: double.infinity, child: OutlinedButton(onPressed: () => controller.logout(), child: const Text('Logout'))),

          // Add more ListTile widgets for additional menu items
        ],
      ),
    );
  }
}
