import 'package:date_field/date_field.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../src/controller/reports/reports_buy_controller.dart';
import '../../../src/controller/reports/reports_sell_controller.dart';
import '../../../utils/constants/sizes.dart';
import '../texts/section_heading.dart';

class TFromToDates extends StatelessWidget {
  const TFromToDates({
    super.key,
    this.headingText = 'Choose Date Range',
    required this.from,
    required this.to,
    required this.onPressed,
  });

  final String headingText;
  final Function(DateTime? value)? from, to;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    final ReportBuyController buyController = Get.put(ReportBuyController());
    final ReportSellController sellController = Get.put(ReportSellController());
    return SingleChildScrollView(
      child: Column(
        children: [
          /// Heading
          TSectionHeading(title: headingText, showActionButton: false),
          const SizedBox(height: TSizes.spaceBtwItems),

          /// From Date
          DateTimeFormField(
            decoration: const InputDecoration(labelText: 'Date From'),
            mode: DateTimeFieldPickerMode.date,
            onChanged: (DateTime? value) {
              buyController.fromDate.value = value;
              buyController.fetchTransactions();
              sellController.fromDate.value = value;
              sellController.fetchTransactions();
            },
          ),
          const SizedBox(height: TSizes.spaceBtwItems),

          /// TO Dates
          DateTimeFormField(
            decoration: const InputDecoration(labelText: 'Date To'),
            mode: DateTimeFieldPickerMode.date,
            onChanged: (DateTime? value) {
              buyController.toDate.value = value;
              buyController.fetchTransactions();
              sellController.toDate.value = value;
              sellController.fetchTransactions();
            },
          ),
          const SizedBox(height: TSizes.spaceBtwSections),

          /// Button
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(onPressed: onPressed, child: const Text('Generate Report')),
          )
        ],
      ),
    );
  }
}