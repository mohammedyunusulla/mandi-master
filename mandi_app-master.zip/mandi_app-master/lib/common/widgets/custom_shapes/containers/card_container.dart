import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';
import 'package:mandi_app/utils/constants/sizes.dart';

class TCardContainer extends StatelessWidget {
  const TCardContainer({
    super.key,
    required this.backgroundImage,
    required this.leadingImage,
    required this.title,
    required this.subtitle,
    required this.trailingWidget,
    this.containerWidth = 400.0,
    this.containerHeight = 400.0,
    this.backgroundColor = Colors.grey,
    this.backgroundGradient,
  });

  final ImageProvider<Object> backgroundImage;
  final ImageProvider<Object> leadingImage;
  final String title;
  final String subtitle;
  final Widget trailingWidget;
  final double? containerWidth;
  final double? containerHeight;
  final Color backgroundColor;
  final Gradient? backgroundGradient;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: containerWidth,
      height: containerHeight,
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(TSizes.borderRadiusLg * 2),
        image: DecorationImage(image: backgroundImage, fit: BoxFit.cover),
        gradient: backgroundGradient,

      ),
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  image: DecorationImage(
                    image: leadingImage,
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              const SizedBox(width: 16.0), // Add some spacing
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 18.0,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      subtitle,
                      style: const TextStyle(
                        fontSize: 14.0,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 16.0), // Add some spacing
              trailingWidget,
            ],
          ),
          const SizedBox(height: 16.0), // Add some spacing between the rows
          const Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // First column with icon and text
              Column(
                children: [
                  Icon(Icons.money, color: Colors.white),
                  Text('Trans', style: TextStyle(color: Colors.white)),
                  Text('10000', style: TextStyle(color: Colors.white)),
                ],
              ),
              // Second column with icon and text
              Column(
                children: [
                  Icon(Iconsax.money_21, color: Colors.white),
                  Text('Rate', style: TextStyle(color: Colors.white)),
                  Text('10000', style: TextStyle(color: Colors.white)),
                ],
              ),
              // Third column with icon and text
              Column(
                children: [
                  Icon(Iconsax.additem, color: Colors.white),
                  Text('Qty', style: TextStyle(color: Colors.white)),
                  Text('10000', style: TextStyle(color: Colors.white)),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}
