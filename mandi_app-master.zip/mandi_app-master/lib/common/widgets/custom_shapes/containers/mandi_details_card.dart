import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';

import '../../../../src/models/main_card_values.dart';
import '../../../../utils/constants/colors.dart';
import '../../../../utils/constants/sizes.dart';
import 'circular_container.dart';

class TMandiDetailsCard extends StatelessWidget {
  const TMandiDetailsCard({
    super.key,
    required this.backgroundColor,
    required this.title,
    required this.subTitle,
    this.cardValues,
    this.onTap,
    this.fixedHeight = false, this.leading,
  });

  final bool fixedHeight;
  final Function()? onTap;
  final Color backgroundColor;
  final String title, subTitle;
  final Widget? leading;
  final List<MainCardValues>? cardValues;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: fixedHeight ? 176 : null,

      /// TCard Overall design
      child: Container(
        margin: const EdgeInsets.only(bottom: TSizes.spaceBtwItems),
        decoration: BoxDecoration(
          color: backgroundColor,
          borderRadius: BorderRadius.circular(TSizes.cardRadiusLg * 2),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [backgroundColor.withOpacity(0.7), backgroundColor],
          ),
        ),

        /// Use Stack in order to add White Circular Container in the BG
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(TSizes.cardRadiusLg * 2),
          child: Stack(
            children: [
              Positioned(
                bottom: -120,
                right: -180,
                child: TCircularContainer(width: 300, height: 300, backgroundColor: TColors.white.withOpacity(0.1)),
              ),

              /// Main Card Body
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: TSizes.sm, vertical: TSizes.md - 3),
                child: Column(
                  children: [
                    /// Upper List Tile
                    Row(
                      children: [
                        Expanded(
                          child: ListTile(
                            leading: leading,
                            title: Text(title.toUpperCase(), style: Theme.of(context).textTheme.titleLarge!.apply(color: TColors.white)),
                            subtitle: Text(subTitle, style: Theme.of(context).textTheme.labelLarge!.apply(color: TColors.white)),
                            trailing: const Icon(Iconsax.arrow_circle_right, color: TColors.white),
                          ),
                        )
                      ],
                    ),
                    if (cardValues != null) const SizedBox(height: TSizes.spaceBtwItems),

                    /// Lower List Tile
                    if (cardValues != null)
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: cardValues!
                            .map(
                              (cardValue) => Column(
                                children: [
                                  Text(cardValue.value, style: Theme.of(context).textTheme.labelLarge!.apply(color: TColors.white)),
                                  Text(cardValue.key,
                                      style: Theme.of(context).textTheme.labelSmall!.apply(color: TColors.white, fontWeightDelta: 1)),
                                ],
                              ),
                            )
                            .toList(),
                      )
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
