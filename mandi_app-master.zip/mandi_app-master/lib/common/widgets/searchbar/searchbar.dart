import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';
import 'package:mandi_app/utils/constants/colors.dart';
import 'package:mandi_app/utils/helpers/helper_functions.dart';

import '../../../utils/constants/sizes.dart';
import '../custom_shapes/containers/rounded_container.dart';

class TSearchbar extends StatelessWidget {
  const TSearchbar({
    super.key,
    this.controller,
    this.showBorder = false,
    this.hintText = 'Search here...', this.onChanged,
  });

  final bool showBorder;
  final String hintText;
  final void Function(String)? onChanged;
  final TextEditingController? controller;

  @override
  Widget build(BuildContext context) {
    final dark = THelperFunctions.isDarkMode(context);
    return TRoundedContainer(
      backgroundColor: dark ? TColors.darkContainer : Colors.white,
      padding: const EdgeInsets.symmetric(vertical: TSizes.sm),
      showBorder: true,
      child: TextFormField(
        onChanged: onChanged,
        controller: controller,
        decoration: InputDecoration(
          hintText: hintText,
          border: showBorder ? null : InputBorder.none,
          focusedBorder: showBorder ? null : InputBorder.none,
          enabledBorder: showBorder ? null : InputBorder.none,
          prefixIcon: const Icon(Iconsax.search_normal),
        ),
      ),
    );
  }
}
